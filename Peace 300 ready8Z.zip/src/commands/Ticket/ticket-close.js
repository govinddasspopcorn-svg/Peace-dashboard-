const { Ticket } = require("../../schema/ticket");
const TicketHandler = require("../../utils/ticketHandler");
const handler = new TicketHandler(null);

module.exports = {
  name: "ticket-close",
  aliases: ["close"],
  description: "Close a ticket",

  async execute(message) {
    if (!message.channel)
      return;

    await handler.handleCloseTicket({
      channel: message.channel,
      guild: message.guild,
      user: message.author,
      reply: (data) => message.channel.send(data.content)
    });
  }
};