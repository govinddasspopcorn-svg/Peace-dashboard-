const { Ticket } = require("../../schema/ticket");

module.exports = {
  name: "ticket-rename",
  aliases: ["rename"],
  description: "Rename the current ticket channel",

  async execute(message, args) {
    try {
      const channel = message.channel;

      // Block renaming categories
      if (!channel || channel.type !== 0)
        return channel?.send("❌ This command must be used in a ticket text channel.");

      // Safety: ensure it's a registered ticket
      const ticket = await Ticket.findOne({
        Guild: message.guild.id,
        Channel: channel.id
      });

      if (!ticket)
        return channel.send("❌ This channel is **not a registered ticket**.");

      const newName = args.join(" ");
      if (!newName)
        return channel.send("❌ Provide a new name.\nExample: `trename payment-issue`");

      // Prevent guild-wide renames
      if (channel.isThread)
        return channel.send("❌ Cannot rename threads using this command.");

      // Rename safely
      await channel.setName(newName).catch(() => null);

      return channel.send(
        `✏️ Renamed ticket to **${newName}**`
      );

    } catch (err) {
      console.log("Rename Error:", err);
      return message.channel?.send("❌ Failed to rename. Try again.");
    }
  }
};