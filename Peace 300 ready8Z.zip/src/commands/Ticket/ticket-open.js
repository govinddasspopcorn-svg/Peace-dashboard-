const TicketCategory = require("../../schema/ticket").TicketCategory;
const TicketHandler = require("../../utils/ticketHandler");
const handler = new TicketHandler(null);

module.exports = {
  name: "ticket-open",
  aliases: ["newticket","openticket"],
  description: "Open a support ticket",

  async execute(message, args, client) {
    const category = await TicketCategory.findOne({
      Guild: message.guild.id
    });

    if (!category)
      return message.reply("<:cross:1455452613645566147> Ticket panel not setup!");

    const created = await handler.createTicket({
      guild: message.guild,
      user: message.author,
      category
    });

    if (!created)
      return message.reply("<:cross:1455452613645566147> Failed to create ticket.");

    if (created.blocked)
      return message.reply(
        `<:Queue:1455451575198683218> You already have a ticket: ${created.channel}`
      );

    return message.reply(
      `<a:ticket:1414311755311484958> Ticket Created: ${created}`
    );
  }
};