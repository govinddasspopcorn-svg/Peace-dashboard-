const TicketHandler = require("../../utils/ticketHandler");
const handler = new TicketHandler(null);

module.exports = {
  name: "ticket-call",
  aliases: ["callstaff","staff"],
  description: "Call staff into ticket",

  async execute(message) {
    await handler.handleCallStaff({
      channel: message.channel,
      guild: message.guild,
      user: message.author,
      reply: d => message.channel.send(d.content)
    });
  }
};