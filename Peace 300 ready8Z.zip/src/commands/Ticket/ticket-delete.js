const { TicketCategory } = require("../../schema/ticket");

module.exports = {
  name: "ticket-panel-delete",
  aliases: ["deletepanel", "tpaneldelete"],
  description: "Delete a ticket panel",

  async execute(message) {
    const id = message.content.split(" ")[1];

    if (!id)
      return message.reply(
        "❌ Provide panel ID.\nCheck panel ID from button error logs or DB."
      );

    const panel = await TicketCategory.findById(id);
    if (!panel) return message.reply("❌ Panel not found.");

    await TicketCategory.deleteOne({ _id: id });

    message.reply("🗑 Ticket panel deleted successfully.");
  }
};