module.exports = {
  name: "ticket-remove",
  aliases: ["remove"],
  description: "Remove a member from ticket",

  async execute(message) {
    if (!message.channel) return;

    const member =
      message.mentions.members.first() ||
      message.guild.members.cache.get(message.content.split(" ")[1]);

    if (!member)
      return message.reply("❌ Mention a user to remove!");

    try {
      await message.channel.permissionOverwrites.edit(member.id, {
        ViewChannel: false,
      });

      message.reply(
        `<:cross:1455452613645566147> Removed **${member.user.tag}** from ticket`
      );
    } catch {
      message.reply("❌ Failed to remove user.");
    }
  }
};