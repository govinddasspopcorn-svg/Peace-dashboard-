module.exports = {
  name: "ticket-add",
  aliases: ["add"],
  description: "Add a member to ticket",

  async execute(message) {
    if (!message.channel) return;

    const member =
      message.mentions.members.first() ||
      message.guild.members.cache.get(message.content.split(" ")[1]);

    if (!member)
      return message.reply("❌ Mention a user to add!");

    try {
      await message.channel.permissionOverwrites.edit(member.id, {
        ViewChannel: true,
        SendMessages: true,
        AttachFiles: true,
        EmbedLinks: true,
      });

      message.reply(
        `<:member:1451140903409287305> Added **${member.user.tag}** to ticket`
      );
    } catch {
      message.reply("❌ Failed to add user.");
    }
  }
};