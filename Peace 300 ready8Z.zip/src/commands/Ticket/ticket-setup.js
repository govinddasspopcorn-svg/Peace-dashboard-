const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder
} = require("discord.js");

const {
  TicketCategory,
  TicketSettings
} = require("../../schema/ticket");

module.exports = {
  name: "ticket-quicksetup",
  aliases: ["tquick", "tsetup"],
  category: "ticket",

  execute: async (message, args, client, prefix) => {
    const e = client.emoji;
    const filter = m => m.author.id === message.author.id;

    const Q = "<:Queue:1455451575198683218>";
    const X = "<:cross:1455452613645566147>";

    async function ask(text) {
      await message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color || "#ffaa00")
            .setDescription(`${Q} ${text}`)
        ]
      });

      const res = await message.channel.awaitMessages({
        filter,
        max: 1,
        time: 300000
      }).catch(() => null);

      if (!res) throw "cancelled";
      return res.first();
    }

    try {
      await message.reply(`${Q} **Quick Ticket Setup Started**`);

      /* ================= GLOBAL SETTINGS ================= */
      await TicketSettings.findOneAndUpdate(
        { Guild: message.guild.id },
        {
          Guild: message.guild.id,
          GlobalLimit: 1,
          CooldownMs: 12000
        },
        { upsert: true }
      );

      /* ================= PANEL NAME ================= */
      const nameAsk = await ask("Enter **Panel Name** (Example: Support / Paid / Help)");
      const Name = nameAsk.content;

      /* ================= EMOJI ================= */
      const emojiAsk = await ask("Enter Emoji or type `none`");
      const Emoji =
        emojiAsk.content.toLowerCase() === "none"
          ? Q
          : emojiAsk.content;

      /* ================= DESCRIPTION ================= */
      const descAsk = await ask("Enter **Panel Description**");
      const Description = descAsk.content;

      /* ================= PANEL TYPE ================= */
      await message.channel.send(
        `${Q} Choose panel type:\n\`button\` = Button Panel\n\`dropdown\` = Select Menu`
      );
      const typeAsk = await message.channel.awaitMessages({
        filter,
        max: 1,
        time: 300000
      });

      const PanelType = ["button", "dropdown"].includes(
        typeAsk.first().content.toLowerCase()
      )
        ? typeAsk.first().content.toLowerCase()
        : "button";

      /* ================= OPEN CATEGORY ================= */
      await message.channel.send(
        `${Q} Mention **OPEN Ticket Category**`
      );
      const oc = await message.channel.awaitMessages({
        filter,
        max: 1,
        time: 300000
      });

      const OpenCategory =
        oc.first().mentions.channels.first()?.id ||
        message.guild.channels.cache.get(oc.first().content)?.id;

      if (!OpenCategory)
        return message.reply(`${X} Invalid category`);

      /* ================= CLOSED CATEGORY ================= */
      await message.channel.send(
        `${Q} Mention **CLOSED Ticket Category** or type \`none\``
      );
      const cc = await message.channel.awaitMessages({
        filter,
        max: 1,
        time: 300000
      });

      const ClosedCategory =
        cc.first().content.toLowerCase() === "none"
          ? null
          : cc.first().mentions.channels.first()?.id ||
            message.guild.channels.cache.get(cc.first().content)?.id;

      /* ================= SUPPORT ROLES ================= */
      await message.channel.send(
        `${Q} Mention **Support Roles** or type \`none\``
      );
      const sr = await message.channel.awaitMessages({
        filter,
        max: 1,
        time: 300000
      });

      const SupportRoles =
        sr.first().content.toLowerCase() === "none"
          ? []
          : sr.first().mentions.roles.map(r => r.id);

      /* ================= SAVE DB ================= */
      const category = await TicketCategory.create({
        Guild: message.guild.id,
        Name,
        Emoji,
        Description,
        Enabled: true,
        OpenCategory,
        ClosedCategory,
        SupportRoles,
        PanelType
      });

      /* ================= AUTO LOGS CHANNEL ================= */
      try {
        const logsChannel = await message.guild.channels.create({
          name: `${Name.toLowerCase().replace(/ /g, "-")}-logs`,
          type: 0,
          permissionOverwrites: [
            { id: message.guild.id, deny: ["ViewChannel"] },
            ...(SupportRoles || []).map(r => ({
              id: r,
              allow: ["ViewChannel", "SendMessages", "ReadMessageHistory"]
            }))
          ]
        });

        category.LogsChannel = logsChannel.id;
        await category.save();

        await logsChannel.send({
          embeds: [
            new EmbedBuilder()
              .setColor("#2b2d31")
              .setTitle("🧾 Ticket Logs Enabled")
              .setDescription(
                `Logs enabled for:\n\n` +
                  `📂 Panel: **${Name}**\n` +
                  `🛡️ Support: ${
                    SupportRoles?.length
                      ? SupportRoles.map(r => `<@&${r}>`).join(", ")
                      : "None"
                  }\n\n` +
                  `📌 Ticket Open Logs\n` +
                  `📌 Ticket Close Logs\n` +
                  `📄 Transcripts\n` +
                  `📩 DM System`
              )
              .setTimestamp()
          ]
        });
      } catch (err) {
        console.log("Failed Logs Channel:", err);
      }

      /* ================= PANEL SEND CHANNEL ================= */
      await message.channel.send(
        `${Q} Mention channel to send Ticket Panel`
      );
      const pc = await message.channel.awaitMessages({
        filter,
        max: 1,
        time: 300000
      });

      const PanelChannel =
        pc.first().mentions.channels.first() ||
        message.guild.channels.cache.get(pc.first().content);

      if (!PanelChannel)
        return message.reply(`${X} Invalid channel`);

      const embed = new EmbedBuilder()
        .setColor(client.color || "#2b2d31")
        .setTitle(`${Emoji} ${Name} Tickets`)
        .setDescription(Description)
        .setFooter({ text: "Peace Ticket System" })
        .setTimestamp();

      let components = [];

      if (PanelType === "button") {
        components = [
          new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId(`ticket_btn_${category._id}`)
              .setLabel("Open Ticket")
              .setEmoji("<a:ticket:1414311755311484958>")
              .setStyle(ButtonStyle.Primary)
          )
        ];
      } else {
        components = [
          new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
              .setCustomId("ticket_dropdown")
              .setPlaceholder("Open Ticket")
              .addOptions([
                {
                  label: Name,
                  value: category._id.toString(),
                  emoji: Emoji
                }
              ])
          )
        ];
      }

      await PanelChannel.send({
        embeds: [embed],
        components
      });

      message.reply(
        `${Q} Ticket Setup Completed — Panel Sent`
      );
    } catch {
      return message.reply(`${X} Setup Cancelled or Timed Out`);
    }
  }
};