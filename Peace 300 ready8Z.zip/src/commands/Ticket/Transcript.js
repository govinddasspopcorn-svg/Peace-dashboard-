const TicketHandler = require("../../utils/ticketHandler");
const handler = new TicketHandler(null);

module.exports = {
  name: "ticket-transcript",
  aliases: ["transcript","delete"],
  description: "Delete ticket with transcript",

  async execute(message) {
    await handler.handleDeleteWithTranscript({
      channel: message.channel,
      guild: message.guild,
      user: message.author,
      reply: d => message.channel.send(d.content)
    });
  }
};