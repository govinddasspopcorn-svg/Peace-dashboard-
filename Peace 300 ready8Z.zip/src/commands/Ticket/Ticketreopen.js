const { Ticket, TicketCategory } = require("../../schema/ticket");

module.exports = {
  name: "ticket-reopen",
  aliases: ["reopen"],
  description: "Reopen a closed ticket",

  async execute(message) {
    const ticket = await Ticket.findOne({
      Channel: message.channel.id,
      Guild: message.guild.id
    });

    if (!ticket)
      return message.reply("❌ This is not a registered ticket.");

    if (ticket.Status !== "closed")
      return message.reply("❌ Ticket is already open.");

    ticket.Status = "open";
    await ticket.save();

    const category = await TicketCategory.findById(ticket.CategoryId);

    if (category?.OpenCategory) {
      const cat = message.guild.channels.cache.get(category.OpenCategory);
      if (cat) message.channel.setParent(cat.id).catch(() => {});
    }

    message.reply(
      `<a:ticket:1414311755311484958> Ticket reopened successfully!`
    );
  }
};