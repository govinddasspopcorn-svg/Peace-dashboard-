const {
  EmbedBuilder,
  MessageFlags,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle,
  PermissionsBitField,
  StringSelectMenuBuilder,
} = require("discord.js");
const AntiCaps = require("../../schema/anticaps");

module.exports = {
  name: "anticaps",
  aliases: ["antiscream", "capslimit"],
  description: "Prevent excessive caps lock usage in messages.",
  category: "Automod",
  userPerms: ["ManageGuild"],
  botPerms: ["ManageMessages", "ModerateMembers"],
  cooldown: 3,
  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
      return message.reply("You need `Manage Guild` permissions to use this command.");
    }

    const guildId = message.guild.id;

    let antiCapsData = await AntiCaps.findOne({ guildId });
    if (!antiCapsData) {
      antiCapsData = new AntiCaps({ guildId });
      await antiCapsData.save();
    }

    const mainMenuEmbed = new EmbedBuilder()
      .setTitle("Anti-Caps System")
      .setDescription("Prevent excessive CAPS LOCK spam in your server!\n\nChoose an option to configure:")
      .setColor("#5865F2");

    const mainMenuRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("toggle").setLabel("Enable/Disable").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId("manage_threshold").setLabel("Set Threshold").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("manage_punishment").setLabel("Set Punishment").setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId("manage_whitelist").setLabel("Manage Whitelist").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("view_config").setLabel("View Config").setStyle(ButtonStyle.Primary),
    );

    const mainMessage = await message.reply({ embeds: [mainMenuEmbed], components: [mainMenuRow] });

    const collector = mainMessage.createMessageComponentCollector({ time: 120000 });

    collector.on("collect", async (interaction) => {
      if (interaction.user.id !== message.author.id) {
        return interaction.reply({ content: "This menu is not for you.", flags: MessageFlags.Ephemeral });
      }

      switch (interaction.customId) {
        case "toggle": {
          antiCapsData.isEnabled = !antiCapsData.isEnabled;
          await antiCapsData.save();

          const toggleEmbed = new EmbedBuilder()
            .setTitle("Anti-Caps System")
            .setDescription(`The Anti-Caps system has been **${antiCapsData.isEnabled ? "enabled" : "disabled"}**.`)
            .setColor("#5865F2");

          await interaction.update({ embeds: [toggleEmbed], components: [] });
          break;
        }

        case "manage_threshold": {
          const thresholdEmbed = new EmbedBuilder()
            .setTitle("Set Caps Lock Threshold")
            .setDescription("Reply with the **percentage** of caps allowed (1-100):\n\nExample: `70` (70% of message can be caps)\n*Messages under 5 characters are ignored*")
            .setColor("#5865F2");

          await interaction.update({ embeds: [thresholdEmbed], components: [] });

          const filter = (res) => res.author.id === message.author.id;
          const thresholdCollector = message.channel.createMessageCollector({ filter, time: 30000, max: 1 });

          thresholdCollector.on("collect", async (res) => {
            const threshold = parseInt(res.content.trim());
            if (!threshold || threshold < 1 || threshold > 100) {
              return res.reply("Invalid percentage. Please provide a number between 1 and 100.");
            }

            antiCapsData.capsPercentage = threshold;
            await antiCapsData.save();

            await res.reply(`✅ Caps threshold set to **${threshold}%** of the message.`);
          });

          break;
        }

        case "manage_punishment": {
          const punishmentMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
              .setCustomId("punishment_select")
              .setPlaceholder("Choose a punishment...")
              .addOptions(
                {
                  label: "Delete Message",
                  value: "delete",
                  description: "Only delete the caps message",
                  emoji: "🗑️"
                },
                {
                  label: "Warn",
                  value: "warn",
                  description: "Warn the user",
                  emoji: "⚠️"
                },
                {
                  label: "Timeout (5 min)",
                  value: "timeout",
                  description: "Timeout user for 5 minutes",
                  emoji: "⏱️"
                },
                {
                  label: "Mute (10 min)",
                  value: "mute",
                  description: "Mute user for 10 minutes",
                  emoji: "🔇"
                },
              ),
          );

          await interaction.update({ 
            embeds: [new EmbedBuilder().setTitle("Select Punishment").setColor("#5865F2").setDescription("Choose what happens when someone exceeds the caps limit:")], 
            components: [punishmentMenu] 
          });

          const selectCollector = mainMessage.createMessageComponentCollector({
            time: 30000,
            filter: (i) => i.user.id === message.author.id && i.customId === "punishment_select",
            max: 1
          });

          selectCollector.on("collect", async (select) => {
            const punishment = select.values[0];
            antiCapsData.punishment = punishment;
            await antiCapsData.save();

            const punishmentNames = {
              delete: "Delete Message",
              warn: "Warn User",
              timeout: "Timeout (5 minutes)",
              mute: "Mute (10 minutes)"
            };

            await select.update({ 
              content: `✅ Punishment set to: **${punishmentNames[punishment]}**`,
              embeds: [],
              components: [] 
            });
          });

          break;
        }

        case "view_config": {
          const whitelistedUsers = antiCapsData.whitelistUsers || [];
          const whitelistedRoles = antiCapsData.whitelistRoles || [];

          const configEmbed = new EmbedBuilder()
            .setTitle("Anti-Caps Configuration")
            .setColor("#5865F2")
            .addFields(
              {
                name: "System Status",
                value: antiCapsData.isEnabled ? "✅ Enabled" : "❌ Disabled",
                inline: true
              },
              {
                name: "Caps Threshold",
                value: `${antiCapsData.capsPercentage || 70}% of message`,
                inline: true
              },
              {
                name: "Punishment",
                value: antiCapsData.punishment || "delete",
                inline: true
              },
              {
                name: "Whitelisted Users",
                value: whitelistedUsers.length ? whitelistedUsers.map((id) => `<@${id}>`).join(", ") : "None",
              },
              {
                name: "Whitelisted Roles",
                value: whitelistedRoles.length ? whitelistedRoles.map((id) => `<@&${id}>`).join(", ") : "None",
              },
            );

          await interaction.update({ embeds: [configEmbed], components: [] });
          break;
        }

        case "manage_whitelist": {
          const whitelistEmbed = new EmbedBuilder()
            .setTitle("Whitelist Manager")
            .setDescription("Select whether to manage **users** or **roles**.")
            .setColor("#5865F2");

          const whitelistMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
              .setCustomId("whitelist_select")
              .setPlaceholder("Choose a whitelist type...")
              .addOptions(
                {
                  label: "Whitelist User",
                  value: "user",
                  description: "Add or remove users from the whitelist",
                },
                {
                  label: "Whitelist Role",
                  value: "role",
                  description: "Add or remove roles from the whitelist",
                },
              ),
          );

          await interaction.update({ embeds: [whitelistEmbed], components: [whitelistMenu] });

          const selectCollector = mainMessage.createMessageComponentCollector({
            time: 30000,
            filter: (i) => i.user.id === message.author.id && i.customId === "whitelist_select",
            max: 1
          });

          selectCollector.on("collect", async (select) => {
            const type = select.values[0];
            const promptText =
              type === "user"
                ? "Mention the user(s) you want to **add/remove** from the whitelist."
                : "Mention the role(s) you want to **add/remove** from the whitelist.";

            await select.update({ content: promptText, embeds: [], components: [] });

            const mentionCollector = message.channel.createMessageCollector({
              filter: (m) => m.author.id === message.author.id,
              time: 30000,
              max: 1
            });

            mentionCollector.on("collect", async (res) => {
              const mentions = type === "user" ? res.mentions.users : res.mentions.roles;

              if (!mentions.size) return res.reply("❌ No valid mentions found.");

              const field = type === "user" ? "whitelistUsers" : "whitelistRoles";
              const currentList = antiCapsData[field] || [];

              mentions.forEach((entity) => {
                const id = entity.id;
                if (currentList.includes(id)) {
                  antiCapsData[field] = currentList.filter((x) => x !== id);
                } else {
                  antiCapsData[field].push(id);
                }
              });

              await antiCapsData.save();

              res.reply(`✅ Whitelist updated for ${type}(s).`);
            });
          });

          break;
        }
      }
    });

    collector.on("end", () => {
      mainMessage.edit({ components: [] }).catch(() => {});
    });
  },
};
