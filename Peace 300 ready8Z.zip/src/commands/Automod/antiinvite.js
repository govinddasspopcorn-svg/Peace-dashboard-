const {
  EmbedBuilder,
  MessageFlags,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle,
  PermissionsBitField,
  StringSelectMenuBuilder,
} = require("discord.js");
const AntiInvite = require("../../schema/antiinvite");

module.exports = {
  name: "antiinvite",
  aliases: ["antiinv", "noinvites"],
  description: "Prevent Discord invite links from being posted.",
  category: "Automod",
  userPerms: ["ManageGuild"],
  botPerms: ["ManageMessages", "ModerateMembers"],
  cooldown: 3,
  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
      return message.reply("You need `Manage Guild` permissions to use this command.");
    }

    const guildId = message.guild.id;

    let antiInviteData = await AntiInvite.findOne({ guildId });
    if (!antiInviteData) {
      antiInviteData = new AntiInvite({ guildId });
      await antiInviteData.save();
    }

    const mainMenuEmbed = new EmbedBuilder()
      .setTitle("Anti-Invite System")
      .setDescription("Prevent unwanted Discord invite links!\n\nChoose an option to configure:")
      .setColor("#5865F2");

    const mainMenuRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("toggle").setLabel("Enable/Disable").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId("manage_punishment").setLabel("Set Punishment").setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId("manage_whitelist").setLabel("Manage Whitelist").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("view_config").setLabel("View Config").setStyle(ButtonStyle.Primary),
    );

    const mainMessage = await message.reply({ embeds: [mainMenuEmbed], components: [mainMenuRow] });

    const collector = mainMessage.createMessageComponentCollector({ time: 120000 });

    collector.on("collect", async (interaction) => {
      if (interaction.user.id !== message.author.id) {
        return interaction.reply({ content: "This menu is not for you.", flags: MessageFlags.Ephemeral });
      }

      switch (interaction.customId) {
        case "toggle": {
          antiInviteData.isEnabled = !antiInviteData.isEnabled;
          await antiInviteData.save();

          const toggleEmbed = new EmbedBuilder()
            .setTitle("Anti-Invite System")
            .setDescription(`The Anti-Invite system has been **${antiInviteData.isEnabled ? "enabled" : "disabled"}**.`)
            .setColor("#5865F2");

          await interaction.update({ embeds: [toggleEmbed], components: [] });
          break;
        }

        case "manage_punishment": {
          const punishmentMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
              .setCustomId("punishment_select")
              .setPlaceholder("Choose a punishment...")
              .addOptions(
                {
                  label: "Delete Message",
                  value: "delete",
                  description: "Only delete the message with invite",
                  emoji: "🗑️"
                },
                {
                  label: "Warn",
                  value: "warn",
                  description: "Warn the user",
                  emoji: "⚠️"
                },
                {
                  label: "Timeout (15 min)",
                  value: "timeout",
                  description: "Timeout user for 15 minutes",
                  emoji: "⏱️"
                },
                {
                  label: "Kick",
                  value: "kick",
                  description: "Kick the user from server",
                  emoji: "👢"
                },
              ),
          );

          await interaction.update({ 
            embeds: [new EmbedBuilder().setTitle("Select Punishment").setColor("#5865F2").setDescription("Choose what happens when someone posts an invite link:")], 
            components: [punishmentMenu] 
          });

          const selectCollector = mainMessage.createMessageComponentCollector({
            time: 30000,
            filter: (i) => i.user.id === message.author.id && i.customId === "punishment_select",
            max: 1
          });

          selectCollector.on("collect", async (select) => {
            const punishment = select.values[0];
            antiInviteData.punishment = punishment;
            await antiInviteData.save();

            const punishmentNames = {
              delete: "Delete Message",
              warn: "Warn User",
              timeout: "Timeout (15 minutes)",
              kick: "Kick User"
            };

            await select.update({ 
              content: `✅ Punishment set to: **${punishmentNames[punishment]}**`,
              embeds: [],
              components: [] 
            });
          });

          break;
        }

        case "view_config": {
          const whitelistedUsers = antiInviteData.whitelistUsers || [];
          const whitelistedRoles = antiInviteData.whitelistRoles || [];
          const whitelistedChannels = antiInviteData.whitelistChannels || [];

          const configEmbed = new EmbedBuilder()
            .setTitle("Anti-Invite Configuration")
            .setColor("#5865F2")
            .addFields(
              {
                name: "System Status",
                value: antiInviteData.isEnabled ? "✅ Enabled" : "❌ Disabled",
                inline: true
              },
              {
                name: "Punishment",
                value: antiInviteData.punishment || "delete",
                inline: true
              },
              {
                name: "Detection",
                value: "discord.gg/* links",
                inline: true
              },
              {
                name: "Whitelisted Users",
                value: whitelistedUsers.length ? whitelistedUsers.map((id) => `<@${id}>`).join(", ") : "None",
              },
              {
                name: "Whitelisted Roles",
                value: whitelistedRoles.length ? whitelistedRoles.map((id) => `<@&${id}>`).join(", ") : "None",
              },
              {
                name: "Whitelisted Channels",
                value: whitelistedChannels.length ? whitelistedChannels.map((id) => `<#${id}>`).join(", ") : "None",
              },
            );

          await interaction.update({ embeds: [configEmbed], components: [] });
          break;
        }

        case "manage_whitelist": {
          const whitelistEmbed = new EmbedBuilder()
            .setTitle("Whitelist Manager")
            .setDescription("Select what to whitelist.")
            .setColor("#5865F2");

          const whitelistMenu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
              .setCustomId("whitelist_select")
              .setPlaceholder("Choose a whitelist type...")
              .addOptions(
                {
                  label: "Whitelist User",
                  value: "user",
                  description: "Add or remove users from the whitelist",
                },
                {
                  label: "Whitelist Role",
                  value: "role",
                  description: "Add or remove roles from the whitelist",
                },
                {
                  label: "Whitelist Channel",
                  value: "channel",
                  description: "Add or remove channels from the whitelist",
                },
              ),
          );

          await interaction.update({ embeds: [whitelistEmbed], components: [whitelistMenu] });

          const selectCollector = mainMessage.createMessageComponentCollector({
            time: 30000,
            filter: (i) => i.user.id === message.author.id && i.customId === "whitelist_select",
            max: 1
          });

          selectCollector.on("collect", async (select) => {
            const type = select.values[0];
            let promptText = "";
            
            if (type === "user") {
              promptText = "Mention the user(s) you want to **add/remove** from the whitelist.";
            } else if (type === "role") {
              promptText = "Mention the role(s) you want to **add/remove** from the whitelist.";
            } else {
              promptText = "Mention the channel(s) you want to **add/remove** from the whitelist.";
            }

            await select.update({ content: promptText, embeds: [], components: [] });

            const mentionCollector = message.channel.createMessageCollector({
              filter: (m) => m.author.id === message.author.id,
              time: 30000,
              max: 1
            });

            mentionCollector.on("collect", async (res) => {
              let mentions;
              
              if (type === "user") {
                mentions = res.mentions.users;
              } else if (type === "role") {
                mentions = res.mentions.roles;
              } else {
                mentions = res.mentions.channels;
              }

              if (!mentions.size) return res.reply("❌ No valid mentions found.");

              const field = type === "user" ? "whitelistUsers" : type === "role" ? "whitelistRoles" : "whitelistChannels";
              const currentList = antiInviteData[field] || [];

              mentions.forEach((entity) => {
                const id = entity.id;
                if (currentList.includes(id)) {
                  antiInviteData[field] = currentList.filter((x) => x !== id);
                } else {
                  antiInviteData[field].push(id);
                }
              });

              await antiInviteData.save();

              res.reply(`✅ Whitelist updated for ${type}(s).`);
            });
          });

          break;
        }
      }
    });

    collector.on("end", () => {
      mainMessage.edit({ components: [] }).catch(() => {});
    });
  },
};
