const { 
  PermissionsBitField, 
  ChannelType, 
  ActionRowBuilder, 
  StringSelectMenuBuilder, 
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType
} = require("discord.js");
const AntiNuke = require("../../schema/antinuke");

module.exports = {
  name: "antinuke",
  aliases: ["antiwizz", "an"],
  category: "Antinuke",
  description: "Advanced Antinuke Management System",
  execute: async (message, args, client, prefix) => {
    const authorId = message.author.id;

    try {
      let config = await AntiNuke.findOne({ guildId: message.guild.id });
      if (!config) {
        config = new AntiNuke({ guildId: message.guild.id });
        await config.save();
      }

      const isAuthorized = authorId === message.guild.ownerId || 
                           authorId === client.owner || 
                           (config.extraOwners || []).includes(authorId);

      if (!isAuthorized) {
        return message.reply({
          embeds: [new EmbedBuilder()
            .setColor(client.colors.error)
            .setDescription(`${client.emoji.cross} | Only authorized users can manage Antinuke.`)
          ],
        });
      }

      if (!config.logChannelId) {
        let logChan = message.guild.channels.cache.find(c => c.name === "peace-logs");
        if (!logChan) {
          logChan = await message.guild.channels.create({
            name: "peace-logs",
            type: ChannelType.GuildText,
            permissionOverwrites: [
              {
                id: message.guild.id,
                deny: [PermissionsBitField.Flags.ViewChannel],
              },
            ],
            reason: "Peace Antinuke: Auto Log Channel Creation"
          }).catch(() => null);
        }
        if (logChan) {
          config.logChannelId = logChan.id;
          await config.save();
        }
      }

      const generateMainEmbed = () => {
        return new EmbedBuilder()
          .setAuthor({ name: `${client.user.username} Antinuke`, iconURL: client.user.displayAvatarURL() })
          .setColor(config.isEnabled ? client.colors.success : client.colors.error)
          .setDescription(
            `🛡️ **Antinuke Security Status**\n\n` +
            `> **Main System:** ${config.isEnabled ? `${client.emoji.tick} Enabled` : `${client.emoji.cross} Disabled`}\n` +
            `> **Log Channel:** ${config.logChannelId ? `<#${config.logChannelId}>` : "None"}\n` +
            `> **Punishment:** \`${config.punishment.toUpperCase()}\`\n\n` +
            `Select an option from the dropdown below to configure your security.`
          )
          .setThumbnail(message.guild.iconURL({ dynamic: true }))
          .setFooter({ text: "Peace Security • Advanced Protection", iconURL: client.user.displayAvatarURL() });
      };

      const mainRow = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId("an_setup_menu")
          .setPlaceholder("Configure Antinuke")
          .addOptions([
            { label: "Enable Antinuke", value: "enable", description: "Turn on the security system", emoji: "🛡️" },
            { label: "Disable Antinuke", value: "disable", description: "Turn off the security system", emoji: "🔓" },
            { label: "Event Settings", value: "events", description: "Manage specific protections", emoji: "⚙️" },
            { label: "Punishment", value: "punishment", description: "Set the penalty for nukers", emoji: "🔨" }
          ])
      );

      const msg = await message.reply({ embeds: [generateMainEmbed()], components: [mainRow] });

      const collector = msg.createMessageComponentCollector({
        filter: (i) => i.user.id === authorId,
        time: 300000
      });

      collector.on("collect", async (interaction) => {
        if (interaction.customId === "an_setup_menu") {
          const value = interaction.values[0];

          if (value === "enable") {
            config.isEnabled = true;
            await config.save();
            return interaction.update({ embeds: [generateMainEmbed()], components: [mainRow] });
          }

          if (value === "disable") {
            config.isEnabled = false;
            await config.save();
            return interaction.update({ embeds: [generateMainEmbed()], components: [mainRow] });
          }

          if (value === "events") {
            const options = Object.keys(config.events).map(e => ({
              label: `Anti-${e}`,
              value: e,
              description: config.events[e] ? "Status: Enabled" : "Status: Disabled",
              emoji: config.events[e] ? client.emoji.tick : client.emoji.cross
            }));

            const eventRow = new ActionRowBuilder().addComponents(
              new StringSelectMenuBuilder()
                .setCustomId("an_event_toggle_multi")
                .setPlaceholder("Select Events to Toggle")
                .addOptions(options)
            );

            const backButton = new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId("an_home").setLabel("Back to Home").setStyle(ButtonStyle.Secondary)
            );

            return interaction.update({ 
              content: "Manage individual security modules:", 
              embeds: [], 
              components: [eventRow, backButton] 
            });
          }

          if (value === "punishment") {
            const punishRow = new ActionRowBuilder().addComponents(
              new StringSelectMenuBuilder()
                .setCustomId("an_punish_set")
                .setPlaceholder("Choose Punishment")
                .addOptions([
                  { label: "Ban", value: "ban", emoji: "🔨" },
                  { label: "Kick", value: "kick", emoji: "👢" },
                  { label: "None (Logs)", value: "none", emoji: "📑" }
                ])
            );
            return interaction.update({ content: "Select what happens to unauthorized actors:", components: [punishRow] });
          }
        }

        if (interaction.customId === "an_event_toggle_multi") {
          const event = interaction.values[0];
          config.events[event] = !config.events[event];
          await config.save();
          
          const options = Object.keys(config.events).map(e => ({
            label: `Anti-${e}`,
            value: e,
            description: config.events[e] ? "Status: Enabled" : "Status: Disabled",
            emoji: config.events[e] ? client.emoji.tick : client.emoji.cross
          }));

          const eventRow = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
              .setCustomId("an_event_toggle_multi")
              .setPlaceholder("Select Events to Toggle")
              .addOptions(options)
          );

          return interaction.update({ components: [eventRow, interaction.message.components[1]] });
        }

        if (interaction.customId === "an_punish_set") {
          config.punishment = interaction.values[0];
          await config.save();
          return interaction.update({ embeds: [generateMainEmbed()], components: [mainRow], content: null });
        }

        if (interaction.customId === "an_home") {
          return interaction.update({ embeds: [generateMainEmbed()], components: [mainRow], content: null });
        }
      });

    } catch (error) {
      console.error(error);
      message.reply("Critical error in Antinuke system.");
    }
  },
};
