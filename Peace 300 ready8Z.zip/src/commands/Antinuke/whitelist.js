const { 
  EmbedBuilder, 
  ActionRowBuilder, 
  StringSelectMenuBuilder,
  UserSelectMenuBuilder
} = require("discord.js");
const Antinuke = require("../../schema/antinuke");

module.exports = {
  name: "whitelist",
  aliases: ["wl"],
  description: "Advanced Event-Wise Whitelist Management",
  category: "Antinuke",
  execute: async (message, args, client, prefix) => {
    const authorId = message.author.id;
    let config = await Antinuke.findOne({ guildId: message.guild.id });

    if (!config) {
      config = new Antinuke({ guildId: message.guild.id });
      await config.save();
    }

    const isAuthorized = authorId === message.guild.ownerId || 
                         authorId === client.owner || 
                         (config.extraOwners || []).includes(authorId);

    if (!isAuthorized) return message.reply({ embeds: [new EmbedBuilder().setColor(client.colors.error).setDescription(`${client.emoji.cross} | Only Server Owner can manage whitelist.`)] });

    const generateWLEmbed = () => {
      return new EmbedBuilder()
        .setAuthor({ name: "Whitelist Management", iconURL: client.user.displayAvatarURL() })
        .setColor(client.colors.primary)
        .setDescription(
          `🛡️ **Event-Wise Whitelist**\n\n` +
          `Select an event from the menu below to manage users who are permitted to perform that action without being punished.`
        )
        .setFooter({ text: "Peace Security System" });
    };

    const events = Object.keys(config.events);
    const eventRow = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("wl_event_select")
        .setPlaceholder("Choose Protection Event")
        .addOptions(events.map(e => ({ 
          label: `Anti-${e}`, 
          value: e,
          description: `Manage whitelist for ${e} actions`
        })))
    );

    const msg = await message.reply({ embeds: [generateWLEmbed()], components: [eventRow] });

    const collector = msg.createMessageComponentCollector({ time: 300000 });

    collector.on("collect", async (interaction) => {
      if (interaction.customId === "wl_event_select") {
        const selectedEvent = interaction.values[0];
        
        const userRow = new ActionRowBuilder().addComponents(
          new UserSelectMenuBuilder()
            .setCustomId(`wl_user_add_${selectedEvent}`)
            .setPlaceholder(`Select users for ${selectedEvent}`)
            .setMaxValues(10)
        );

        await interaction.update({ 
          content: `👤 **Managing Whitelist for:** \`Anti-${selectedEvent}\``,
          embeds: [],
          components: [userRow]
        });
      }

      if (interaction.customId.startsWith("wl_user_add_")) {
        const event = interaction.customId.split("_").pop();
        const users = interaction.values;
        
        config.whitelistedEvents.set(event, users);
        await config.save();
        
        await interaction.update({ 
          content: `${client.emoji.tick} | Successfully updated whitelist for **Anti-${event}**.`, 
          components: [eventRow] 
        });
      }
    });
  }
};
