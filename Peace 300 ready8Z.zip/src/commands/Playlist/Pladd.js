const { EmbedBuilder } = require("discord.js");
const db = require("../../schema/playlist");

module.exports = {
  name: "pladd",
  aliases: ["playlistadd"],
  category: "Playlist",
  args: true,
  usage: "pladd <playlist name>",
  player: true,
  inVoiceChannel: true,
  sameVoiceChannel: true,

  execute: async (message, args, client) => {
    const Name = args[0];

    const data = await db.findOne({
      UserId: message.author.id,
      PlaylistName: Name,
    });

    if (!data) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("2f3136")
            .setDescription(
              `${client.emoji.cross} | Playlist **${Name}** not found`
            ),
        ],
      });
    }

    const player = client.manager.players.get(message.guild.id);
    if (!player || !player.queue.current) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("2f3136")
            .setDescription(
              `${client.emoji.cross} | No song is currently playing`
            ),
        ],
      });
    }

    const track = player.queue.current;

    await db.updateOne(
      {
        UserId: message.author.id,
        PlaylistName: Name,
      },
      {
        $push: {
          Playlist: {
            title: track.title,
            uri: track.uri,
            author: track.author,
            duration: track.duration,
          },
        },
      }
    );

    return message.channel.send({
      embeds: [
        new EmbedBuilder()
          .setColor("2f3136")
          .setDescription(
            `${client.emoji.tick} | Added **${track.title}** to **${Name}**`
          ),
      ],
    });
  },
};