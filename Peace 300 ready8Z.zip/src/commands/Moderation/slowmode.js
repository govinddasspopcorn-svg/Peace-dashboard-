module.exports = {
  name: "slowmode",
  category: "Moderation",
  description: "Set the slowmode for a channel",
  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has("ManageChannels")) {
      return message.reply(`${client.emoji.cross} You need \`Manage Channels\` permission.`);
    }
    const time = args[0];
    if (!time) {
      return message.channel.setRateLimitPerUser(0)
        .then(() => message.reply(`${client.emoji.tick} Slowmode has been disabled.`));
    }
    if (isNaN(time)) return message.reply(`${client.emoji.cross} Please provide a valid number of seconds.`);
    
    message.channel.setRateLimitPerUser(parseInt(time))
      .then(() => message.reply(`${client.emoji.tick} Slowmode set to **${time}** seconds.`))
      .catch(e => message.reply(`${client.emoji.cross} Failed to set slowmode.`));
  },
};