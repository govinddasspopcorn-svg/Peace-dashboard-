const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const Warnings = require("../../schema/warnings");
const WarnSettings = require("../../schema/warnsettings");
const { randomUUID } = require("crypto");

module.exports = {
  name: "warn",
  category: "Moderation",
  aliases: ["warning"],
  cooldown: 3,
  description: "Warn a user with automatic punishments based on warn count",
  args: true,
  usage: "<@user> [reason]",
  userPerms: ["ModerateMembers"],
  botPerms: ["ModerateMembers", "KickMembers", "BanMembers"],
  owner: false,

  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | You need \`Moderate Members\` permission to use this command.`)
        ]
      });
    }

    const user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
    if (!user) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | Please mention a valid user to warn.\n**Usage:** \`${prefix}warn <@user> [reason]\``)
        ]
      });
    }

    const member = await message.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | User not found in this server.`)
        ]
      });
    }

    if (member.id === message.author.id) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | You cannot warn yourself!`)
        ]
      });
    }

    if (member.id === client.user.id) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | I cannot be warned!`)
        ]
      });
    }

    if (member.roles.highest.position >= message.member.roles.highest.position) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | You cannot warn someone with equal or higher role!`)
        ]
      });
    }

    const reason = args.slice(1).join(" ") || "No reason provided";
    const warnId = randomUUID().split("-")[0];

    // Get or create warnings document
    let warningsDoc = await Warnings.findOne({ guildId: message.guild.id, userId: user.id });
    if (!warningsDoc) {
      warningsDoc = new Warnings({
        guildId: message.guild.id,
        userId: user.id,
        warnings: [],
        punishments: []
      });
    }

    // Get warn settings
    let warnSettings = await WarnSettings.findOne({ guildId: message.guild.id });
    if (!warnSettings) {
      warnSettings = new WarnSettings({ guildId: message.guild.id });
      await warnSettings.save();
    }

    // Check if we need to reset daily warns
    if (warnSettings.resetDaily) {
      const now = Date.now();
      const lastReset = warnSettings.lastReset || 0;
      const dayInMs = 24 * 60 * 60 * 1000;
      
      if (now - lastReset > dayInMs) {
        // Reset all warns for this guild
        await Warnings.updateMany(
          { guildId: message.guild.id },
          { warnings: [], punishments: [] }
        );
        warnSettings.lastReset = now;
        await warnSettings.save();
        
        warningsDoc.warnings = [];
        warningsDoc.punishments = [];
      }
    }

    // Add new warning
    warningsDoc.warnings.push({
      warnId: warnId,
      reason: reason,
      moderator: message.author.id,
      timestamp: Date.now()
    });

    const warnCount = warningsDoc.warnings.length;

    // Check for auto-punishment
    const punishmentMap = warnSettings.punishments || new Map([
      ['3', 'timeout'],
      ['5', 'kick'],
      ['7', 'ban']
    ]);

    let punishmentApplied = null;
    const punishmentType = punishmentMap.get(warnCount.toString());

    if (punishmentType) {
      try {
        switch (punishmentType) {
          case "timeout":
            await member.timeout(5 * 60 * 1000, `Auto-punishment: ${warnCount} warnings`);
            punishmentApplied = "Timeout (5 minutes)";
            warningsDoc.punishments.push({
              type: "timeout",
              reason: `${warnCount} warnings reached`,
              timestamp: Date.now()
            });
            break;

          case "kick":
            await member.kick(`Auto-punishment: ${warnCount} warnings`);
            punishmentApplied = "Kicked from server";
            warningsDoc.punishments.push({
              type: "kick",
              reason: `${warnCount} warnings reached`,
              timestamp: Date.now()
            });
            break;

          case "ban":
            await member.ban({ reason: `Auto-punishment: ${warnCount} warnings` });
            punishmentApplied = "Banned from server";
            warningsDoc.punishments.push({
              type: "ban",
              reason: `${warnCount} warnings reached`,
              timestamp: Date.now()
            });
            break;
        }
      } catch (error) {
        console.error("Error applying punishment:", error);
      }
    }

    await warningsDoc.save();

    // DM the user
    try {
      await user.send({
        embeds: [
          new EmbedBuilder()
            .setTitle(`⚠️ You've been warned in ${message.guild.name}`)
            .setColor(client.colors.warning)
            .addFields(
              { name: "Reason", value: reason, inline: false },
              { name: "Moderator", value: message.author.tag, inline: true },
              { name: "Warn Count", value: `${warnCount}`, inline: true },
              { name: "Warn ID", value: `\`${warnId}\``, inline: true }
            )
            .setTimestamp()
        ]
      });
    } catch (e) {
      // User has DMs disabled
    }

    // Send confirmation
    const embed = new EmbedBuilder()
      .setColor(client.colors.warning)
      .setTitle("⚠️ User Warned")
      .addFields(
        { name: "User", value: `${user.tag} (${user.id})`, inline: true },
        { name: "Moderator", value: message.author.tag, inline: true },
        { name: "Warn Count", value: `${warnCount}`, inline: true },
        { name: "Reason", value: reason, inline: false },
        { name: "Warn ID", value: `\`${warnId}\``, inline: true }
      )
      .setFooter({
        text: `✨ Warned by ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    if (punishmentApplied) {
      embed.addFields({
        name: "🔨 Auto-Punishment Applied",
        value: punishmentApplied,
        inline: false
      });
    }

    message.reply({ embeds: [embed] });
  }
};
