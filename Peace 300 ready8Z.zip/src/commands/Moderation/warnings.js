const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const Warnings = require("../../schema/warnings");

module.exports = {
  name: "warnings",
  category: "Moderation",
  aliases: ["warns", "warnlist"],
  cooldown: 3,
  description: "View all warnings for a user",
  args: false,
  usage: "[@user]",
  userPerms: ["ModerateMembers"],
  botPerms: [],
  owner: false,

  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | You need \`Moderate Members\` permission to use this command.`)
        ]
      });
    }

    const user = message.mentions.users.first() || 
                 await client.users.fetch(args[0]).catch(() => null) || 
                 message.author;

    const warningsDoc = await Warnings.findOne({ 
      guildId: message.guild.id, 
      userId: user.id 
    });

    if (!warningsDoc || warningsDoc.warnings.length === 0) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.tick} | ${user.tag} has no warnings!`)
        ]
      });
    }

    const warnings = warningsDoc.warnings
      .sort((a, b) => b.timestamp - a.timestamp)
      .slice(0, 10);

    const warningList = warnings.map((w, i) => 
      `**${i + 1}.** <t:${Math.floor(w.timestamp / 1000)}:R>\n` +
      `**Moderator:** <@${w.moderator}>\n` +
      `**Reason:** ${w.reason}\n` +
      `**ID:** \`${w.warnId}\``
    ).join("\n\n");

    const embed = new EmbedBuilder()
      .setTitle(`⚠️ Warnings for ${user.tag}`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setColor(client.colors.warning)
      .setDescription(
        `**Total Warnings:** ${warningsDoc.warnings.length}\n` +
        `**Total Punishments:** ${warningsDoc.punishments.length}\n\n` +
        `**Recent Warnings:**\n${warningList}`
      )
      .setFooter({
        text: `✨ Requested by ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  }
};
