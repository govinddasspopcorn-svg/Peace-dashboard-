module.exports = {
  name: "moveall",
  category: "Moderation",
  description: "Move all members from one voice channel to another",
  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has("MoveMembers")) return message.reply(`${client.emoji.cross} You need \`Move Members\` permission.`);
    const fromChannel = message.guild.channels.cache.get(args[0]) || message.member.voice.channel;
    const toChannel = message.guild.channels.cache.get(args[1]);
    if (!fromChannel || fromChannel.type !== 2) return message.reply(`${client.emoji.cross} Please provide a valid source voice channel.`);
    if (!toChannel || toChannel.type !== 2) return message.reply(`${client.emoji.cross} Please provide a valid target voice channel.`);
    
    fromChannel.members.forEach(member => {
      member.voice.setChannel(toChannel).catch(() => {});
    });
    message.reply(`${client.emoji.tick} Moving everyone from **${fromChannel.name}** to **${toChannel.name}**`);
  },
};