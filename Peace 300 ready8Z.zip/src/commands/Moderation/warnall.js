module.exports = {
  name: "warnall",
  category: "Moderation",
  description: "Warn all users mentioned",
  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has("ModerateMembers")) return message.reply(`${client.emoji.cross} You need permission.`);
    const members = message.mentions.members;
    if (members.size === 0) return message.reply(`${client.emoji.cross} Please mention members to warn.`);
    
    message.reply(`${client.emoji.tick} Warned ${members.size} members.`);
  },
};