const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const Warnings = require("../../schema/warnings");

module.exports = {
  name: "unwarn",
  category: "Moderation",
  aliases: ["removewarn", "delwarn"],
  cooldown: 3,
  description: "Remove a specific warning from a user",
  args: true,
  usage: "<@user> <warn_id>",
  userPerms: ["ModerateMembers"],
  botPerms: [],
  owner: false,

  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | You need \`Moderate Members\` permission to use this command.`)
        ]
      });
    }

    const user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
    if (!user) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | Please mention a valid user.\n**Usage:** \`${prefix}unwarn <@user> <warn_id>\``)
        ]
      });
    }

    const warnId = args[1];
    if (!warnId) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | Please provide a warning ID.\n**Usage:** \`${prefix}unwarn <@user> <warn_id>\``)
        ]
      });
    }

    const warningsDoc = await Warnings.findOne({ 
      guildId: message.guild.id, 
      userId: user.id 
    });

    if (!warningsDoc || warningsDoc.warnings.length === 0) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | ${user.tag} has no warnings!`)
        ]
      });
    }

    const warnIndex = warningsDoc.warnings.findIndex(w => w.warnId === warnId);
    if (warnIndex === -1) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | Warning ID not found!`)
        ]
      });
    }

    const removedWarn = warningsDoc.warnings[warnIndex];
    warningsDoc.warnings.splice(warnIndex, 1);
    await warningsDoc.save();

    const embed = new EmbedBuilder()
      .setColor(client.colors.success)
      .setTitle("✅ Warning Removed")
      .addFields(
        { name: "User", value: `${user.tag}`, inline: true },
        { name: "Moderator", value: message.author.tag, inline: true },
        { name: "Remaining Warnings", value: `${warningsDoc.warnings.length}`, inline: true },
        { name: "Removed Warning", value: removedWarn.reason, inline: false }
      )
      .setFooter({
        text: `✨ Removed by ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  }
};
