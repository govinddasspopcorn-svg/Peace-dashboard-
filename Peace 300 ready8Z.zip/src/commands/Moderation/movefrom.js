module.exports = {
  name: "movefrom",
  category: "Moderation",
  description: "Move all members from a specific voice channel to your current one",
  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has("MoveMembers")) return message.reply(`${client.emoji.cross} You need \`Move Members\` permission.`);
    const fromChannel = message.guild.channels.cache.get(args[0]);
    const toChannel = message.member.voice.channel;
    if (!fromChannel || fromChannel.type !== 2) return message.reply(`${client.emoji.cross} Please provide a source voice channel ID.`);
    if (!toChannel) return message.reply(`${client.emoji.cross} You must be in a voice channel.`);
    
    fromChannel.members.forEach(member => {
      member.voice.setChannel(toChannel).catch(() => {});
    });
    message.reply(`${client.emoji.tick} Moving everyone from **${fromChannel.name}** to your channel.`);
  },
};