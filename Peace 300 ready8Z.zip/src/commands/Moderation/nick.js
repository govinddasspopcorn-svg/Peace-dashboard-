const {
  EmbedBuilder,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle,
  PermissionsBitField
} = require("discord.js");

module.exports = {
  name: "nick",
  category: "Moderation",
  aliases: ["nickname", "setnick"],
  cooldown: 3,
  description: "Change a user's nickname",
  args: true,
  usage: "<user> <new nickname>",
  userPerms: ["ManageNicknames"],
  botPerms: ["ManageNicknames"],
  owner: false,

  execute: async (message, args, client, prefix) => {

    // USER PERMISSION CHECK
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageNicknames)) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | You need **Manage Nicknames** permission.`)
        ]
      });
    }

    // BOT PERMISSION CHECK
    if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageNicknames)) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | I need **Manage Nicknames** permission.`)
        ]
      });
    }

    // FETCH USER
    const member =
      message.mentions.members.first() ||
      message.guild.members.cache.get(args[0]);

    if (!member) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | Provide a valid user.`)
        ]
      });
    }

    // PREVENT CHANGING OWNER
    if (member.id === message.guild.ownerId) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | You cannot change the server owner's nickname.`)
        ]
      });
    }

    // PREVENT CHANGING BOT NICK
    if (member.id === client.user.id) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | Use **/nick** to change my nickname manually.`)
        ]
      });
    }

    // ROLE HIERARCHY CHECK — USER
    if (
      member.roles.highest.position >= message.member.roles.highest.position &&
      message.author.id !== message.guild.ownerId
    ) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | That user has a higher/equal role than you.`)
        ]
      });
    }

    // ROLE HIERARCHY CHECK — BOT
    if (member.roles.highest.position >= message.guild.members.me.roles.highest.position) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | That user has a higher/equal role than me.`)
        ]
      });
    }

    // GET NICKNAME
    const newNick = args.slice(1).join(" ");
    if (!newNick) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | Provide the new nickname.`)
        ]
      });
    }

    // CONFIRMATION BUTTONS
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("NICK_YES").setStyle(ButtonStyle.Success).setLabel("Yes"),
      new ButtonBuilder().setCustomId("NICK_NO").setStyle(ButtonStyle.Secondary).setLabel("No"),
    );

    const confirmMsg = await message.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(client.color)
          .setDescription(
            `Are you sure you want to change **${member.user.tag}'s** nickname to:\n**${newNick}**?`
          )
      ],
      components: [row],
    });

    const filter = (i) => i.user.id === message.author.id;
    const collector = confirmMsg.createMessageComponentCollector({
      filter,
      time: 30000,
      max: 1,
    });

    // BUTTON PRESS
    collector.on("collect", async (i) => {
      await i.deferUpdate();

      // RECHECK PERMISSIONS
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageNicknames)) {
        return confirmMsg.edit({
          components: [],
          embeds: [
            new EmbedBuilder()
              .setColor(client.color)
              .setDescription(`${client.emoji.cross} | You lost **Manage Nicknames** permission.`)
          ]
        });
      }

      if (i.customId === "NICK_NO") {
        return confirmMsg.edit({ components: [] });
      }

      // APPLY NICKNAME
      await member.setNickname(newNick).catch(() => null);

      confirmMsg.edit({
        components: [],
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(
              `${client.emoji.tick} | Successfully changed **${member.user.tag}**'s nickname to **${newNick}**.`
            )
        ]
      });
    });

    collector.on("end", () => {
      confirmMsg.edit({ components: [] }).catch(() => {});
    });
  },
};
