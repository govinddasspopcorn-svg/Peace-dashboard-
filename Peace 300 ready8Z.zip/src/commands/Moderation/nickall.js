module.exports = {
  name: "nickall",
  category: "Moderation",
  description: "Change nickname of all mentioned users",
  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has("ManageNicknames")) return message.reply("You need permission.");
    const members = message.mentions.members;
    const nick = args.slice(members.size).join(" ");
    if (members.size === 0 || !nick) return message.reply("Usage: `?nickall @user1 @user2 new_nick`.");
    
    members.forEach(m => m.setNickname(nick).catch(() => {}));
    message.reply(`${client.emoji.tick} Nicknames updated.`);
  },
};