const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
  name: "purgesticker",
  category: "Moderation",
  aliases: ["clearsticker", "deletesticker", "purgstickers"],
  cooldown: 3,
  description: "Delete messages containing stickers in bulk",
  args: true,
  usage: "<number_of_messages>",
  userPerms: ["ManageMessages"],
  botPerms: ["ManageMessages"],
  owner: false,

  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(
              `${client.emoji.cross} | You must have \`Manage Messages\` permissions to use this command.`
            ),
        ],
      });
    }

    const amount = parseInt(args[0]);
    if (!amount || isNaN(amount)) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(
              `${client.emoji.cross} | You must provide a valid number of messages to scan.\n**Usage:** \`${prefix}purgesticker <amount>\``
            ),
        ],
      });
    }

    if (amount < 1 || amount > 100) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(
              `${client.emoji.cross} | You can scan between 1 and 100 messages at a time.`
            ),
        ],
      });
    }

    try {
      const messages = await message.channel.messages.fetch({ limit: amount });
      const stickerMessages = messages.filter(msg => msg.stickers.size > 0);

      if (stickerMessages.size === 0) {
        return message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(client.color)
              .setDescription(
                `${client.emoji.cross} | No messages with stickers found in the last ${amount} messages.`
              ),
          ],
        });
      }

      await message.channel.bulkDelete(stickerMessages, true);
      
      return message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(
              `${client.emoji.tick} | Successfully deleted **${stickerMessages.size}** messages containing stickers.`
            ),
        ],
      });
    } catch (error) {
      console.error(error);
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(
              `${client.emoji.cross} | An error occurred while trying to delete sticker messages.`
            ),
        ],
      });
    }
  },
};
