module.exports = {
  name: "move",
  category: "Moderation",
  description: "Move a member to another voice channel",
  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has("MoveMembers")) return message.reply(`${client.emoji.cross} You need \`Move Members\` permission.`);
    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!member) return message.reply(`${client.emoji.cross} Please mention a member.`);
    if (!member.voice.channel) return message.reply(`${client.emoji.cross} That member is not in a voice channel.`);
    const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
    if (!channel || channel.type !== 2) return message.reply(`${client.emoji.cross} Please provide a valid voice channel.`);
    
    member.voice.setChannel(channel)
      .then(() => message.reply(`${client.emoji.tick} Moved **${member.user.tag}** to **${channel.name}**`))
      .catch(e => message.reply(`${client.emoji.cross} Failed to move member.`));
  },
};