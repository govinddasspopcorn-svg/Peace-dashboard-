const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "dhelp",
  category: "Drops",
  aliases: ["drophelp", "dcommands"],
  description: "Show all drop-related commands",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  cooldown: 5,

  execute: async (message, args, client, prefix) => {
    const embed = new EmbedBuilder()
      .setColor(client.color || "#00BFFF")
      .setTitle("🎁 Drop System Help")
      .setDescription("Here are all available drop commands and what they do.")
      .addFields(
        {
          name: "👤 User Commands",
          value: 
`**${prefix}dclaim** - Claim the active drop
**${prefix}dbal** - Check your drop balance & stats
**${prefix}droprewards** - View drop rewards & chances
**${prefix}dropleaderboard** - Top users by drops
**${prefix}withdrawrewards** - Info on how to withdraw rewards`,
          inline: false,
        },
        {
          name: "🛠️ Admin Commands",
          value: 
`**${prefix}dropchannel** - Set the drop channel
**${prefix}dropdisable** - Disable drops in the server
**${prefix}forcedrop** - Force spawn a drop
**${prefix}rain** - Enable/disable rain mode
**${prefix}giveowo** - Give OWO to a user
**${prefix}resetuser** - Reset a user's drop data`,
          inline: false,
        }
      )
      .setFooter({ text: `Use ${prefix} before each command name.` })
      .setTimestamp();

    return message.reply({ embeds: [embed] });
  },
};