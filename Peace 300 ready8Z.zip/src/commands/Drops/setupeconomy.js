module.exports = {
  name: "setupeconomy",
  ownerOnly: true,

  execute: async (message) => {
    message.reply(
      "✅ Economy system enabled:\n" +
      "• Rob system\n" +
      "• Bank protection\n" +
      "• Rob history\n" +
      "• Role protection\n" +
      "• Passive mode"
    );
  }
};