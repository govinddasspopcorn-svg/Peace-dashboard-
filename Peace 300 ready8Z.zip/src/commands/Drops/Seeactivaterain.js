const { EmbedBuilder } = require("discord.js");
const db = require("../../utils/dropsDB");

module.exports = {
  name: "seeactiverains",
  aliases: ["activerains", "rainsactive"],
  description: "View all servers currently in rain mode. (Owner Only)",
  category: "Drops",
  cooldown: 5,

  execute: async (message, args, client, prefix) => {
    // OWNER CHECK
    if (message.author.id !== process.env.OWNER_ID)
      return message.reply("❌ Only the **bot owner** can use this command.");

    const guilds = await db.getAllEnabledGuilds();
    const now = Date.now();

    const active = guilds.filter(g => g.rainMode && now < g.rainEndTime);

    const embed = new EmbedBuilder()
      .setColor("#00FF7F")
      .setTitle("🌧️ Active Rain Servers")
      .setTimestamp();

    if (active.length === 0) {
      embed.setDescription("❌ No servers currently have rain mode active.");
      return message.reply({ embeds: [embed] });
    }

    for (const g of active) {
      const fetchedGuild = client.guilds.cache.get(g.GuildId);
      if (!fetchedGuild) continue;

      embed.addFields({
        name: `🌧️ ${fetchedGuild.name}`,
        value:
          `• **Rain Ends:** <t:${Math.floor(g.rainEndTime / 1000)}:R>\n` +
          `• **Rain Channel:** <#${g.dropChannel}>`,
        inline: false,
      });
    }

    return message.reply({ embeds: [embed] });
  },
};