const db = require("../../utils/dropsDB.js");
const { formatNumber } = require("../../system/rarityChooser.js");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "dropleaderboard",
  category: "Drops",
  aliases: ["droplb", "owotop", "droptop"],
  description: "View the top drop collectors",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  cooldown: 10,
  execute: async (message, args, client, prefix) => {
    const leaderboard = await db.getLeaderboard(10);

    if (!leaderboard || leaderboard.length === 0) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`${client.emoji.cross} | No one has claimed any drops yet!`)
        ],
      });
    }

    let leaderboardText = "";
    const medals = ["🥇", "🥈", "🥉"];

    for (let i = 0; i < leaderboard.length; i++) {
      const user = leaderboard[i];
      const rank = i < 3 ? medals[i] : `**#${i + 1}**`;
      
      let username = "Unknown User";
      try {
        const fetchedUser = await client.users.fetch(user.UserId).catch(() => null);
        if (fetchedUser) username = fetchedUser.username;
      } catch (e) {}

      leaderboardText += `${rank} **${username}**\n`;
      leaderboardText += `   <a:owo:1442395441181229177> ${formatNumber(user.owo)} OWO`;
      if (user.ltc > 0) {
        leaderboardText += ` | <a:ltc:1442395484802121822> $${user.ltc.toFixed(2)} LTC`;
      }
      leaderboardText += ` | 🎁 ${user.dropsClaimed} claims\n\n`;
    }

    const embed = new EmbedBuilder()
      .setColor(client.color)
      .setTitle("🏆 Drop Leaderboard")
      .setDescription(leaderboardText)
      .setFooter({ text: `Use ${prefix}dbal to check your own balance!` })
      .setTimestamp();

    return message.reply({ embeds: [embed] });
  },
};
