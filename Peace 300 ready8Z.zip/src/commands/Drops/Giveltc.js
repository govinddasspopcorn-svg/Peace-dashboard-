const { EmbedBuilder } = require("discord.js");

const db = require("../../utils/dropsDB");

module.exports = {

  name: "ltcgive",

  aliases: ["giveltc", "addltc"],

  description: "Give LTC to a user (Owner Only)",

  category: "Drops",

  usage: "<user> <amount>",

  cooldown: 5,

  execute: async (message, args, client, prefix) => {

    // OWNER CHECK

    const OWNER_ID = process.env.OWNER_ID;

    if (message.author.id !== OWNER_ID) {

      return message.reply("❌ Only the **bot owner** can use this command.");

    }

    // ARG CHECKS

    if (args.length < 2) {

      return message.reply(`❌ Usage: \`${prefix}ltcgive @user <amount>\``);

    }

    const userMention = message.mentions.users.first();

    if (!userMention) {

      return message.reply("❌ Please mention a **valid user**.");

    }

    const amount = parseFloat(args[1]);

    if (isNaN(amount) || amount <= 0) {

      return message.reply("❌ Enter a **valid positive LTC amount**.");

    }

    // DATABASE UPDATE

    const user = await db.getUser(userMention.id);

    user.ltc += amount;

    await db.saveUser(user);

    // RESPONSE EMBED

    const embed = new EmbedBuilder()

      .setColor("#00FF99")

      .setTitle("💰 LTC Granted Successfully")

      .setDescription(

        `Added **$${amount.toFixed(2)} LTC** to <@${userMention.id}>.\n\n` +

        `📦 **New LTC Balance:** \`${user.ltc.toFixed(2)}\``

      )

      .setTimestamp();

    return message.reply({ embeds: [embed] });

  },

};