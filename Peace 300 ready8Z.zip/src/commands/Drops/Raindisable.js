const { EmbedBuilder } = require("discord.js");

const db = require("../../utils/dropsDB");

module.exports = {

  name: "raindisable",

  aliases: ["rainoff", "stoprain", "disablerain"],

  description: "Disable rain mode in your server.",

  category: "Drops",

  cooldown: 5,

  execute: async (message, args, client, prefix) => {

    const guildId = message.guild.id;

    const guild = await db.getGuild(guildId);

    if (!guild.rainMode) {

      return message.reply("🌧️ Rain mode is already **disabled**.");

    }

    guild.rainMode = false;

    guild.rainEndTime = 0;

    await db.saveGuild(guild);

    const embed = new EmbedBuilder()

      .setColor("#ff4d4d")

      .setTitle("🌧️ Rain Mode Disabled")

      .setDescription(

        "Rain mode has been **turned off**.\n" +

        "Drops will now spawn at the **normal 30-minute interval**."

      )

      .setTimestamp();

    return message.reply({ embeds: [embed] });

  },

};