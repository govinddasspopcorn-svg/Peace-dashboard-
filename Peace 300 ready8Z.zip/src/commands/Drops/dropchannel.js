const db = require("../../utils/dropsDB.js");
const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  name: "dropchannel",
  category: "Drops",
  aliases: ["setdropchannel", "dropchan", "setdrops"],
  description: "Set the channel where drops will spawn",
  args: false,
  usage: "[#channel]",
  userPerms: [], // removed ManageGuild requirement
  owner: true,   // mark as owner
  cooldown: 5,

  execute: async (message, args, client, prefix) => {

    // OWNER CHECK
    const BOT_OWNER = process.env.OWNER_ID;
    if (message.author.id !== BOT_OWNER) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription(`❌ | Only the **Bot Owner** can use this command!`)
        ],
      });
    }

    const channel = message.mentions.channels.first() || 
                    message.guild.channels.cache.get(args[0]) || 
                    message.channel;

    if (!channel.isTextBased()) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription(`❌ | Please select a valid text channel!`)
        ],
      });
    }

    const guild = await db.getGuild(message.guild.id);
    guild.dropChannel = channel.id;
    guild.enabled = true;
    await db.saveGuild(guild);

    const embed = new EmbedBuilder()
      .setColor("#00FF00")
      .setTitle(`✅ Drop Channel Set!`)
      .setDescription(
        `Drops will now spawn in ${channel}!\n\n` +
        `**Commands:**\n` +
        `\`${prefix}dclaim\` - Claim a drop\n` +
        `\`${prefix}dbal\` - Check balance\n` +
        `\`${prefix}forcedrop\` - Force spawn a drop (admin)\n` +
        `\`${prefix}rain\` - Enable rain mode (admin)`
      )
      .setFooter({ text: "Drops spawn automatically every 30 minutes!" })
      .setTimestamp();

    return message.reply({ embeds: [embed] });
  },
};