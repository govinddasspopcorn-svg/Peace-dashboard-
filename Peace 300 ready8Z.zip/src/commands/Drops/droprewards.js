const { RARITIES, formatNumber } = require("../../system/rarityChooser.js");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "droprewards",
  category: "Drops",
  aliases: ["rewards", "inforewards", "dropinfo"],
  description: "View drop rarity rewards and chances",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  cooldown: 5,
  execute: async (message, args, client, prefix) => {
    let rewardsText = "";

    for (const [rarity, data] of Object.entries(RARITIES)) {
      const cooldownText = data.cooldownMs > 0 
        ? `${Math.floor(data.cooldownMs / (24 * 60 * 60 * 1000))}d` 
        : "None";
      
      rewardsText += `${data.emoji} **${data.label}** (${data.chance}%)\n`;
      rewardsText += `   <a:owo:1442395441181229177> ${formatNumber(data.reward)} OWO`;
      if (data.ltc > 0) {
        rewardsText += ` + <a:ltc:1442395484802121822> $${data.ltc.toFixed(2)} LTC`;
      }
      rewardsText += `\n   ⏱️ Cooldown: ${cooldownText}\n\n`;
    }

    const embed = new EmbedBuilder()
      .setColor(client.color)
      .setTitle("🎁 Drop Rewards")
      .setDescription(rewardsText)
      .addFields(
        {
          name: "⏰ Auto-Drops",
          value: "Drops spawn automatically every **30 minutes**\nWith rain mode: every **2 minutes**",
          inline: true,
        },
        {
          name: "⏳ Expiration",
          value: "Each drop expires after **5 minutes** if unclaimed",
          inline: true,
        }
      )
      .setFooter({ text: `Use ${prefix}dclaim to claim drops! | ${prefix}dbal to check balance` })
      .setTimestamp();

    return message.reply({ embeds: [embed] });
  },
};
