const { EmbedBuilder } = require("discord.js");

const db = require("../../utils/dropsDB");

module.exports = {

  name: "give",

  aliases: ["pay", "transfer"],

  description: "Give OWO or LTC from your balance to another user",

  category: "Drops",

  usage: "<user> <owo|ltc> <amount>",

  cooldown: 5,

  execute: async (message, args) => {

    if (args.length < 3) {

      return message.reply(

        "❌ Usage: `give @user <owo|ltc> <amount>`"

      );

    }

    const target = message.mentions.users.first();

    if (!target) {

      return message.reply("❌ Please mention a valid user.");

    }

    if (target.id === message.author.id) {

      return message.reply("❌ You cannot give rewards to yourself.");

    }

    const currency = args[1].toLowerCase();

    if (!["owo", "ltc"].includes(currency)) {

      return message.reply("❌ Currency must be `owo` or `ltc`.");

    }

    const amount =

      currency === "ltc"

        ? parseFloat(args[2])

        : parseInt(args[2]);

    if (isNaN(amount) || amount <= 0) {

      return message.reply("❌ Enter a valid positive amount.");

    }

    const sender = await db.getUser(message.author.id);

    const receiver = await db.getUser(target.id);

    // BALANCE CHECK

    if (currency === "owo") {

      if (sender.owo < amount) {

        return message.reply("❌ You don’t have enough OWO.");

      }

      sender.owo -= amount;

      receiver.owo += amount;

    } else {

      if (sender.ltc < amount) {

        return message.reply("❌ You don’t have enough LTC.");

      }

      sender.ltc -= amount;

      receiver.ltc += amount;

    }

    await db.saveUser(sender);

    await db.saveUser(receiver);

    const embed = new EmbedBuilder()

      .setColor("#00BFFF")

      .setTitle("💸 Transfer Successful")

      .setDescription(

        `**From:** <@${message.author.id}>\n` +

        `**To:** <@${target.id}>\n\n` +

        `**Amount:** ${

          currency === "ltc"

            ? `$${amount.toFixed(2)} LTC`

            : `${amount.toLocaleString()} OWO`

        }`

      )

      .setFooter({

        text:

          currency === "ltc"

            ? `Your new LTC balance: ${sender.ltc.toFixed(2)}`

            : `Your new OWO balance: ${sender.owo.toLocaleString()}`,

      })

      .setTimestamp();

    return message.reply({ embeds: [embed] });

  },

};