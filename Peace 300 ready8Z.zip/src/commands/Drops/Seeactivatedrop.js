const { EmbedBuilder } = require("discord.js");
const db = require("../../utils/dropsDB");

module.exports = {
  name: "seeactivedrops",
  aliases: ["activedrops", "dropsactive"],
  description: "View all servers with enabled drop channels. (Owner Only)",
  category: "Drops",
  cooldown: 5,

  execute: async (message, args, client, prefix) => {
    // OWNER CHECK
    if (message.author.id !== process.env.OWNER_ID)
      return message.reply("❌ Only the **bot owner** can use this command.");

    const guilds = await db.getAllEnabledGuilds();

    const embed = new EmbedBuilder()
      .setColor("#00BFFF")
      .setTitle("📡 Active Drop Channels")
      .setDescription("Here are all servers that have drops enabled:")
      .setTimestamp();

    if (guilds.length === 0) {
      embed.setDescription("❌ No servers have drops enabled.");
      return message.reply({ embeds: [embed] });
    }

    for (const g of guilds) {
      const fetchedGuild = client.guilds.cache.get(g.GuildId);
      if (!fetchedGuild) continue;

      // Try creating an invite
      let invite = "No Invite Available";
      try {
        const channel = await client.channels.fetch(g.dropChannel).catch(() => null);
        if (channel) {
          const inv = await channel.createInvite({ maxAge: 0, maxUses: 0 });
          invite = inv.url;
        }
      } catch {
        invite = "Invite Failed";
      }

      embed.addFields({
        name: `🟦 ${fetchedGuild.name}`,
        value:
          `• **Drop Channel:** <#${g.dropChannel}>\n` +
          `• **Server Invite:** ${invite}\n`,
        inline: false,
      });
    }

    return message.reply({ embeds: [embed] });
  },
};