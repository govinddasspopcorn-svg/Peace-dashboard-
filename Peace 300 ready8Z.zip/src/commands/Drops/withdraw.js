const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "withdrawrewards",
  category: "Drops",
  aliases: ["withdraw", "withrewards"],
  description: "Get info on how to withdraw your drop rewards",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  cooldown: 5,

  execute: async (message, args, client, prefix) => {
    const embed = new EmbedBuilder()
      .setColor("#00BFFF")
      .setTitle("💸 Withdraw Your Rewards")
      .setDescription(
        "To withdraw your OWO or LTC rewards, please follow these steps:\n\n" +
        "1. Create a ticket in the server.\n" +
        "2. Head over to the **ticket channel** and open a new ticket.\n" +
        "3. Our team will check your balance and process your withdrawal manually.\n\n" +
        "<:info:1188195669660422226> Note: You can claim **only one type** of reward at a time — either OWO or LTC."
      )
      .setFooter({ text: `Use ${prefix}dbal to check your current rewards.` })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};