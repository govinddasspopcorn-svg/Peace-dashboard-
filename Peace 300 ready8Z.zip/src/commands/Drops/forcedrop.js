const { spawnDropForGuild } = require("../../system/spawnDrop.js");
const { RARITIES } = require("../../system/rarityChooser.js");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "forcedrop",
  category: "Drops",
  aliases: ["fdrop", "spawndrop"],
  description: "Force spawn a drop (Owner only)",
  args: false,
  usage: "[rarity]",
  userPerms: [], 
  owner: true,
  cooldown: 10,

  execute: async (message, args, client, prefix) => {

    // =====================
    // OWNER CHECK (ENV)
    // =====================
    const BOT_OWNER = process.env.OWNER_ID;

    if (message.author.id !== BOT_OWNER) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription(`❌ | Only the **Bot Owner** can use this command!`)
        ],
      });
    }

    // =====================
    // RARITY HANDLING
    // =====================

    const validRarities = Object.keys(RARITIES);
    let forceRarity = null;

    if (args[0]) {
      const inputRarity = args[0].toLowerCase();

      if (validRarities.includes(inputRarity)) {
        forceRarity = inputRarity;
      } else {
        return message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor("#FF0000")
              .setDescription(
                `❌ | Invalid rarity!\n\nValid: \`${validRarities.join(", ")}\``
              )
          ],
        });
      }
    }

    // =====================
    // FORCE SPAWN DROP
    // =====================

    const result = await spawnDropForGuild(client, message.guild.id, prefix, forceRarity);

    if (!result.success) {
      let errorMsg = "";

      switch (result.reason) {
        case "not_configured":
          errorMsg = `Drops not configured! Use \`${prefix}dropchannel\`.`;
          break;
        case "active_drop_exists":
          errorMsg = "There is already an active drop!";
          break;
        case "channel_not_found":
          errorMsg = `Drop channel not found! Reconfigure with \`${prefix}dropchannel\`.`;
          break;
        default:
          errorMsg = "Unable to spawn drop.";
      }

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription(`❌ | ${errorMsg}`)
        ],
      });
    }

    // =====================
    // SUCCESS
    // =====================

    const embed = new EmbedBuilder()
      .setColor("#00FF00")
      .setDescription(
        `✅ | Force spawned a **${result.rarity.toUpperCase()}** drop!`
      )
      .setTimestamp();

    return message.reply({ embeds: [embed] });
  },
};