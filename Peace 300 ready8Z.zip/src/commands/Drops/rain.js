const { enableRainMode, disableRainMode } = require("../../system/autoSpawnerLoop.js");
const db = require("../../utils/dropsDB.js");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "rain",
  category: "Drops",
  aliases: ["rainmode", "droprain"],
  description: "Enable rain mode - drops spawn every 2 minutes instead of 30",
  args: false,
  usage: "[duration in minutes] | off",
  userPerms: [], // No perms needed
  owner: true,
  cooldown: 10,

  execute: async (message, args, client, prefix) => {

    // ======================
    // OWNER CHECK (ENV)
    // ======================
    const BOT_OWNER = process.env.OWNER_ID;

    if (message.author.id !== BOT_OWNER) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription(`❌ | Only the **Bot Owner** can use this command!`)
        ],
      });
    }

    // ======================
    // GUILD CHECK
    // ======================
    const guild = await db.getGuild(message.guild.id);

    if (!guild.enabled || !guild.dropChannel) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription(`❌ | Drops are not configured! Use \`${prefix}dropchannel\` first.`)
        ],
      });
    }

    // ======================
    // DISABLE RAIN
    // ======================
    if (args[0] && args[0].toLowerCase() === "off") {
      await disableRainMode(message.guild.id);
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#00FF00")
            .setTitle("🌧️ Rain Mode Disabled")
            .setDescription("Drops will now spawn at the normal rate (every 30 minutes).")
            .setTimestamp()
        ],
      });
    }

    // ======================
    // ENABLE RAIN MODE
    // ======================
    let duration = 30;

    if (args[0]) {
      const parsed = parseInt(args[0]);
      if (!isNaN(parsed) && parsed > 0 && parsed <= 120) {
        duration = parsed;
      } else {
        return message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor("#FF0000")
              .setDescription(`❌ | Duration must be between **1–120 minutes**!`)
          ],
        });
      }
    }

    const endTime = await enableRainMode(message.guild.id, duration);

    const embed = new EmbedBuilder()
      .setColor("#00BFFF")
      .setTitle("🌧️ Rain Mode Enabled!")
      .setDescription(
        `Drops will now spawn every **2 minutes**!\n\n` +
        `**Duration:** ${duration} minutes\n` +
        `**Ends:** <t:${Math.floor(endTime / 1000)}:R>`
      )
      .setFooter({ text: `Use ${prefix}rain off to disable early` })
      .setTimestamp();

    return message.reply({ embeds: [embed] });
  },
};