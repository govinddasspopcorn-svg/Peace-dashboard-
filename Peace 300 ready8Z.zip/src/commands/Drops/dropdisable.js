const db = require("../../utils/dropsDB.js");
const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  name: "dropdisable",
  category: "Drops",
  aliases: ["disabledrops", "dropsdisable", "stopdrops"],
  description: "Disable drops from spawning in the server",
  args: false,
  usage: "",
  userPerms: ["ManageGuild"],
  owner: false,
  cooldown: 5,

  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription(`${client.emoji.cross} | You need **Manage Server** permission to use this command!`)
        ],
      });
    }

    const guild = await db.getGuild(message.guild.id);

    if (!guild.enabled) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription(`${client.emoji.cross} | Drops are already **disabled** in this server!`)
        ],
      });
    }

    guild.enabled = false;
    await db.saveGuild(guild);

    const embed = new EmbedBuilder()
      .setColor("#FF0000")
      .setTitle(`${client.emoji.cross} Drops Disabled!`)
      .setDescription(
        `🎁 Drops have been **disabled** for this server.\n\n` +
        `Use \`${prefix}dropchannel\` to re-enable drops by setting a drop channel.`
      )
      .setTimestamp();

    return message.reply({ embeds: [embed] });
  }
};