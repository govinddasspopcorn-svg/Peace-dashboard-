const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../utils/dropsDB.js");

module.exports = {
  name: "dropresetall",
  category: "Drops",
  aliases: ["resetdrops", "droprewipe", "dropwipeall"],
  description: "Reset ALL users' drop data (global wipe)",
  args: false,
  usage: "",
  userPerms: ["ManageGuild"],
  owner: false,
  cooldown: 10,

  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription(`${client.emoji.cross} | You need **Manage Server** permission to use this command!`)
        ],
      });
    }

    const confirmEmbed = new EmbedBuilder()
      .setColor("#ffcc00")
      .setTitle("⚠ GLOBAL DROP DATA RESET")
      .setDescription(
        `This will **ERASE ALL DROP DATA** for **every user** in the database.\n\n` +
        `🟡 **This action cannot be undone.**\n\n` +
        `Are you sure you want to continue?`
      );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("confirm_reset_drops")
        .setLabel("YES — Reset All Data")
        .setStyle(ButtonStyle.Danger),

      new ButtonBuilder()
        .setCustomId("cancel_reset_drops")
        .setLabel("Cancel")
        .setStyle(ButtonStyle.Secondary)
    );

    const msg = await message.reply({ embeds: [confirmEmbed], components: [row] });

    // Collector
    const collector = msg.createMessageComponentCollector({
      filter: (i) => i.user.id === message.author.id,
      time: 30000,
    });

    collector.on("collect", async (interaction) => {
      if (interaction.customId === "cancel_reset_drops") {
        return interaction.update({
          embeds: [
            new EmbedBuilder()
              .setColor("#00ff00")
              .setDescription(`${client.emoji.tick} | Reset cancelled.`)
          ],
          components: [],
        });
      }

      if (interaction.customId === "confirm_reset_drops") {
        await db.DropUser.deleteMany({}); // FULL WIPE

        return interaction.update({
          embeds: [
            new EmbedBuilder()
              .setColor("#FF0000")
              .setTitle("🎁 Drop System - Global Wipe Complete")
              .setDescription(
                `${client.emoji.tick} | **All users' drop data has been reset.**\n\n` +
                `OWO, LTC, cooldowns, stats, and claim logs cleared.`
              )
              .setTimestamp()
          ],
          components: [],
        });
      }
    });

    collector.on("end", () => {
      msg.edit({ components: [] }).catch(() => {});
    });
  }
};