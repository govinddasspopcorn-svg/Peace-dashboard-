const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "exchange",
  category: "Drops",
  aliases: ["dex", "dexchange"],
  description: "View OWO ↔ LTC exchange rates and how to exchange",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  cooldown: 5,

  execute: async (message, args, client, prefix) => {
    const embed = new EmbedBuilder()
      .setColor("#00BFFF")
      .setTitle("💱 OWO ↔ LTC Exchange")
      .setDescription(
        "**Current exchange rates:**\n" +
        "- **OWO → LTC:** `100,000 OWO` = `$0.02` LTC\n" +
        "- **LTC → OWO:** `$0.02` LTC = `100,000 OWO`\n\n" +
        "To exchange your rewards, please **create a ticket** in the server's ticket channel.\n" +
        "Staff will check your balance and process the exchange manually."
      )
      .setFooter({ text: `Use ${prefix}dbal to check your balance before opening a ticket.` })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};