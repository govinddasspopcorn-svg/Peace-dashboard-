const db = require("../../utils/dropsDB.js");
const { formatNumber } = require("../../system/rarityChooser.js");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "giveowo",
  category: "Drops",
  aliases: ["addowo", "owogive"],
  description: "Give OWO to a user (Owner only)",
  args: true,
  usage: "<@user> <amount>",
  userPerms: [],
  owner: true,
  cooldown: 5,

  execute: async (message, args, client, prefix) => {

    // OWNER CHECK
    const BOT_OWNER = process.env.OWNER_ID;
    if (message.author.id !== BOT_OWNER) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription(`${client.emoji.cross} | Only the **Bot Owner** can use this command!`)
        ],
      });
    }

    const target = message.mentions.users.first();
    const amount = parseInt(args[1]);

    const user = await db.addOwoToUser(target.id, amount);

    const embed = new EmbedBuilder()
      .setColor("#00FF00")
      .setTitle(`${client.emoji.tick} OWO Given!`)
      .setDescription(
        `Gave **${formatNumber(amount)} OWO** to ${target}.\n\n` +
        `**New Balance:** ${formatNumber(user.owo)}`
      )
      .setThumbnail(target.displayAvatarURL({ size: 128 }))
      .setTimestamp();

    return message.reply({ embeds: [embed] });
  },
};