const db = require("../../utils/dropsDB.js");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "resetuser",
  category: "Drops",
  aliases: ["dropreset", "resetdropuser"],
  description: "Reset a user's drop data (Owner only)",
  args: true,
  usage: "<@user>",
  userPerms: [],
  owner: true,
  cooldown: 10,

  execute: async (message, args, client, prefix) => {

    // OWNER CHECK
    const BOT_OWNER = process.env.OWNER_ID;
    if (message.author.id !== BOT_OWNER) {
      return message.reply({
        embeds: [
          new EmbedBuilder().setColor("#FF0000").setDescription(`${client.emoji.cross} | Only the **Bot Owner** can use this command!`)
        ],
      });
    }

    const target = message.mentions.users.first();

    await db.resetUserData(target.id);

    const embed = new EmbedBuilder()
      .setColor("#00FF00")
      .setTitle(`${client.emoji.tick} User Reset`)
      .setDescription(
        `Reset drop data for **${target.username}**:\n` +
        `• OWO: 0\n• LTC: $0.00\n• Drops: 0\n• All cooldowns cleared`
      )
      .setThumbnail(target.displayAvatarURL({ size: 128 }))
      .setTimestamp();

    return message.reply({ embeds: [embed] });
  },
};