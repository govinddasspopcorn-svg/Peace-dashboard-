const { claimDrop } = require("../../system/spawnDrop.js");
const { getRarityData, formatNumber } = require("../../system/rarityChooser.js");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "dclaim",
  category: "Drops",
  aliases: ["claim", "dropclaim"],
  description: "Claim the active drop in the server",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  cooldown: 1,
  execute: async (message, args, client, prefix) => {
    const result = await claimDrop(client, message.guild.id, message.author.id, message.author.username);

    if (!result.success) {
      let errorMsg = "";
      switch (result.reason) {
        case "no_active_drop":
          errorMsg = "There is no active drop to claim right now!";
          break;
        case "drop_expired":
          errorMsg = "That drop has expired! Wait for the next one.";
          break;
        case "cooldown":
          errorMsg = `You're on cooldown for **${result.rarity.toUpperCase()}** drops! Wait **${result.timeRemaining}** before claiming this rarity again.`;
          break;
        default:
          errorMsg = "Something went wrong. Please try again.";
      }

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription(`${client.emoji.cross} | ${errorMsg}`)
        ],
      });
    }

    const data = getRarityData(result.rarity);

    const embed = new EmbedBuilder()
      .setColor(data.color)
      .setTitle(`${data.emoji} Drop Claimed!`)
      .setDescription(
        `**${message.author.username}** claimed a **${data.label}** drop!\n\n` +
        `**Rewards:**\n` +
        `<a:owo:1442395441181229177> **+${formatNumber(result.owoAmount)} OWO**\n` +
        (result.ltcAmount > 0 ? `<a:ltc:1442395484802121822> **+$${result.ltcAmount.toFixed(2)} LTC**\n` : "")
      )
      .setThumbnail(message.author.displayAvatarURL({ size: 256 }))
      .setFooter({ text: `Congratulations! Use ${prefix}dbal to check your balance.` })
      .setTimestamp();

    if (result.messageId) {
      try {
        const dropChannel = message.channel;
        const dropMessage = await dropChannel.messages.fetch(result.messageId).catch(() => null);
        if (dropMessage) {
          const claimedEmbed = new EmbedBuilder()
            .setColor(data.color)
            .setTitle(`${data.emoji} Drop Claimed!`)
            .setDescription(`This **${data.label}** drop was claimed by **${message.author.username}**!`)
            .setTimestamp();
          await dropMessage.edit({ embeds: [claimedEmbed], components: [] }).catch(() => null);
        }
      } catch (e) {}
    }

    return message.reply({ embeds: [embed] });
  },
};
