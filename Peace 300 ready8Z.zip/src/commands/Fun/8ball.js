module.exports = {
  name: "8ball",
  category: "Fun",
  aliases: ["eightball", "8b"],
  description: "Ask the magic 8ball a question and get a mystical answer",
  args: true,
  usage: "<question>",
  userPerms: [],
  owner: false,
  cooldown: 3,
  execute: async (message, args, client, prefix) => {
    const question = args.join(" ");
    
    if (!question || question.length < 3) {
      return message.reply({
        embeds: [
          new client.embed()
            .setDescription(`${client.emoji.cross} | Please ask a valid question!\n**Usage:** \`${prefix}8ball <question>\``)
        ],
      });
    }

    const answers = [
      // Affirmative Answers (10)
      "🟢 Yes, definitely!",
      "🟢 It is certain!",
      "🟢 Without a doubt!",
      "🟢 Yes, absolutely!",
      "🟢 You may rely on it!",
      "🟢 As I see it, yes!",
      "🟢 Most likely!",
      "🟢 Outlook good!",
      "🟢 Signs point to yes!",
      "🟢 Yes!",
      
      // Non-committal Answers (5)
      "🟡 Reply hazy, try again.",
      "🟡 Ask again later.",
      "🟡 Better not tell you now.",
      "🟡 Cannot predict now.",
      "🟡 Concentrate and ask again.",
      
      // Negative Answers (5)
      "🔴 Don't count on it.",
      "🔴 My reply is no.",
      "🔴 My sources say no.",
      "🔴 Outlook not so good.",
      "🔴 Very doubtful.",
    ];

    const answer = answers[Math.floor(Math.random() * answers.length)];
    const isPremium = answer.startsWith("🟢");
    const isNeutral = answer.startsWith("🟡");
    
    const embed = new client.embed()
      .setAuthor({
        name: "🔮 Magic 8-Ball",
        iconURL: client.user.displayAvatarURL(),
      })
      .setThumbnail(message.author.displayAvatarURL({ size: 1024 }))
      .addFields(
        {
          name: "❓ Question",
          value: `\`\`\`${question}\`\`\``,
          inline: false,
        },
        {
          name: "🎱 Answer",
          value: `**${answer}**`,
          inline: false,
        }
      )
      .setFooter({
        text: `✨ Asked by ${message.author.username}`,
        iconURL: message.author.displayAvatarURL(),
      })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
