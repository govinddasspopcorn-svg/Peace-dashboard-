module.exports = {
  name: "snake",
  category: "Fun",
  description: "Play a game of Snake",
  execute: async (message, args, client, prefix) => {
    const { Snake } = require("discord-gamecord");
    new Snake({
      message: message,
      isSlashArgs: false,
      embed: {
        title: "Snake Game",
        overTitle: "Game Over",
        color: "#5865F2",
      },
      emojis: {
        board: "⬛",
        food: "🍎",
        up: "⬆️",
        down: "⬇️",
        left: "⬅️",
        right: "➡️",
      },
      snake: { head: "🟢", body: "🟩", tail: "🟢", over: "💀" },
      foods: ["🍎", "🍇", "🍊", "🫐", "🥕", "🥝", "🌽"],
      stopButton: "Stop",
      timeoutTime: 60000,
      playerOnlyMessage: "Only {player} can use these buttons.",
    }).startGame();
  },
};