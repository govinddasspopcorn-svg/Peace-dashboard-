const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "hack",
  category: "Fun",
  aliases: ["hacker", "wizz"],
  cooldown: 5,

  execute: async (message, args, client, prefix) => {
    const user = message.mentions.users.first();
    if (!user)
      return message.reply(`${client.emoji.cross} | Mention a user to hack`);

    const emails = [
      "sus@among.us", "unknown@discord.com",
      "admin@gmail.com", "uwu@owo.com"
    ];
    const ips = [
      "127.0.0.1", "69.420.69.420",
      "192.168.0.1", "41.89.22.109"
    ];

    const email = emails[Math.floor(Math.random() * emails.length)];
    const ip = ips[Math.floor(Math.random() * ips.length)];
    const password = Math.random().toString(36).slice(2);
    const token = `Mz${Math.random().toString(36).slice(2)}.${Math.random().toString(36).slice(2)}`;

    let msg = await message.channel.send(
      `${client.emoji.loading} | Initializing hack on **${user.username}**`
    );

    setTimeout(() => msg.edit(`${client.emoji.loading} | Bypassing firewall...`), 800);
    setTimeout(() => msg.edit(`${client.emoji.loading} | Collecting data...`), 1600);

    setTimeout(() => {
      const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTitle(`😈 Successfully Hacked ${user.tag}`)
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .setDescription(
          `${client.emoji.dot} **Email:** \`${email}\`\n` +
          `${client.emoji.dot} **IP:** \`${ip}\`\n` +
          `${client.emoji.dot} **Password:** \`${password}\`\n` +
          `${client.emoji.dot} **Token:** \`${token}\`\n\n` +
          `⚠️ Relax, it's a prank 😭`
        );

      msg.edit({ content: "", embeds: [embed] });
    }, 3000);
  },
};