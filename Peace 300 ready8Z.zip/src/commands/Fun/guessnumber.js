const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "multiguess",
  category: "Fun",
  aliases: ["mgtn", "mguess"],
  cooldown: 5,

  execute: async (message, args, client, prefix) => {
    const max = parseInt(args[0]) || 50;
    let time = args[1] || "40s";

    let ms = 40000;
    if (time.endsWith("s")) ms = parseInt(time) * 1000;
    if (time.endsWith("m")) ms = parseInt(time) * 60000;

    const number = Math.floor(Math.random() * max) + 1;

    // DM Host Secret Number
    try {
      await message.author.send(
        `${client.emoji.info} | Secret number for game in **${message.guild.name}** is: \`${number}\`\nDon't leak it 😈`
      );
    } catch {
      return message.reply(
        `${client.emoji.cross} | Enable DM so I can send you the number`
      );
    }

    const startEmbed = new EmbedBuilder()
      .setColor(client.color)
      .setTitle(`${client.emoji.fun} Multiplayer Guess The Number`)
      .setDescription(
        `${client.emoji.info} Guess a number between **1 - ${max}**\n\n` +
        `👥 Everyone can play\n` +
        `⏱️ Time: **${ms / 1000} seconds**\n\n` +
        `❌ Type \`cancel\` to stop (Host/Admin only)\n\n` +
        `✍️ Start guessing now!`
      );

    message.channel.send({ embeds: [startEmbed] });

    const attempts = new Map();

    const collector = message.channel.createMessageCollector({
      time: ms
    });

    collector.on("collect", msg => {
      if (msg.author.bot) return;

      // cancel system
      if (
        msg.content.toLowerCase() === "cancel" &&
        (msg.author.id === message.author.id ||
          msg.member.permissions.has("Administrator"))
      ) return collector.stop("cancelled");

      const guess = parseInt(msg.content);
      if (isNaN(guess)) return;

      attempts.set(msg.author.id, (attempts.get(msg.author.id) || 0) + 1);

      if (guess === number) {
        collector.stop("guessed");

        message.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor("#00ff59")
              .setTitle(`${client.emoji.tick} Winner!`)
              .setDescription(
                `🎉 **${msg.author} guessed correctly!**\n\n` +
                `🔢 Number: **${number}**\n` +
                `🎯 Attempts Used: **${attempts.get(msg.author.id)}**`
              )
          ]
        });

        // Scoreboard
        const sorted = [...attempts.entries()].sort((a, b) => a[1] - b[1]);
        let board = "";
        let pos = 1;
        sorted.forEach(([id, att]) => {
          board += `\`${pos++}.\` <@${id}> — **${att} attempts**\n`;
        });

        return message.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor("#2b2d31")
              .setTitle("🏆 Scoreboard")
              .setDescription(board || "Nobody played 💀")
          ]
        });
      }
    });

    collector.on("end", (_, reason) => {
      if (reason === "time")
        return message.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor("#ff0000")
              .setTitle(`${client.emoji.cross} Time's Up`)
              .setDescription(
                `Nobody guessed it.\n\nCorrect Number: **${number}**`
              )
          ]
        });

      if (reason === "cancelled")
        return message.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor("#ffaa00")
              .setTitle(`🛑 Game Cancelled`)
          ]
        });
    });
  },
};