module.exports = {
  name: "coinflip",
  category: "Fun",
  description: "Flip a coin",
  execute: async (message, args, client, prefix) => {
    const result = Math.random() > 0.5 ? "Heads" : "Tails";
    message.reply({
      embeds: [
        new client.embed()
          .setAuthor({ name: "Coin Flip", iconURL: client.user.displayAvatarURL() })
          .setDescription(`${client.emoji.dot} The coin landed on: **${result}**`)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
      ]
    });
  },
};