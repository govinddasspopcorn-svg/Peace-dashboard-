const { EmbedBuilder } = require("discord.js");

const activeGames = new Map();

module.exports = {
  name: "wordchain",
  category: "Fun",
  aliases: ["wc", "wordgame"],
  cooldown: 3,
  description: "Start a word chain game! Next word must start with the last letter of previous word.",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  execute: async (message, args, client, prefix) => {
    if (activeGames.has(message.channel.id)) {
      return message.reply({
        embeds: [
          new client.embed()
            .setDescription(`${client.emoji.cross} | A word chain game is already running in this channel!`)
        ]
      });
    }

    const startWords = [
      "Apple", "Banana", "Cat", "Dog", "Elephant", "Fire", "Guitar", 
      "House", "Island", "Jungle", "King", "Lion", "Mountain", "Night",
      "Ocean", "Pizza", "Queen", "River", "Sun", "Tree"
    ];

    const firstWord = startWords[Math.floor(Math.random() * startWords.length)];
    const usedWords = new Set([firstWord.toLowerCase()]);
    
    const gameData = {
      currentWord: firstWord,
      usedWords: usedWords,
      players: new Map(),
      startTime: Date.now(),
      lastPlayer: null
    };

    activeGames.set(message.channel.id, gameData);

    const embed = new client.embed()
      .setTitle("🔤 Word Chain Game Started!")
      .setDescription(
        `**How to Play:**\n` +
        `• Say a word that starts with the last letter of the previous word\n` +
        `• No repeating words!\n` +
        `• You can't play twice in a row\n` +
        `• Game ends after 2 minutes of inactivity\n\n` +
        `**Starting Word:** \`${firstWord}\`\n` +
        `**Next word must start with:** \`${firstWord.slice(-1).toUpperCase()}\`\n\n` +
        `Type your word in chat to play!`
      )
      .setFooter({
        text: `✨ Started by ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      });

    await message.reply({ embeds: [embed] });

    const filter = (m) => {
      if (m.author.bot) return false;
      const game = activeGames.get(message.channel.id);
      if (!game) return false;

      const word = m.content.trim().toLowerCase();
      const lastLetter = game.currentWord.slice(-1).toLowerCase();
      const firstLetter = word[0];

      // Check if it's a valid word attempt (single word, starts with correct letter)
      return word.split(" ").length === 1 && 
             firstLetter === lastLetter && 
             word.length >= 2 &&
             /^[a-zA-Z]+$/.test(word);
    };

    const collector = message.channel.createMessageCollector({ 
      filter,
      time: 120000 
    });

    let timeout;

    collector.on("collect", async (m) => {
      const game = activeGames.get(message.channel.id);
      if (!game) return;

      const word = m.content.trim();
      const wordLower = word.toLowerCase();

      // Check if player is playing twice in a row
      if (game.lastPlayer === m.author.id) {
        return m.reply({
          embeds: [
            new client.embed()
              .setDescription(`${client.emoji.cross} | You can't play twice in a row! Let someone else go.`)
          ]
        }).then(msg => setTimeout(() => msg.delete().catch(() => {}), 3000));
      }

      // Check if word was already used
      if (game.usedWords.has(wordLower)) {
        return m.reply({
          embeds: [
            new client.embed()
              .setDescription(`${client.emoji.cross} | \`${word}\` has already been used! Try another word.`)
          ]
        }).then(msg => setTimeout(() => msg.delete().catch(() => {}), 3000));
      }

      // Valid word!
      game.usedWords.add(wordLower);
      game.currentWord = word;
      game.lastPlayer = m.author.id;

      // Update player score
      const currentScore = game.players.get(m.author.id) || 0;
      game.players.set(m.author.id, currentScore + 1);

      await m.react(client.emoji.tick || "✅").catch(() => {});

      const nextLetter = word.slice(-1).toUpperCase();
      await m.reply({
        embeds: [
          new client.embed()
            .setDescription(
              `${client.emoji.tick} **${word}** is correct!\n\n` +
              `**Next word must start with:** \`${nextLetter}\`\n` +
              `**Words used:** ${game.usedWords.size}`
            )
        ]
      });

      // Reset timeout
      if (timeout) clearTimeout(timeout);
      timeout = setTimeout(() => {
        collector.stop("inactivity");
      }, 120000);
    });

    collector.on("end", (collected, reason) => {
      const game = activeGames.get(message.channel.id);
      if (!game) return;

      activeGames.delete(message.channel.id);
      if (timeout) clearTimeout(timeout);

      const leaderboard = Array.from(game.players.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([userId, score], index) => {
          const medal = index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : "🏅";
          return `${medal} <@${userId}>: **${score}** word${score !== 1 ? 's' : ''}`;
        })
        .join("\n");

      const endEmbed = new client.embed()
        .setTitle("🏁 Word Chain Game Ended!")
        .setDescription(
          `**Total Words Used:** ${game.usedWords.size}\n` +
          `**Duration:** ${Math.floor((Date.now() - game.startTime) / 1000)}s\n\n` +
          (leaderboard ? `**Top Players:**\n${leaderboard}` : "No one played!")
        )
        .setFooter({ text: "✨ Thanks for playing!" });

      message.channel.send({ embeds: [endEmbed] });
    });
  },
};
