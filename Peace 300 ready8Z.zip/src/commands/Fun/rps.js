const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require("discord.js");

module.exports = {
  name: "rps",
  category: "Fun",
  aliases: ["rockpaperscissors", "roshambo"],
  cooldown: 3,
  description: "Play Rock, Paper, Scissors against the bot!",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  execute: async (message, args, client, prefix) => {
    const choices = ["🪨 Rock", "📄 Paper", "✂️ Scissors"];
    const choiceEmojis = ["🪨", "📄", "✂️"];
    
    const buttons = [
      new ButtonBuilder()
        .setCustomId("rps_rock")
        .setLabel("Rock")
        .setEmoji("🪨")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("rps_paper")
        .setLabel("Paper")
        .setEmoji("📄")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("rps_scissors")
        .setLabel("Scissors")
        .setEmoji("✂️")
        .setStyle(ButtonStyle.Secondary),
    ];

    const row = new ActionRowBuilder().addComponents(buttons);

    const embed = new client.embed()
      .setTitle("🎮 Rock, Paper, Scissors!")
      .setDescription(
        `Choose your move, ${message.author.username}!\n\n` +
        `🪨 **Rock** crushes Scissors\n` +
        `📄 **Paper** covers Rock\n` +
        `✂️ **Scissors** cuts Paper`
      )
      .setFooter({
        text: "✨ Click a button to make your choice!",
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      });

    const gameMessage = await message.reply({ 
      embeds: [embed], 
      components: [row] 
    });

    const collector = gameMessage.createMessageComponentCollector({ 
      time: 30000,
      max: 1,
      filter: (i) => i.user.id === message.author.id
    });

    collector.on("collect", async (interaction) => {
      const playerChoice = interaction.customId.split("_")[1];
      const botChoice = Math.floor(Math.random() * 3);
      
      const choiceMap = {
        rock: 0,
        paper: 1,
        scissors: 2
      };

      const playerIndex = choiceMap[playerChoice];
      const playerChoiceText = choices[playerIndex];
      const botChoiceText = choices[botChoice];

      // Determine winner
      let result;
      let resultColor;
      let resultEmoji;
      
      if (playerIndex === botChoice) {
        result = "It's a Tie!";
        resultColor = "#FFD700";
        resultEmoji = "🤝";
      } else if (
        (playerIndex === 0 && botChoice === 2) || // Rock beats Scissors
        (playerIndex === 1 && botChoice === 0) || // Paper beats Rock
        (playerIndex === 2 && botChoice === 1)    // Scissors beats Paper
      ) {
        result = "You Win!";
        resultColor = "#00FF00";
        resultEmoji = "🎉";
      } else {
        result = "You Lose!";
        resultColor = "#FF0000";
        resultEmoji = "😢";
      }

      const resultEmbed = new EmbedBuilder()
        .setTitle(`${resultEmoji} ${result}`)
        .setColor(resultColor)
        .addFields(
          {
            name: "Your Choice",
            value: playerChoiceText,
            inline: true
          },
          {
            name: "Bot's Choice",
            value: botChoiceText,
            inline: true
          },
          {
            name: "Result",
            value: result,
            inline: false
          }
        )
        .setFooter({
          text: `✨ Played by ${interaction.user.username}`,
          iconURL: interaction.user.displayAvatarURL({ dynamic: true })
        })
        .setTimestamp();

      // Add fun commentary
      let commentary = "";
      if (result === "You Win!") {
        const winMessages = [
          "Outstanding move! 🌟",
          "You're on fire! 🔥",
          "Incredible strategy! 💪",
          "You're a natural! ⭐",
          "What a play! 🎯"
        ];
        commentary = winMessages[Math.floor(Math.random() * winMessages.length)];
      } else if (result === "You Lose!") {
        const loseMessages = [
          "Better luck next time! 💫",
          "So close! Try again! 🎲",
          "The bot got lucky! 🤖",
          "Don't give up! 💪",
          "Rematch? 🔄"
        ];
        commentary = loseMessages[Math.floor(Math.random() * loseMessages.length)];
      } else {
        const tieMessages = [
          "Great minds think alike! 🧠",
          "We're perfectly matched! ⚖️",
          "What are the odds! 🎲",
          "Telepathy at work! 🔮",
          "Draw! Round 2? 🔄"
        ];
        commentary = tieMessages[Math.floor(Math.random() * tieMessages.length)];
      }

      resultEmbed.setDescription(commentary);

      await interaction.update({ embeds: [resultEmbed], components: [] });
    });

    collector.on("end", (collected) => {
      if (collected.size === 0) {
        const timeoutEmbed = new client.embed()
          .setTitle("⏰ Game Cancelled")
          .setDescription(`${client.emoji.cross} You didn't make a choice in time!`)
          .setFooter({ text: "✨ Try again when you're ready!" });

        gameMessage.edit({ embeds: [timeoutEmbed], components: [] });
      }
    });
  },
};
