module.exports = {
  name: "roll",
  category: "Fun",
  description: "Roll a dice",
  execute: async (message, args, client, prefix) => {
    const result = Math.floor(Math.random() * 6) + 1;
    message.reply({
      embeds: [
        new client.embed()
          .setAuthor({ name: "Dice Roll", iconURL: client.user.displayAvatarURL() })
          .setDescription(`${client.emoji.dot} You rolled a: **${result}**`)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
      ]
    });
  },
};