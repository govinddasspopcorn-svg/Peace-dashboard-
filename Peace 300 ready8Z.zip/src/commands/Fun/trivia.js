const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require("discord.js");

module.exports = {
  name: "trivia",
  category: "Fun",
  aliases: ["quiz", "triviatime"],
  cooldown: 5,
  description: "Test your knowledge with a random trivia question!",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  execute: async (message, args, client, prefix) => {
    const triviaQuestions = [
      {
        question: "What is the capital of France?",
        options: ["London", "Berlin", "Paris", "Madrid"],
        correct: 2,
        category: "Geography"
      },
      {
        question: "Who painted the Mona Lisa?",
        options: ["Van Gogh", "Leonardo da Vinci", "Picasso", "Michelangelo"],
        correct: 1,
        category: "Art"
      },
      {
        question: "What is the largest planet in our solar system?",
        options: ["Mars", "Saturn", "Jupiter", "Neptune"],
        correct: 2,
        category: "Science"
      },
      {
        question: "In what year did World War II end?",
        options: ["1943", "1944", "1945", "1946"],
        correct: 2,
        category: "History"
      },
      {
        question: "What is the speed of light?",
        options: ["299,792 km/s", "150,000 km/s", "500,000 km/s", "1,000,000 km/s"],
        correct: 0,
        category: "Science"
      },
      {
        question: "Who wrote 'Romeo and Juliet'?",
        options: ["Charles Dickens", "William Shakespeare", "Jane Austen", "Mark Twain"],
        correct: 1,
        category: "Literature"
      },
      {
        question: "What is the chemical symbol for gold?",
        options: ["Go", "Gd", "Au", "Ag"],
        correct: 2,
        category: "Science"
      },
      {
        question: "How many continents are there?",
        options: ["5", "6", "7", "8"],
        correct: 2,
        category: "Geography"
      },
      {
        question: "What is the smallest prime number?",
        options: ["0", "1", "2", "3"],
        correct: 2,
        category: "Mathematics"
      },
      {
        question: "Which programming language is known as the 'language of the web'?",
        options: ["Python", "Java", "JavaScript", "C++"],
        correct: 2,
        category: "Technology"
      },
      {
        question: "What is the largest ocean on Earth?",
        options: ["Atlantic", "Indian", "Arctic", "Pacific"],
        correct: 3,
        category: "Geography"
      },
      {
        question: "Who developed the theory of relativity?",
        options: ["Isaac Newton", "Albert Einstein", "Galileo", "Stephen Hawking"],
        correct: 1,
        category: "Science"
      },
      {
        question: "What is the currency of Japan?",
        options: ["Yuan", "Won", "Yen", "Ringgit"],
        correct: 2,
        category: "General Knowledge"
      },
      {
        question: "How many bones are in the human body?",
        options: ["186", "206", "226", "246"],
        correct: 1,
        category: "Biology"
      },
      {
        question: "What is the hardest natural substance?",
        options: ["Gold", "Iron", "Diamond", "Platinum"],
        correct: 2,
        category: "Science"
      }
    ];

    const trivia = triviaQuestions[Math.floor(Math.random() * triviaQuestions.length)];
    const emojis = ["🇦", "🇧", "🇨", "🇩"];
    
    const optionsText = trivia.options.map((opt, i) => 
      `${emojis[i]} ${opt}`
    ).join("\n");

    const buttons = trivia.options.map((opt, i) => 
      new ButtonBuilder()
        .setCustomId(`trivia_${i}`)
        .setLabel(opt)
        .setStyle(i === trivia.correct ? ButtonStyle.Success : ButtonStyle.Primary)
        .setEmoji(emojis[i])
    );

    const row = new ActionRowBuilder().addComponents(buttons);

    const embed = new client.embed()
      .setTitle(`🎯 Trivia Time!`)
      .setDescription(`**Category:** ${trivia.category}\n\n**Question:**\n${trivia.question}\n\n**Options:**\n${optionsText}`)
      .setFooter({
        text: `✨ You have 30 seconds to answer! • Asked by ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      });

    const triviaMessage = await message.reply({ 
      embeds: [embed], 
      components: [row] 
    });

    const collector = triviaMessage.createMessageComponentCollector({ 
      time: 30000,
      max: 1,
      filter: (i) => i.user.id === message.author.id
    });

    collector.on("collect", async (interaction) => {
      const selectedIndex = parseInt(interaction.customId.split("_")[1]);
      const isCorrect = selectedIndex === trivia.correct;

      const resultEmbed = new client.embed()
        .setTitle(isCorrect ? "🎉 Correct!" : "❌ Incorrect!")
        .setDescription(
          `**Question:** ${trivia.question}\n\n` +
          `**Your Answer:** ${trivia.options[selectedIndex]}\n` +
          `**Correct Answer:** ${trivia.options[trivia.correct]}\n\n` +
          (isCorrect ? 
            `${client.emoji.tick} Great job ${interaction.user.username}! You got it right!` : 
            `${client.emoji.cross} Better luck next time!`)
        )
        .setFooter({
          text: `Category: ${trivia.category}`,
          iconURL: interaction.user.displayAvatarURL({ dynamic: true })
        });

      await interaction.update({ embeds: [resultEmbed], components: [] });
    });

    collector.on("end", (collected) => {
      if (collected.size === 0) {
        const timeoutEmbed = new client.embed()
          .setTitle("⏰ Time's Up!")
          .setDescription(
            `**Question:** ${trivia.question}\n\n` +
            `**Correct Answer:** ${trivia.options[trivia.correct]}\n\n` +
            `${client.emoji.cross} You didn't answer in time!`
          )
          .setFooter({ text: `Category: ${trivia.category}` });

        triviaMessage.edit({ embeds: [timeoutEmbed], components: [] });
      }
    });
  },
};
