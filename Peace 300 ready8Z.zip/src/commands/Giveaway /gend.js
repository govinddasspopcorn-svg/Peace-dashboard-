const GiveawayManager = require("../../utils/giveawayManager");
const Giveaway = require("../../schema/giveaway");

module.exports = {
  name: "gend",
  category: "giveaway",
  description: "End a giveaway early",
  userPerms: ["ManageGuild"],
  botPerms: ["ManageGuild"],

  execute: async (message, args, client, prefix) => {
    const emoji = client.emoji.giveaway || "<a:giveaway:1440153256964788306>";
    const color =
      typeof client.color === "string"
        ? parseInt(client.color.replace("#", ""), 16)
        : client.color || 0xffd700;

    const messageId = args[0];
    if (!messageId)
      return message.reply(
        `❌ Usage: \`${prefix}gend <messageId>\``
      );

    const giveaway = await Giveaway.findOne({
      messageId,
      guildId: message.guild.id,
    });

    if (!giveaway)
      return message.reply("❌ No giveaway found with that message ID.");

    if (giveaway.ended)
      return message.reply("❌ This giveaway is already ended!");

    const manager = new GiveawayManager(client);
    const result = await manager.endGiveaway(messageId);

    if (!result || result.success === false)
      return message.reply("❌ Failed to end giveaway.");

    return message.channel.send({
      embeds: [
        {
          color,
          title: `${emoji} Giveaway Ended Early`,
          description:
            `⏰ The giveaway has been **force ended** successfully!\n` +
            `🎁 Prize: **${giveaway.prize}**`,
          footer: { text: "Host ended the giveaway early." },
        },
      ],
    });
  },
};