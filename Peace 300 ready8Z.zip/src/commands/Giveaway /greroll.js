const GiveawayManager = require("../../utils/giveawayManager");
const Giveaway = require("../../schema/giveaway");

module.exports = {
  name: "greroll",
  category: "giveaway",
  description: "Reroll giveaway winners",
  userPerms: ["ManageGuild"],
  botPerms: ["ManageGuild"],

  execute: async (message, args, client, prefix) => {
    const emoji = client.emoji.giveaway || "<a:giveaway:1440153256964788306>";
    const color =
      typeof client.color === "string"
        ? parseInt(client.color.replace("#", ""), 16)
        : client.color || 0xffd700;

    const messageId = args[0];
    if (!messageId)
      return message.reply(
        `❌ Usage: \`${prefix}greroll <messageId>\``
      );

    const giveaway = await Giveaway.findOne({
      messageId,
      guildId: message.guild.id,
    });

    if (!giveaway)
      return message.reply("❌ No giveaway found with that message ID.");

    if (!giveaway.ended)
      return message.reply("❌ That giveaway hasn't ended yet!");

    const channel = await message.guild.channels
      .fetch(giveaway.channelId)
      .catch(() => null);

    if (!channel)
      return message.reply("❌ Giveaway channel not found.");

    const msg = await channel.messages
      .fetch(giveaway.messageId)
      .catch(() => null);

    if (!msg)
      return message.reply("❌ Giveaway message not found.");

    let participants = giveaway.participants || [];

    // fallback → fetch from reactions if DB empty
    if (!participants.length) {
      const reaction = msg.reactions.cache.first();
      if (reaction) {
        const users = await reaction.users.fetch().catch(() => null);
        if (users) {
          participants = users.filter(u => !u.bot).map(u => u.id);
        }
      }
    }

    if (!participants.length)
      return message.reply("❌ No participants found to reroll.");

    const winner =
      participants[Math.floor(Math.random() * participants.length)];

    return message.channel.send({
      embeds: [
        {
          color,
          title: `${emoji} Giveaway Rerolled!`,
          description: `🎉 **New Winner:** <@${winner}>\n🔁 Giveaway has been successfully rerolled.`,
          footer: { text: "Good luck next time everyone!" },
        },
      ],
    });
  },
};