const GiveawayManager = require("../../utils/giveawayManager");

module.exports = {
  name: "gstart",
  category: "giveaway",
  description: "Start a giveaway",
  userPerms: ["ManageGuild"],
  botPerms: ["ManageGuild"],

  execute: async (message, args, client, prefix) => {
    const emoji = client.emoji.giveaway || "<a:giveaway:1440153256964788306>";

    // ===== USAGE HELP =====
    if (!args.length)
      return message.reply({
        embeds: [
          {
            color:
              typeof client.color === "string"
                ? parseInt(client.color.replace("#", ""), 16)
                : client.color || 0xFFD700,
            title: `${emoji} Giveaway Setup`,
            description:
              `**Format:**\n` +
              `\`${prefix}gstart <duration> <winners> <#channel> <prize>\`\n\n` +
              `**Examples:**\n` +
              `\`${prefix}gstart 10m 1 #giveaway Nitro\`\n` +
              `\`${prefix}gstart 1h 3 #events 10 Invites\`\n\n` +
              `**Duration Supported:**\n1m | 10m | 1h | 2d etc`,
          },
        ],
      });

    const manager = new GiveawayManager(client);

    // Duration
    const duration = args[0];
    const ms = manager.parseDuration(duration);
    if (!ms || ms < 1000)
      return message.reply("❌ Invalid duration! Example: `10m`, `1h`, `2d`");

    // Winners
    const winners = parseInt(args[1]);
    if (!winners || winners < 1 || winners > 20)
      return message.reply("❌ Winners must be between **1 - 20**");

    // Channel
    const channel =
      message.mentions.channels.first() || message.channel;
    if (!channel)
      return message.reply("❌ Provide a valid channel!");

    // Prize
    const prize = args.slice(3).join(" ");
    if (!prize)
      return message.reply("❌ Provide a prize!");

    await message.delete().catch(() => {});

    // ===== CREATE GIVEAWAY =====
    const result = await manager.createGiveaway(
      message,
      prize,
      ms,
      winners,
      channel.id
    );

    if (!result.success)
      return channel.send(`❌ Failed to start giveaway: ${result.error}`);

    // No extra "giveaway started" spam — embed handles it
  },
};