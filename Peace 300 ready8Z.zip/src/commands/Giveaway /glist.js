const { EmbedBuilder } = require("discord.js");
const Giveaway = require("../../schema/giveaway");

module.exports = {
  name: "glist",
  category: "giveaway",
  description: "List all active giveaways (prefix)",

  execute: async (message, args, client) => {
    const emoji = client.emoji.giveaway || "🎉";

    const giveaways = await Giveaway.find({
      guildId: message.guild.id,
      ended: false
    });

    if (!giveaways.length)
      return message.reply("❌ No active giveaways!");

    const embed = new EmbedBuilder()
      .setColor("#FFD700")
      .setTitle(`${emoji} Active Giveaways (${giveaways.length})`)
      .setDescription(
        giveaways
          .map(g => 
            `
🎁 **${g.prize}**
<:time:1440233667048902737> Ends: <t:${Math.floor(g.endTime / 1000)}:R>
👑 Host: <@${g.hostId}>
📩 Message ID: \`${g.messageId}\`
            `
          )
          .join("\n")
      )
      .setFooter({ text: "Use glist to check again" });

    message.reply({ embeds: [embed] });
  }
};
