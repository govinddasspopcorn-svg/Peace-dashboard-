/** @format */

const {
  EmbedBuilder,
  MessageFlags,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle,
  version,
} = require("discord.js");

module.exports = {
  name: "about",
  category: "Information",
  aliases: ["dev", "abt"],
  botPrams: ["EMBED_LINKS"],
  description: "See information about this project.",
  cooldown: 3,
  execute: async (message, args, client, prefix) => {
    try {
      // Bot information
      const uptime = Math.round(Date.now() / 1000 - client.uptime / 1000);
      const guildCount = client.numb(client.guilds.cache.size);
      const channelCount = client.numb(client.channels.cache.size);
      const userCount = client.numb(
        client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0),
      );

      // Embeds
      const homeEmbed = new client.embed()
        .setAuthor({
          name: `About ${client.user.username}`,
          iconURL: client.user.displayAvatarURL(),
        })
        .setDescription(
          `**🌟 Premium All-in-One Discord Bot**\n\n` +
          `${client.emoji.music} **Music System**\nHigh-quality audio streaming from multiple platforms\n\n` +
          `${client.emoji.antinuke} **Advanced Security**\nPowerful anti-nuke & automod protection\n\n` +
          `${client.emoji.moderation} **Moderation Tools**\nComplete server management features\n\n` +
          `${client.emoji.config} **Customization**\nFully configurable to match your server\n\n` +
          `⚡ Running 24/7 with premium reliability`,
        )
        .setThumbnail(client.user.displayAvatarURL({ size: 1024 }))
        .setFooter({
          text: `✨ Page 1/3 • Premium Quality Bot`,
          iconURL: client.user.displayAvatarURL(),
        });

      const infoEmbed = new client.embed()
        .setAuthor({
          name: "📊 Bot Statistics",
          iconURL: client.user.displayAvatarURL(),
        })
        .setDescription(
          `**Global Reach**\n` +
          `${client.emoji.dot} **Servers:** ${guildCount}\n` +
          `${client.emoji.dot} **Users:** ${userCount}\n` +
          `${client.emoji.dot} **Channels:** ${channelCount}\n\n` +
          `**Performance**\n` +
          `${client.emoji.dot} **Commands:** ${client.commands.size}\n` +
          `${client.emoji.dot} **Discord.js:** v${version}\n` +
          `${client.emoji.dot} **Uptime:** <t:${uptime}:R>\n` +
          `${client.emoji.dot} **Latency:** ${client.ws.ping}ms`,
        )
        .setThumbnail(client.user.displayAvatarURL({ size: 1024 }))
        .setFooter({
          text: `✨ Page 2/3 • Always Online`,
          iconURL: client.user.displayAvatarURL(),
        });

      const teamEmbed = new client.embed()
        .setAuthor({
          name: "👑 Development Team",
          iconURL: client.user.displayAvatarURL(),
        })
        .setDescription(
          `**${client.emoji.owner} Lead Developer**\n` +
          `[UNKNOWN](https://discord.com/users/1266043322129059925)\n\n` +
          `**${client.emoji.owner} Project Owner**\n` +
          `[Vaibhavi](https://discord.com/users/1393539740678094962)\n\n` +
          `**${client.emoji.dot} Links**\n` +
          `[Support Server](${client.config.links.support}) • [Invite Bot](${client.config.links.invite})\n` +
          `[Vote](${client.config.links.topgg}) • Show your support!`,
        )
        .setThumbnail(client.user.displayAvatarURL({ size: 1024 }))
        .setFooter({
          text: "✨ Page 3/3 • Premium Discord Bot",
          iconURL: client.user.displayAvatarURL(),
        });

      // Function to create button row with active button disabled
      const createButtonRow = (activePage) => {
        return new ActionRowBuilder().addComponents([
          new ButtonBuilder()
            .setCustomId("arki")
            .setLabel("Home")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(activePage === "home"),
          new ButtonBuilder()
            .setCustomId("inf")
            .setLabel("Info")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(activePage === "info"),
          new ButtonBuilder()
            .setCustomId("od")
            .setLabel("Team")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(activePage === "team"),
        ]);
      };

      // Send the initial message
      const msg = await message.reply({
        embeds: [homeEmbed],
        components: [createButtonRow("home")],
      });

      // Collector
      const collector = msg.createMessageComponentCollector({
        filter: (i) => i.user.id === message.author.id,
        time: 60000, // 1-minute timeout
      });

      collector.on("collect", async (interaction) => {
        try {
          if (interaction.customId === "arki") {
            await interaction.update({
              embeds: [homeEmbed],
              components: [createButtonRow("home")],
            });
          } else if (interaction.customId === "inf") {
            await interaction.update({
              embeds: [infoEmbed],
              components: [createButtonRow("info")],
            });
          } else if (interaction.customId === "od") {
            await interaction.update({
              embeds: [teamEmbed],
              components: [createButtonRow("team")],
            });
          }
        } catch (err) {
          console.error("Error handling interaction:", err);
        }
      });

      collector.on("end", (_, reason) => {
        if (reason === "time") {
          msg.edit({ components: [] }).catch(console.error);
        }
      });
    } catch (err) {
      console.error("Error executing 'about' command:", err);
      message.reply({
        content: "Something went wrong while executing this command.",
        flags: MessageFlags.Ephemeral,
      });
    }
  },
};
