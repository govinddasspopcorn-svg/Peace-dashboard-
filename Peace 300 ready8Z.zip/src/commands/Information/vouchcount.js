/** @format */
const { PermissionFlagsBits } = require("discord.js");

module.exports = {
  name: "vouchcount",
  aliases: ["scanvouch", "vouches"],
  category: "Information",
  cooldown: 10,

  execute: async (message, args, client) => {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `<:cross:1455452613645566147> You need **Manage Server** permission to use this.`
          ),
        ],
      });
    }

    const channel = message.mentions.channels.first() || message.channel;
    if (!channel?.isTextBased()) {
      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `<:cross:1455452613645566147> Please select a valid text channel.`
          ),
        ],
      });
    }

    let scanned = 0;
    let totalOWO = 0;
    let totalMoney = 0;

    const TRUST_WORDS = ["vouch", "legit", "trusted", "paid", "got", "received", "sent"];

    const msg = await message.reply({
      embeds: [
        new client.embed().setDescription(
          `<:host:1440232674999537760> **Scanning vouches in ${channel}...**\n⏳ Please wait...`
        ),
      ],
    });

    let last = null;

    try {
      while (true) {
        const opt = { limit: 100 };
        if (last) opt.before = last;

        const messages = await channel.messages.fetch(opt);
        if (!messages.size) break;

        for (const m of messages.values()) {
          let content = (m.content || "")
            .toLowerCase()
            .replace(/,/g, "")
            .replace(/\s+/g, " ")
            .trim();

          if (!content) continue;
          scanned++;

          // must include a trust word
          if (!TRUST_WORDS.some(w => content.includes(w))) continue;

          /* ===========================
             STRICT OWO MATCHING
          =========================== */

          // captures:
          // 500k owo / 500 k owo / 1.5m owo / 2000 owo / owo 200k
          const owoRegex = /(\d+(\.\d+)?)(\s?)(k|m|million)?\s*owo/;
          const owoMatch = content.match(owoRegex);

          if (owoMatch) {
            let value = parseFloat(owoMatch[1]);
            const unit = owoMatch[4];

            if (unit === "k") value *= 1000;
            if (unit === "m" || unit === "million") value *= 1000000;

            if (!isNaN(value) && value < 10_000_000_000) totalOWO += Math.floor(value);
          }

          /* ===========================
             STRICT MONEY + LTC MATCH
          =========================== */

          /**
           Supports:
           $0.2
           0.2$
           0.2 usd
           0.2 ltc
           0.02 dollars
           0.02 cents -> auto converts to USD
          */

          let money = null;

          const dollar1 = content.match(/\$([\d.]+)/);             // $0.2
          const dollar2 = content.match(/([\d.]+)\$/);             // 0.2$
          const usd = content.match(/([\d.]+)\s*(usd|dollars)/);   // 0.2 usd
          const ltc = content.match(/([\d.]+)\s*ltc/);             // 0.2 ltc
          const cents = content.match(/([\d.]+)\s*cents?/);        // 0.2 cents

          if (dollar1) money = parseFloat(dollar1[1]);
          else if (dollar2) money = parseFloat(dollar2[1]);
          else if (usd) money = parseFloat(usd[1]);
          else if (ltc) money = parseFloat(ltc[1]);
          else if (cents) money = parseFloat(cents[1]) / 100;

          if (!isNaN(money) && money > 0 && money < 1_000_000)
            totalMoney += money;
        }

        last = messages.last().id;
        await new Promise(r => setTimeout(r, 350));
      }

      await msg.edit({
        embeds: [
          new client.embed().setDescription(
            `<a:veirfied:1443432591242956801> **Vouch Scan Complete!**\n\n` +
              `📌 **Channel:** ${channel}\n` +
              `📊 **Messages Scanned:** \`${scanned}\`\n\n` +
              `<a:owo:1442395441181229177> **Total OWO:** \`${totalOWO.toLocaleString()}\`\n` +
              `<a:ltc:1442395484802121822> **Total LTC / $:** \`${totalMoney.toFixed(2)}\``
          ),
        ],
      });
    } catch (err) {
      console.log("VOUCH COUNT ERROR", err);
      await msg.edit({
        embeds: [
          new client.embed().setDescription(
            `<:cross:1455452613645566147> Something went wrong while scanning.`
          ),
        ],
      });
    }
  },
};