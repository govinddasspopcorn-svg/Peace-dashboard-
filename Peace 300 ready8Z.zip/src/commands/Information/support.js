const {
  EmbedBuilder,
  MessageFlags,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

module.exports = {
  name: "support",
  category: "Information",
  aliases: ["supportserver", "help-server"],
  description: "Get help and support for the bot",
  args: false,
  usage: "",
  userPrams: [],
  botPrams: ["EMBED_LINKS"],
  owner: false,
  cooldown: 3,
  execute: async (message, args, client, prefix) => {
    const embed = new EmbedBuilder()
      .setAuthor({
        name: "💎 Premium Support Server",
        iconURL: client.user.displayAvatarURL(),
      })
      .setThumbnail(client.user.displayAvatarURL({ size: 1024 }))
      .setDescription(
        `**Need help with the bot?**\n\n` +
        `${client.emoji.dot} Get instant support from our team\n` +
        `${client.emoji.dot} Report bugs and issues\n` +
        `${client.emoji.dot} Request new features\n` +
        `${client.emoji.dot} Connect with other users\n` +
        `${client.emoji.dot} Stay updated with announcements\n\n` +
        `**${client.emoji.tick} Join our community today!**`
      )
      .setColor(client.color)
      .setFooter({
        text: "✨ We're here to help 24/7",
        iconURL: client.user.displayAvatarURL(),
      });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel("Join Support Server")
        .setStyle(ButtonStyle.Link)
        .setURL(client.config.links.support)
        .setEmoji("🔗"),
      new ButtonBuilder()
        .setLabel("Invite Bot")
        .setStyle(ButtonStyle.Link)
        .setURL(client.config.links.invite)
        .setEmoji("✨"),
      new ButtonBuilder()
        .setLabel("Vote")
        .setStyle(ButtonStyle.Link)
        .setURL(client.config.links.topgg)
        .setEmoji("⭐")
    );

    await message.reply({ embeds: [embed], components: [row] });
  },
};
