module.exports = {
  name: "ping",
  cooldown: 5,
  category: "Information",
  aliases: ["latency", "speed"],
  description: "Check bot's response time and API latency",
  execute: async (message, args, client, prefix) => {
    const start = Date.now();
    const msg = await message.reply({
      embeds: [
        new client.embed()
          .setAuthor({
            name: "⚡ Checking Latency...",
            iconURL: client.user.displayAvatarURL(),
          })
          .setDescription(`${client.emoji.loading} Please wait...`)
      ],
    });
    
    const latency = Date.now() - start;
    const apiLatency = client.ws.ping;
    const statusEmoji = apiLatency < 100 ? client.emoji.tick : apiLatency < 200 ? client.emoji.warn : client.emoji.cross;
    const status = apiLatency < 100 ? 'Excellent' : apiLatency < 200 ? 'Good' : 'Poor';
    const statusBar = apiLatency < 100 ? '🟢🟢🟢🟢🟢' : apiLatency < 200 ? '🟡🟡🟡🟡⚪' : '🔴🔴🔴⚪⚪';
    
    msg.edit({
      embeds: [
        new client.embed()
          .setAuthor({
            name: "⚡ Premium Bot Latency",
            iconURL: client.user.displayAvatarURL(),
          })
          .setThumbnail(client.user.displayAvatarURL({ size: 1024 }))
          .setDescription(
            `**${statusEmoji} Status:** ${status}\n` +
            `${statusBar}\n\n` +
            `**📊 Performance Metrics**\n` +
            `${client.emoji.dot} **Bot Latency:** \`${latency}ms\`\n` +
            `${client.emoji.dot} **API Latency:** \`${apiLatency}ms\`\n` +
            `${client.emoji.dot} **Uptime:** <t:${Math.round(Date.now() / 1000 - client.uptime / 1000)}:R>\n\n` +
            `**🌟 Quality:** Premium ${status} Connection`
          )
          .setFooter({
            text: `✨ Running on Premium Infrastructure`,
            iconURL: client.user.displayAvatarURL()
          })
      ],
    });
  },
};
