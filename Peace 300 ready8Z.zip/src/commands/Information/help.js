const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

module.exports = {
  name: "help",
  category: "Information",
  aliases: ["h"],
  description: "Help with all commands, or one specific command.",
  botParams: ["EmbedLinks", "SendMassges"],
  cooldown: 3,

  execute: async (message, args, client, prefix) => {

    // MAIN HELP PANEL
      const mainEmbed = new client.embed()
  .setAuthor({
    name: `${client.user.username} Premium Commands`,
    iconURL: client.user.displayAvatarURL(),
  })
  .d(`
**Prefix:** \`${prefix}\` • **Commands:** \`${client.slashCommands.size + client.commands.size}\`

**New Features:**

Select a category from the dropdown menu below to view all commands.
`)
  .addFields(
    {
      name: "`left column`",
      value: `
- Antinuke
- Drops
- Automod
- Config
- Extra
- Fun
- Giveaway
- Information
- Moderation
      `,
      inline: true
    },
    {
      name: "`right column`",
      value: `
- Music
- Pfp
- Playlist
- Profile
- Role
- Ticket
- Utility
- Voice
- Welcome
      `,
      inline: true
    }
  )
  .thumb(client.user.displayAvatarURL({ size: 1024 }))
  .setFooter({
    text: `* Serving ${client.guilds.cache.size} Servers • 300+ Commands`,
    iconURL: client.user.displayAvatarURL({ dynamic: true }),
  });

    // -------------------------
    // CATEGORY LIST (UPDATED)
    // -------------------------
    const commandCategories = [
      { label: "Antinuke", value: "antinuke" },
      { label: "Drops", value: "drops" },
      { label: "Automod", value: "automod" },
      { label: "Config", value: "config" },
      { label: "Extra", value: "extra" },
      { label: "Fun", value: "fun" },
      { label: "Giveaway", value: "giveaway" },
      { label: "Information", value: "information" },
      { label: "Moderation", value: "moderation" },
      { label: "Music", value: "music" },
      { label: "Pfp", value: "pfp" },
      { label: "Playlist", value: "playlist" },
      { label: "Profile", value: "profile" },
      { label: "Role", value: "role" },
      { label: "Ticket", value: "ticket" },
      { label: "Utility", value: "utility" },
      { label: "Voice", value: "voice" },
      { label: "Welcome", value: "welcome" },
    ];

    const categoryKeys = commandCategories.map(c => c.value);
    let index = 0; // Home page index

    // DROPDOWN MENU
    const dropdown = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("help_select")
        .setPlaceholder("Select a command category...")
        .addOptions(
          commandCategories.map(c => ({
            label: c.label,
            value: c.value,
            description: `Get all ${c.label} commands`,
          }))
        )
    );

    // NAVIGATION BUTTONS
    const navButtons = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("back_page")
        .setLabel("Back") // Replaced emoji with label
        .setStyle(ButtonStyle.Secondary),

      new ButtonBuilder()
        .setCustomId("home_page")
        .setLabel("Home") // Replaced emoji with label
        .setStyle(ButtonStyle.Danger),

      new ButtonBuilder()
        .setCustomId("next_page")
        .setLabel("Next") // Replaced emoji with label
        .setStyle(ButtonStyle.Secondary)
    );

    // SEND MAIN PANEL
    const sentMessage = await message.channel.send({
      embeds: [mainEmbed],
      components: [dropdown, navButtons],
    });

    // COLLECTOR (1 hour)
    const collector = sentMessage.createMessageComponentCollector({
      filter: (i) => i.user.id === message.author.id,
      time: 3600000,
    });

    // FUNCTION TO SEND CATEGORY EMBED
    async function sendCategory(interaction, selected) {
      const cmds = client.commands
        .filter(cmd => cmd.category?.toLowerCase() === selected)
        .map(cmd => `\`${cmd.name}\``);

      let highlights = "";
      if (selected === "utility") {
        highlights = `\n\n**New Commands:**\n\`membercount\` • \`channelinfo\` • \`emojiinfo\` • \`rolemembers\``;
      }
      if (selected === "moderation") {
        highlights = `\n\n**Enhanced:**\n\`warn\` • \`warnings\` • \`unwarn\``;
      }

      const catName = selected.charAt(0).toUpperCase() + selected.slice(1);

      const catEmbed = new client.embed()
        .setTitle(`${catName} Commands`)
        .d(`${cmds.join(" • ") || "No commands found"}${highlights}`)
        .setFooter({
          text: `* ${cmds.length} Commands • Use ${prefix}help <command>`,
          iconURL: client.user.displayAvatarURL({ dynamic: true }),
        });

      return interaction.update({
        embeds: [catEmbed],
        components: [dropdown, navButtons],
      });
    }

    // COLLECTOR EVENTS
    collector.on("collect", async (interaction) => {
      const id = interaction.customId;

      if (id === "home_page") {
        index = 0;
        return interaction.update({
          embeds: [mainEmbed],
          components: [dropdown, navButtons],
        });
      }

      if (id === "next_page") {
        if (index === 0) index = 1;
        else index++;

        if (index > categoryKeys.length) index = 1;
        return sendCategory(interaction, categoryKeys[index - 1]);
      }

      if (id === "back_page") {
        if (index === 0) index = categoryKeys.length;
        else index--;

        if (index < 1) index = categoryKeys.length;
        return sendCategory(interaction, categoryKeys[index - 1]);
      }

      if (interaction.isStringSelectMenu()) {
        const selected = interaction.values[0];
        index = categoryKeys.indexOf(selected) + 1;
        return sendCategory(interaction, selected);
      }
    });

    collector.on("end", () => {
      sentMessage.edit({ components: [] }).catch(() => {});
    });
  },
};
