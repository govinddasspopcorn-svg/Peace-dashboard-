/** @format
 *
 * Premium Discord Bot
 * © 2025 Peace Development
 *
 */

const {
  EmbedBuilder,
  MessageFlags,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ComponentType,
} = require("discord.js");

module.exports = {
  name: "team",
  category: "Information",
  aliases: ["developers", "devs"],
  description: "Meet the development team behind this premium bot",
  args: false,
  usage: "",
  owner: false,
  cooldown: 3,
  execute: async (message, args, client, prefix, interaction) => {
    const ozuma = await client.users.fetch(`1266043322129059925`);
    const kabbu = await client.users.fetch(`1266043322129059925`);
    const ayush = await client.users.fetch(`1266043322129059925`);

    const embedt = new EmbedBuilder()
      .setAuthor({
        name: `👑 ${client.user.username} Development Team`,
        iconURL: client.user.displayAvatarURL({ size: 2048 }),
      })
      .setDescription(
        `**Welcome, ${message.author.username}!**\n\n` +
        `Meet the talented team behind this premium Discord bot. ` +
        `We've crafted a powerful, feature-rich bot with 155+ commands to enhance your Discord experience.\n\n` +
        `**✨ Select a team member below to learn more about them**`
      )
      .setColor(client.color)
      .setThumbnail(client.user.displayAvatarURL({ size: 1024 }))
      .setFooter({
        text: client.config.links.power,
        iconURL: message.author.displayAvatarURL({ dynamic: true }),
      });

    const row = new ActionRowBuilder().addComponents([
      new ButtonBuilder()
        .setStyle(ButtonStyle.Primary)
        .setCustomId("1")
        .setLabel("🏠 Home")
    ]);

    const devsbaby = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("teamm")
        .setPlaceholder("👥 Select a team member")
        .addOptions([
          {
            label: `${ozuma.displayName}`,
            value: `${ozuma.username}`,
            description: "Lead Developer & Owner",
            emoji: "👑",
          },
          {
            label: `${kabbu.displayName}`,
            value: `${kabbu.username}`,
            description: "Co-Developer",
            emoji: "💻",
          },
          {
            label: `${ayush.displayName}`,
            value: `${ayush.username}`,
            description: "Project Manager",
            emoji: "⚡",
          },
        ]),
    );
    const msg = await message.channel.send({
      embeds: [embedt],
      components: [devsbaby],
    });
    const collector = await msg.createMessageComponentCollector({
      filter: (i) => {
        if (message.author.id === i.user.id) return true;
        else {
          i.reply({
            content: `${client.emoji.cross} | That's not your session run : \`${prefix}team\` to create your own.`,
            ephemeral: true,
          });
        }
      },
      time: 100000,
    });
    const oembed = new EmbedBuilder()
      .setThumbnail(ozuma.displayAvatarURL({ size: 1024 }))
      .setAuthor({
        name: `👑 ${ozuma.displayName}`,
        iconURL: ozuma.displayAvatarURL(),
      })
      .setFooter({
        text: `✨ Lead Developer & Owner`,
        iconURL: client.user.displayAvatarURL(),
      })
      .setDescription(
        `**${client.emoji.owner} Lead Developer**\n` +
        `[@${ozuma.displayName}](https://discord.com/users/${ozuma.id})\n` +
        `**User ID:** \`${ozuma.id}\`\n\n` +
        `**${client.emoji.dot} About**\n` +
        `The mastermind behind this premium Discord bot. Responsible for core development, features, and overall bot architecture.\n\n` +
        `**${client.emoji.dot} Links**\n` +
        `${client.emoji.discord} [Support Server](${client.config.links.support})\n` +
        `${client.emoji.discord} [Invite Bot](${client.config.links.invite})`
      )
      .setColor(client.color);

    const kembed = new EmbedBuilder()
      .setThumbnail(kabbu.displayAvatarURL({ size: 1024 }))
      .setAuthor({
        name: `💻 ${kabbu.displayName}`,
        iconURL: kabbu.displayAvatarURL(),
      })
      .setFooter({
        text: `✨ Co-Developer`,
        iconURL: client.user.displayAvatarURL(),
      })
      .setDescription(
        `**${client.emoji.dev} Co-Developer**\n` +
        `[@${kabbu.displayName}](https://discord.com/users/${kabbu.id})\n` +
        `**User ID:** \`${kabbu.id}\`\n\n` +
        `**${client.emoji.dot} About**\n` +
        `Contributing developer helping to build and maintain this premium bot with cutting-edge features.\n\n` +
        `**${client.emoji.dot} Links**\n` +
        `${client.emoji.discord} [Support Server](${client.config.links.support})\n` +
        `${client.emoji.discord} [Invite Bot](${client.config.links.invite})`
      )
      .setColor(client.color);

    const aembed = new EmbedBuilder()
      .setThumbnail(ayush.displayAvatarURL({ size: 1024 }))
      .setAuthor({
        name: `⚡ ${ayush.displayName}`,
        iconURL: ayush.displayAvatarURL(),
      })
      .setFooter({
        text: `✨ Project Manager`,
        iconURL: client.user.displayAvatarURL(),
      })
      .setDescription(
        `**${client.emoji.admin} Project Manager**\n` +
        `[@${ayush.displayName}](https://discord.com/users/${ayush.id})\n` +
        `**User ID:** \`${ayush.id}\`\n\n` +
        `**${client.emoji.dot} About**\n` +
        `Managing the development roadmap and ensuring this bot delivers premium quality to all users.\n\n` +
        `**${client.emoji.dot} Links**\n` +
        `${client.emoji.discord} [Support Server](${client.config.links.support})\n` +
        `${client.emoji.discord} [Invite Bot](${client.config.links.invite})`
      )
      .setColor(client.color)

    collector.on("collect", async (i) => {
      if (i.isStringSelectMenu()) {
        for (const value of i.values) {
          if (value === ozuma.username) {
            return i.update({ embeds: [oembed], components: [devsbaby, row] });
          }
          if (value === kabbu.username) {
            return i.update({ embeds: [kembed], components: [devsbaby, row] });
          }
          if (value === ayush.username) {
            return i.update({ embeds: [aembed], components: [devsbaby, row] });
          }
        }
      }
      if (i.isButton()) {
        if (i.customId === "1")
          await i.update({ embeds: [embedt], components: [devsbaby] });
      }
    });
    collector.on("end", async (i) => {
      if (!msg) return;
      msg.edit({
        embeds: [embedt],
        components: [],
        content: `${client.emoji.tick} | Team command session ended. Run \`${prefix}team\` to view again.`,
      });
    });
  },
};
