const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "accage",
  category: "Utility",
  description: "Shows account age and server join date",
  aliases: ["accountage", "age"],
  args: false,
  usage: "[@user]",

  async execute(message, args, client) {
    const user =
      message.mentions.users.first() ||
      client.users.cache.get(args[0]) ||
      message.author;

    const member = await message.guild.members.fetch(user.id).catch(() => null);
    if (!member)
      return message.reply(
        `${client.emoji.cross} User is not in this server.`
      );

    const createdAt = Math.floor(user.createdTimestamp / 1000);
    const joinedAt = Math.floor(member.joinedTimestamp / 1000);

    const embed = new EmbedBuilder()
      .setColor(client.colors.info)
      .setAuthor({
        name: `${user.tag}`,
        iconURL: user.displayAvatarURL({ dynamic: true }),
      })
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setDescription(
        `${client.emoji.profile} **Account Details**\n\n` +
        `${client.emoji.information} **User ID:** \`${user.id}\`\n\n` +
        `${client.emoji.config} **Account Created:** <t:${createdAt}:F>\n` +
        `${client.emoji.loading} **Account Age:** <t:${createdAt}:R>\n\n` +
        `${client.emoji.join} **Joined This Server:** <t:${joinedAt}:F>\n` +
        `${client.emoji.voice} **Time In Server:** <t:${joinedAt}:R>`
      )
      .setFooter({
        text: `Requested by ${message.author.tag}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true }),
      });

    message.channel.send({ embeds: [embed] });
  },
};
