const { EmbedBuilder } = require("discord.js");

if (!globalThis.fetch)
  globalThis.fetch = (...a)=>import("node-fetch").then(({default:f})=>f(...a));

module.exports = {
  name: "girls",
  aliases: ["waifu"],
  category: "Fun",

  execute: async (...args) => {
    let message = args[0]?.author ? args[0] : args[1];

    try {
      const res = await fetch("https://nekos.best/api/v2/waifu");
      const data = await res.json();

      const img = data.results?.[0]?.url;
      if (!img) return message.channel.send("❌ No image found.");

      return message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor("#ff9adc")
            .setTitle("👧 Anime Girl")
            .setImage(img)
        ]
      });
    } catch {
      return message.channel.send("❌ Failed to load image.");
    }
  },

  run: async (...args) => module.exports.execute(...args)
};