const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "wallpaper",
  aliases: ["wall"],
  category: "Fun",

  execute: async (...args) => {
    let message = args[0]?.author ? args[0] : args[1];

    const wallpapers = [
      "https://i.pinimg.com/736x/d6/4d/1d/d64d1d4645daadb9d0c7ac88818170be.jpg",
      "https://i.pinimg.com/236x/9e/c6/93/9ec693267d09d8a947cb7b2c57be0b12.jpg",
      "https://i.pinimg.com/736x/15/dd/5b/15dd5bd0f82cf5f2e7ebe4e646123607.jpg",
      "https://i.pinimg.com/236x/63/b1/09/63b109f66c5c5f203dae8efbe7cb9710.jpg",
      "https://i.pinimg.com/236x/66/ea/ec/66eaec32b8519212954be7c77bee408c.jpg",
      "https://i.pinimg.com/1200x/5e/af/14/5eaf14482349f5e01612e89b471b825e.jpg",
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQGZBrFmIKlZCcz9wP09JET2lsQIxoLeO7PisVsYmPCVTV_HpJXeDxXFsM&s=10",
      "https://i.pinimg.com/736x/60/38/d9/6038d95bd63b37e50e70796e92b4e542.jpg",
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRB0VzSzDfjKqA91gLVffNuuOuY2ITJIEnH9BQZRW6kXg&s=10",
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRvGsgoG3sik9pJL0LnIqfoVPoe30uqNwos14fJm8jBWwAySXud_X1vo34&s=10"
    ];

    const random = wallpapers[Math.floor(Math.random() * wallpapers.length)];

    return message.channel.send({
      embeds: [
        new EmbedBuilder()
          .setColor("#00ffd0")
          .setTitle("🌄 HD Wallpaper")
          .setImage(random)
      ]
    }).catch(() => {});
  },

  run: async (...args) => module.exports.execute(...args)
};