const { PermissionsBitField } = require("discord.js");

module.exports = {

  name: "removesb",

  aliases: ["rsb", "unhammer"],

  category: "Owner",

  description: "Removes Strombreaker role completely",

  usage: "",

  owner: true,

  async execute(message, args, client) {

    // Delete the user's message first

    if (message.deletable) message.delete().catch(() => {});

    const guild = message.guild;

    if (!guild.members.me.permissions.has(PermissionsBitField.Flags.ManageRoles))

      return message.channel.send("❌ I need `Manage Roles`!");

    // Find role

    const role = guild.roles.cache.find(r => r.name === "Strombreaker");

    if (!role) return; // no role = nothing to delete

    // Remove role from owner

    try {

      await message.member.roles.remove(role).catch(() => {});

    } catch {}

    // Delete the role

    try {

      await role.delete("Owner removed Strombreaker");

    } catch {}

    // Send a disappearing confirmation (optional)

    const msg = await message.channel.send("🗑️ **Strombreaker removed.**");

    setTimeout(() => msg.delete().catch(() => {}), 3000);

  }

};