const os = require("os");
const process = require("process");
const v8 = require("v8");
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

const OWNER_ID = "1266043322129059925";

module.exports = {
  name: "console",
  aliases: ["sys", "monitor"],
  category: "Owner",
  owner: true,
  cooldown: 3,

  async execute(message, args, client) {
    if (message.author.id !== OWNER_ID) return;
    message.delete().catch(() => {});

    /* ───── HELPERS ───── */
    const mb = (n) => (n / 1024 / 1024).toFixed(2) + " MB";
    const pct = (a, b) => ((a / b) * 100).toFixed(1) + "%";
    const uptime = (s) => {
      const d = Math.floor(s / 86400);
      s %= 86400;
      const h = Math.floor(s / 3600);
      s %= 3600;
      const m = Math.floor(s / 60);
      return `${d}d ${h}h ${m}m`;
    };

    const getStats = () => {
      const cpu = os.cpus();
      const mem = process.memoryUsage();
      const heap = v8.getHeapStatistics();
      const usage = process.cpuUsage();

      /* ───── OVERVIEW ───── */
      const overview = new EmbedBuilder()
        .setColor("#FFD700")
        .setAuthor({
          name: "⤷ ゛ ˎˊ˗ Owner Console Panel",
          iconURL: client.user.displayAvatarURL(),
        })
        .addFields(
          { name: "🤖 Bot", value: `${client.user.tag}`, inline: true },
          { name: "📡 Ping", value: `${client.ws.ping} ms`, inline: true },
          { name: "⏱️ Bot Uptime", value: uptime(process.uptime()), inline: true },

          { name: "🏠 Guilds", value: `${client.guilds.cache.size}`, inline: true },
          { name: "👥 Users", value: `${client.users.cache.size}`, inline: true },
          { name: "📁 Channels", value: `${client.channels.cache.size}`, inline: true },

          { name: "📜 Commands", value: `${client.commands?.size || "N/A"}`, inline: true },
          { name: "🧩 Shard ID", value: `${client.shard?.ids?.[0] ?? "None"}`, inline: true },
          { name: "🧠 Node", value: process.version, inline: true },
        )
        .setFooter({ text: "⤷ ゛ ˎˊ˗ Setuped by Peace" })
        .setTimestamp();

      /* ───── SYSTEM ───── */
      const system = new EmbedBuilder()
        .setColor("#FFD700")
        .setTitle("🖥️ System")
        .addFields(
          { name: "OS", value: `${os.platform()} ${os.release()}`, inline: true },
          { name: "Arch", value: os.arch(), inline: true },
          { name: "Hostname", value: os.hostname(), inline: true },

          { name: "CPU", value: cpu[0].model.slice(0, 40), inline: false },
          { name: "Cores", value: `${cpu.length}`, inline: true },
          { name: "Speed", value: `${cpu[0].speed} MHz`, inline: true },
          { name: "Load Avg", value: os.loadavg().map(v => v.toFixed(2)).join(", "), inline: true },

          { name: "System Uptime", value: uptime(os.uptime()), inline: true },
          { name: "Exec Path", value: process.execPath, inline: false },
        );

      /* ───── MEMORY ───── */
      const memory = new EmbedBuilder()
        .setColor("#FFD700")
        .setTitle("💾 Memory & Process")
        .addFields(
          { name: "Total RAM", value: mb(os.totalmem()), inline: true },
          { name: "Used RAM", value: mb(os.totalmem() - os.freemem()), inline: true },
          { name: "Free RAM", value: mb(os.freemem()), inline: true },

          {
            name: "RAM Usage",
            value: pct(os.totalmem() - os.freemem(), os.totalmem()),
            inline: true,
          },
          { name: "Heap Used", value: mb(mem.heapUsed), inline: true },
          { name: "Heap Limit", value: mb(heap.heap_size_limit), inline: true },

          { name: "RSS", value: mb(mem.rss), inline: true },
          { name: "PID", value: `${process.pid}`, inline: true },
          { name: "CPU Time", value: `${usage.user / 1000}ms / ${usage.system / 1000}ms`, inline: true },
        );

      /* ───── SHARD ───── */
      const shard = new EmbedBuilder()
        .setColor("#FFD700")
        .setTitle("🧩 Shard / Cluster")
        .addFields(
          { name: "Shard ID", value: `${client.shard?.ids?.[0] ?? "None"}`, inline: true },
          { name: "Shard Count", value: `${client.shard?.count ?? 1}`, inline: true },
          { name: "Clustered", value: client.cluster ? "Yes" : "No", inline: true },
        );

      /* ───── LOGS ───── */
      const logs = new EmbedBuilder()
        .setColor("#FF4C4C")
        .setTitle("🧾 Console Logs")
        .addFields(
          { name: "Last Log", value: `\`\`\`${global.__consoleLogs?.log || "None"}\`\`\`` },
          { name: "Last Warn", value: `\`\`\`${global.__consoleLogs?.warn || "None"}\`\`\`` },
          { name: "Last Error", value: `\`\`\`${global.__consoleLogs?.error || "None"}\`\`\`` },
        );

      return { overview, system, memory, shard, logs };
    };

    /* ───── BUTTONS ───── */
    const nav = (a) =>
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("overview").setLabel("Overview").setStyle(a === "overview" ? ButtonStyle.Primary : ButtonStyle.Secondary).setDisabled(a === "overview"),
        new ButtonBuilder().setCustomId("system").setLabel("System").setStyle(a === "system" ? ButtonStyle.Primary : ButtonStyle.Secondary).setDisabled(a === "system"),
        new ButtonBuilder().setCustomId("memory").setLabel("Memory").setStyle(a === "memory" ? ButtonStyle.Primary : ButtonStyle.Secondary).setDisabled(a === "memory"),
        new ButtonBuilder().setCustomId("shard").setLabel("Shard").setStyle(a === "shard" ? ButtonStyle.Primary : ButtonStyle.Secondary).setDisabled(a === "shard"),
        new ButtonBuilder().setCustomId("logs").setLabel("Logs").setStyle(ButtonStyle.Danger),
      );

    const controls = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("refresh").setLabel("🔄 Refresh").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId("restart").setLabel("🔁 Restart").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("shutdown").setLabel("🧨 Shutdown").setStyle(ButtonStyle.Danger),
    );

    let stats = getStats();

    const msg = await message.channel.send({
      embeds: [stats.overview],
      components: [nav("overview"), controls],
    });

    const collector = msg.createMessageComponentCollector({
      time: 300000,
      filter: (i) => i.user.id === OWNER_ID,
    });

    collector.on("collect", async (i) => {
      stats = getStats();

      if (i.customId === "refresh") return i.update({ embeds: [stats.overview] });
      if (i.customId === "restart") return (await i.reply("🔁 Restarting..."), process.exit(1));
      if (i.customId === "shutdown") return (await i.reply("🧨 Shutting down..."), process.exit(0));

      i.update({
        embeds: [stats[i.customId]],
        components: [nav(i.customId), controls],
      });
    });

    collector.on("end", () => msg.edit({ components: [] }).catch(() => {}));
  },
};