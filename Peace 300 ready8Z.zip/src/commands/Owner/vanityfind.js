const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "rr",
  aliases: ["fastreactremove"],
  category: "Utility",
  description: "Fast reaction remover with instant delete + tick",

  execute: async (message, args, client, prefix) => {
    const channel = message.channel;

    // Delete rr instantly
    message.delete().catch(() => {});

    // Send instant tick message
    const status = await channel.send({
      embeds: [
        new EmbedBuilder()
          .setColor(client.color)
          .setDescription(
            `${client.emoji.tick || "✅"} | Removing reactions from last **50 messages**…`
          ),
      ],
    });

    let removed = 0;

    try {
      const messages = await channel.messages.fetch({ limit: 50 });

      const tasks = [];
      for (const m of messages.values()) {
        if (m.reactions.cache.size > 0) {
          tasks.push(
            m.reactions
              .removeAll()
              .then(() => removed++)
              .catch(() => {})
          );
        }
      }

      await Promise.all(tasks);

      await status.edit({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setTitle("Reaction Cleanup Completed")
            .setDescription(
              `${client.emoji.tick || "✅"} | Removed reactions from **${removed} messages**`
            ),
        ],
      });

      setTimeout(() => status.delete().catch(() => {}), 3000);
    } catch {
      await status.edit({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(
              `${client.emoji.cross || "❌"} | Failed removing some reactions.`
            ),
        ],
      });

      setTimeout(() => status.delete().catch(() => {}), 3000);
    }
  },
};