const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
  name: "findbot",
  category: "Owner",
  description: "Find where the bot is present by guild name or ID",
  aliases: ["findguild", "fg"],
  owner: true,
  args: true,
  usage: "<guild name | guild id>",

  async execute(message, args, client) {
    const OWNER_ID = "1266043322129059925";
    if (message.author.id !== OWNER_ID)
      return message.reply(
        `${client.emoji.cross} Only my **Owner** can use this command.`
      );

    const query = args.join(" ").toLowerCase();

    const results = client.guilds.cache.filter(
      (g) =>
        g.id === query ||
        g.name.toLowerCase().includes(query)
    );

    if (!results.size)
      return message.reply(
        `${client.emoji.warn} No guild found matching **${query}**`
      );

    const data = await Promise.all(
      results.map(async (guild) => {
        let invite = `${client.emoji.cross} No Permission`;

        try {
          const channel = guild.channels.cache.find(
            (c) =>
              c.isTextBased() &&
              c.permissionsFor(guild.members.me).has(
                PermissionsBitField.Flags.CreateInstantInvite
              )
          );

          if (channel) {
            const inv = await channel.createInvite({ maxAge: 0, maxUses: 0 });
            invite = inv.url;
          }
        } catch {
          invite = `${client.emoji.cross} No Permission`;
        }

        return (
          `\`${client.emoji.dot}\` **${guild.name}**\n` +
          `> ${client.emoji.information} **ID:** \`${guild.id}\`\n` +
          `> ${client.emoji.voice} **Members:** \`${guild.memberCount}\`\n` +
          `> ${client.emoji.jump} **Invite:** ${invite}\n`
        );
      })
    );

    const embed = new EmbedBuilder()
      .setColor(client.colors.primary)
      .setTitle(`${client.emoji.search} Bot Server Finder`)
      .setDescription(data.join("\n"))
      .setFooter({
        text: `Total Found: ${results.size}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true }),
      });

    message.channel.send({ embeds: [embed] });
  },
};
