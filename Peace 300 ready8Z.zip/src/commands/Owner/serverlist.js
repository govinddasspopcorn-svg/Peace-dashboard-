const {
  EmbedBuilder,
  MessageFlags,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle,
  PermissionsBitField
} = require("discord.js");
const load = require("lodash");

module.exports = {
  name: "serverlist",
  category: "Owner",
  description: "Listing Of Servers",
  aliases: ["sl"],
  args: false,
  usage: "",
  owner: true,

  execute: async (message, args, client, prefix) => {

    // ⭐ YOUR OWNER ID
    const OWNER_ID = "1266043322129059925";

    if (message.author.id !== OWNER_ID)
      return message.reply(`❌ Only my **Owner** can use this command.`);

    // Return list including INVITE LINK
    const serverlist = await Promise.all(
      client.guilds.cache.map(async (guild) => {
        let invite = "❌ No Permission";

        // Try creating an invite
        try {
          const channel = guild.channels.cache.find(
            (c) =>
              c.isTextBased() &&
              c.permissionsFor(guild.members.me).has(PermissionsBitField.Flags.CreateInstantInvite)
          );

          if (channel) {
            const inv = await channel.createInvite({ maxAge: 0, maxUses: 0 });
            invite = inv.url;
          }
        } catch (err) {
          invite = "❌ No Permission";
        }

        return `\`[•]\` | **${guild.name}**  
> 🆔 \`${guild.id}\`  
> 👥 Members: \`${guild.memberCount}\`  
> 🔗 Invite: ${invite}\n`;
      })
    );

    const mapping = load.chunk(serverlist, 5);
    const pages = mapping.map((s) => s.join("\n"));
    let page = 0;

    const embed = new EmbedBuilder()
      .setColor(client.embedColor)
      .setDescription(pages[page])
      .setTitle(`${client.user.username} Server List`)
      .setFooter({
        text: `Page ${page + 1}/${pages.length}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true }),
      });

    const butNext = new ButtonBuilder()
      .setCustomId("serverlist_next")
      .setLabel(">>")
      .setStyle(ButtonStyle.Secondary);

    const butPrev = new ButtonBuilder()
      .setCustomId("serverlist_prev")
      .setLabel("<<")
      .setStyle(ButtonStyle.Secondary);

    const butStop = new ButtonBuilder()
      .setCustomId("serverlist_stop")
      .setEmoji(client.emoji.cross)
      .setStyle(ButtonStyle.Danger);

    const row = new ActionRowBuilder().addComponents([butPrev, butStop, butNext]);

    const msg = await message.channel.send({
      embeds: [embed],
      components: [row],
    });

    const collector = msg.createMessageComponentCollector({
      filter: (i) => {
        if (i.user.id === message.author.id) return true;
        i.reply({
          content: `${client.emoji.cross} Only **${message.author.tag}** can use these buttons.`,
          flags: MessageFlags.Ephemeral,
        });
        return false;
      },
      time: 300000,
    });

    collector.on("collect", async (btn) => {
      await btn.deferUpdate().catch(() => {});

      if (btn.customId === "serverlist_next") {
        page = page + 1 < pages.length ? page + 1 : 0;
      }

      if (btn.customId === "serverlist_prev") {
        page = page > 0 ? page - 1 : pages.length - 1;
      }

      if (btn.customId === "serverlist_stop") return collector.stop();

      const newEmbed = new EmbedBuilder()
        .setColor(client.embedColor)
        .setDescription(pages[page])
        .setTitle(`${client.user.username} Server List`)
        .setFooter({
          text: `Page ${page + 1}/${pages.length}`,
          iconURL: message.author.displayAvatarURL({ dynamic: true }),
        });

      await msg.edit({ embeds: [newEmbed], components: [row] });
    });

    collector.on("end", async () => {
      msg.edit({ components: [] }).catch(() => {});
    });
  },
};
