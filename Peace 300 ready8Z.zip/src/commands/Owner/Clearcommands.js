module.exports = {
  name: "clearcommands",
  aliases: ["wipecommands", "resetcommands"],
  category: "owner",

  async execute(message, args, client, prefix) {

    if (message.author.id !== "1266043322129059925")
      return message.reply("❌ Only bot owner can use this command.");

    try {
      await client.application.commands.set([]);
      message.reply("✅ All slash commands cleared successfully.\n🔁 Restart bot & deploy again if needed.");
    } catch (err) {
      console.error(err);
      message.reply("❌ Failed to clear slash commands. Check console.");
    }
  }
};