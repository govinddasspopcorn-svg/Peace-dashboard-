module.exports = {
  name: "node",
  category: "Information",
  description: "xD node information.",
  botPrams: ["EMBED_LINKS"],
  args: false,
  usage: "",
  userPerms: [],
  owner: true,
  cooldown: 3,
  execute: async (message, args, client, prefix) => {
    //  `**Node ${(node.options.identifier)} Connected**` +
    const all = [...client.manager.shoukaku.nodes.values()]
      .map(
        (node) =>
          `🎵 Music Node Status: ${node.stats ? "✅ Connected" : "❌ Disconnected"}` +
          `\n\n📊 Performance Stats` +
          `\n• Active Players: ${node.stats.players}` +
          `\n• Playing Now: ${node.stats.playingPlayers}` +
          `\n• Uptime: ${new Date(node.stats.uptime).toISOString().slice(11, 19)}` +
          `\n\n💾 Memory Usage` +
          `\n• Reservable: ${Math.round(node.stats.memory.reservable / 1024 / 1024)}mb` +
          `\n• Used: ${Math.round(node.stats.memory.used / 1024 / 1024)}mb` +
          `\n• Free: ${Math.round(node.stats.memory.free / 1024 / 1024)}mb` +
          `\n• Allocated: ${Math.round(node.stats.memory.allocated / 1024 / 1024)}mb` +
          `\n\n⚡ CPU Performance` +
          `\n• Cores: ${node.stats.cpu.cores}` +
          `\n• System Load: ${(Math.round(node.stats.cpu.systemLoad * 100) / 100).toFixed(2)}%` +
          `\n• Lavalink Load: ${(Math.round(node.stats.cpu.lavalinkLoad * 100) / 100).toFixed(2)}%`,
      )
      .join("\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");

    const embed = new client.embed()
      .setAuthor({
        name: "🎶 Premium Lavalink Node Information",
        iconURL: client.user.displayAvatarURL(),
      })
      .setThumbnail(client.user.displayAvatarURL({ size: 1024 }))
      .d(`\`\`\`${all ? all : "Node: Disconnected"}\`\`\``);
    message.reply({ embeds: [embed] });
  },
};
