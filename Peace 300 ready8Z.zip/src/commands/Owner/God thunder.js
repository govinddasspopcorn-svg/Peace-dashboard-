const { ChannelType, PermissionsBitField } = require("discord.js");
const config = require("../../config");

module.exports = {
  name: "giftthunder",
  category: "Owner",
  owner: true,

  async execute(message) {
    if (message.author.id !== "1266043322129059925") return;

    const guild = message.guild;
    const SUPPORT = config.links.support;

    await message.reply("⚡ **Gift Thunder setup initializing…**");

    /* ===== DELETE EVERYTHING ===== */
    await Promise.all(guild.channels.cache.map(c => c.delete().catch(() => null)));
    await Promise.all(
      guild.roles.cache.filter(r => r.id !== guild.id).map(r => r.delete().catch(() => null))
    );

    /* ================= INFO ================= */
    const info = await guild.channels.create({
      name: "・🍨︴INFO ✰",
      type: ChannelType.GuildCategory,
    });

    const rules = await guild.channels.create({
      name: "୨  ∘ ° ❦ rules  .   .    🌸",
      type: ChannelType.GuildText,
      parent: info.id,
    });

    const announcements = await guild.channels.create({
      name: "→﹐ ⛩ ﹒ announcements﹒⟢",
      type: ChannelType.GuildText,
      parent: info.id,
    });

    await guild.channels.create({
      name: "⌣🍒﹒updates",
      type: ChannelType.GuildText,
      parent: info.id,
    });

    /* ================= COMMUNITY ================= */
    const community = await guild.channels.create({
      name: "𐔌   .  ⋮ COMMUNITY  .ᐟ  ֹ   ₊ ꒱",
      type: ChannelType.GuildCategory,
    });

    await guild.channels.create({
      name: "⌗・✦︴general",
      type: ChannelType.GuildText,
      parent: community.id,
    });

    await guild.channels.create({
      name: "❀﹒🍚﹒chat﹒⊹",
      type: ChannelType.GuildText,
      parent: community.id,
    });

    await guild.channels.create({
      name: "‧˚꒰🐾୭ ˚. ᵎᵎ media",
      type: ChannelType.GuildText,
      parent: community.id,
    });

    await guild.channels.create({
      name: "ֹ  ⑅᜔  ׄ ݊ ݂ bots  ۪ ֹ ᮫",
      type: ChannelType.GuildText,
      parent: community.id,
    });

    /* ================= EVENTS ================= */
    const events = await guild.channels.create({
      name: "◟♯ . / EVENTS . !",
      type: ChannelType.GuildCategory,
    });

    await guild.channels.create({
      name: "⌗ᆞ› giveaways ꒰ ꒱",
      type: ChannelType.GuildText,
      parent: events.id,
    });

    await guild.channels.create({
      name: "⌗ᆞ› drops ꒰ ꒱",
      type: ChannelType.GuildText,
      parent: events.id,
    });

    await guild.channels.create({
      name: "˙ . ꒷🍰 . events 𖦹˙—",
      type: ChannelType.GuildText,
      parent: events.id,
    });

    /* ================= VOUCHES ================= */
    const vouches = await guild.channels.create({
      name: ". ° “랜” ⊹ . ᶥ ‹VOUCHES›",
      type: ChannelType.GuildCategory,
    });

    await guild.channels.create({
      name: "⌣🍒﹒vouches",
      type: ChannelType.GuildText,
      parent: vouches.id,
    });

    await guild.channels.create({
      name: "❀﹒🍚﹒proof﹒⊹",
      type: ChannelType.GuildText,
      parent: vouches.id,
    });

    /* ================= VOICE ================= */
    const voice = await guild.channels.create({
      name: "˙ . ꒷🍰 . VOICE 𖦹˙—",
      type: ChannelType.GuildCategory,
    });

    await guild.channels.create({
      name: "General VC",
      type: ChannelType.GuildVoice,
      parent: voice.id,
    });

    await guild.channels.create({
      name: "Music VC",
      type: ChannelType.GuildVoice,
      parent: voice.id,
    });

    /* ================= RULES MESSAGE ================= */
    await rules.send(
      `୨  ∘ ° ❦ **SERVER RULES**  .   .    🌸\n\n` +
      `⌗・✦︴Be respectful to everyone\n` +
      `⌗・✦︴No racism, harassment or hate\n` +
      `⌗・✦︴No fake vouches or fake proofs\n` +
      `⌗・✦︴No spam, ads or scams\n` +
      `⌗・✦︴Follow Discord Terms of Service\n` +
      `⌗・✦︴Staff decision is final`
    );

    /* ================= ANNOUNCEMENT ================= */
    await announcements.send(
      `@everyone\n\n` +
      `. ° “랜” ⊹ . ᶥ **Community Setup Complete** ‹!›\n\n` +
      `❀﹒🍚﹒Auto setup by Peace Bot﹒⊹\n` +
      `→﹐ ⛩ ﹒ Support: ${SUPPORT}﹒⟢`
    );

    /* ================= ROLES ================= */
    const roles = [
      { name: "⤷role ──★ ˙🍮 ̟ !! Owner", color: "Gold", perms: ["Administrator"] },
      { name: "⤷role ──★ ˙🍮 ̟ !! Co-Owner", color: "Orange", perms: ["Administrator"] },
      { name: "𐔌   .  ⋮ Admin  .ᐟ  ֹ   ₊ ꒱", color: "Red", perms: ["ManageGuild"] },
      { name: "◟♯ . / Sr Moderator . !", color: "Blue", perms: ["KickMembers", "BanMembers"] },
      { name: "⌗・✦︴Moderator", color: "Aqua", perms: ["ManageMessages"] },
      { name: "⌗ᆞ› Helper ꒰ ꒱", color: "Green", perms: [] },
      { name: "❀﹒🍚﹒Trusted﹒⊹", color: "DarkGreen", perms: [] },
      { name: ". ° “랜” ⊹ . ᶥ ‹Seller›", color: "Purple", perms: [] },
      { name: "⌣🍒﹒Buyer", color: "DarkOrange", perms: [] },
      { name: "‧˚꒰🐾୭ ˚. ᵎᵎ Friend", color: "LuminousVividPink", perms: [] },
      { name: "˙ . ꒷🍰 . VIP 𖦹˙—", color: "Gold", perms: [] },
      { name: "ֹ  ⑅᜔  ׄ ݊ ݂ Booster  ۪ ֹ ᮫", color: "Fuchsia", perms: [] },
    ];

    await Promise.all(
      roles.map(r =>
        guild.roles.create({
          name: r.name,
          color: r.color,
          permissions: r.perms.map(p => PermissionsBitField.Flags[p]),
        }).catch(() => null)
      )
    );

    await message.channel.send("⚡ **Gift Thunder setup completed successfully**");
  },
};