const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "emojiinfo",
  category: "Utility",
  aliases: ["ei", "emoji"],
  cooldown: 3,
  description: "Get information about a server emoji",
  args: true,
  usage: "<emoji>",
  userPerms: [],
  botPerms: [],
  owner: false,

  execute: async (message, args, client, prefix) => {
    // Parse emoji from argument
    const emojiMatch = args[0].match(/<?(a)?:?(\w+):(\d+)>?/);
    
    if (!emojiMatch) {
      return message.reply({
        embeds: [
          new client.embed()
            .setDescription(`${client.emoji.cross} | Please provide a valid custom emoji!`)
        ]
      });
    }

    const emojiId = emojiMatch[3];
    const emoji = message.guild.emojis.cache.get(emojiId) || await client.emojis.fetch(emojiId).catch(() => null);

    if (!emoji) {
      return message.reply({
        embeds: [
          new client.embed()
            .setDescription(`${client.emoji.cross} | Emoji not found!`)
        ]
      });
    }

    const embed = new client.embed()
      .setTitle("Emoji Information")
      .setThumbnail(emoji.url)
      .addFields([
        {
          name: "📛 Name",
          value: `\`${emoji.name}\``,
          inline: true
        },
        {
          name: "🆔 ID",
          value: `\`${emoji.id}\``,
          inline: true
        },
        {
          name: "✨ Animated",
          value: emoji.animated ? client.emoji.tick : client.emoji.cross,
          inline: true
        },
        {
          name: "📅 Created",
          value: `<t:${Math.floor(emoji.createdTimestamp / 1000)}:R>`,
          inline: true
        },
        {
          name: "🔗 URL",
          value: `[Click Here](${emoji.url})`,
          inline: true
        },
        {
          name: "📝 Format",
          value: `\`\`\`${emoji.toString()}\`\`\``,
          inline: false
        }
      ])
      .setFooter({
        text: `✨ Requested by ${message.author.username}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      });

    if (emoji.author) {
      embed.addFields({
        name: "👤 Created By",
        value: `${emoji.author.tag}`,
        inline: true
      });
    }

    message.reply({ embeds: [embed] });
  },
};
