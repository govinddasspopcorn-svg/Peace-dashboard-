const { EmbedBuilder, ChannelType } = require("discord.js");

module.exports = {
  name: "membercount",
  category: "Utility",
  aliases: ["mc", "members", "memberstats"],
  cooldown: 3,
  description: "Shows detailed member statistics of the server",
  args: false,
  usage: "",
  userPerms: [],
  botPerms: [],
  owner: false,

  execute: async (message, args, client, prefix) => {
    const guild = message.guild;
    
    // Fetch all members to ensure accuracy
    await guild.members.fetch();
    
    const totalMembers = guild.memberCount;
    const humans = guild.members.cache.filter(member => !member.user.bot).size;
    const bots = guild.members.cache.filter(member => member.user.bot).size;
    
    // Online status breakdown
    const online = guild.members.cache.filter(member => member.presence?.status === "online").size;
    const idle = guild.members.cache.filter(member => member.presence?.status === "idle").size;
    const dnd = guild.members.cache.filter(member => member.presence?.status === "dnd").size;
    const offline = guild.members.cache.filter(member => !member.presence || member.presence.status === "offline").size;
    
    // Role statistics
    const rolesCount = guild.roles.cache.size - 1; // -1 for @everyone
    
    // Calculate percentages
    const humanPercent = ((humans / totalMembers) * 100).toFixed(1);
    const botPercent = ((bots / totalMembers) * 100).toFixed(1);
    
    const embed = new client.embed()
      .setTitle(`📊 ${guild.name} Member Statistics`)
      .setThumbnail(guild.iconURL({ dynamic: true, size: 1024 }))
      .addFields([
        {
          name: "👥 Total Members",
          value: `\`\`\`${totalMembers.toLocaleString()}\`\`\``,
          inline: true
        },
        {
          name: "👤 Humans",
          value: `\`\`\`${humans.toLocaleString()} (${humanPercent}%)\`\`\``,
          inline: true
        },
        {
          name: "🤖 Bots",
          value: `\`\`\`${bots.toLocaleString()} (${botPercent}%)\`\`\``,
          inline: true
        },
        {
          name: "📊 Status Breakdown",
          value: `${client.emoji.online} **Online:** ${online}\n${client.emoji.idle} **Idle:** ${idle}\n${client.emoji.dnd} **DND:** ${dnd}\n${client.emoji.offline} **Offline:** ${offline}`,
          inline: true
        },
        {
          name: "🎭 Server Roles",
          value: `\`\`\`${rolesCount}\`\`\``,
          inline: true
        },
        {
          name: "👑 Owner",
          value: `<@${guild.ownerId}>`,
          inline: true
        }
      ])
      .setFooter({
        text: `✨ Requested by ${message.author.username} • ID: ${guild.id}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      });

    message.reply({ embeds: [embed] });
  },
};
