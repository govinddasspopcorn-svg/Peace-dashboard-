const { EmbedBuilder, ChannelType } = require("discord.js");

module.exports = {
  name: "channelinfo",
  category: "Utility",
  aliases: ["ci", "cinfo"],
  cooldown: 3,
  description: "Get detailed information about a channel",
  args: false,
  usage: "[channel]",
  userPerms: [],
  botPerms: [],
  owner: false,

  execute: async (message, args, client, prefix) => {
    const channel = message.mentions.channels.first() || 
                   message.guild.channels.cache.get(args[0]) || 
                   message.channel;

    const channelTypes = {
      [ChannelType.GuildText]: "📝 Text Channel",
      [ChannelType.GuildVoice]: "🔊 Voice Channel",
      [ChannelType.GuildCategory]: "📁 Category",
      [ChannelType.GuildAnnouncement]: "📢 Announcement",
      [ChannelType.GuildStageVoice]: "🎤 Stage Channel",
      [ChannelType.GuildForum]: "💬 Forum Channel",
    };

    const embed = new client.embed()
      .setTitle(`Channel Information`)
      .setDescription(`Information about ${channel}`)
      .addFields([
        {
          name: "📌 Channel Name",
          value: `\`${channel.name}\``,
          inline: true
        },
        {
          name: "🆔 Channel ID",
          value: `\`${channel.id}\``,
          inline: true
        },
        {
          name: "📂 Type",
          value: channelTypes[channel.type] || "Unknown",
          inline: true
        },
        {
          name: "📅 Created",
          value: `<t:${Math.floor(channel.createdTimestamp / 1000)}:R>`,
          inline: true
        },
        {
          name: "📍 Position",
          value: `\`${channel.position + 1}\``,
          inline: true
        },
        {
          name: "🔞 NSFW",
          value: channel.nsfw ? client.emoji.tick : client.emoji.cross,
          inline: true
        }
      ]);

    if (channel.topic) {
      embed.addFields({
        name: "📝 Topic",
        value: channel.topic.length > 1024 ? channel.topic.substring(0, 1020) + "..." : channel.topic,
        inline: false
      });
    }

    if (channel.parent) {
      embed.addFields({
        name: "📁 Category",
        value: `${channel.parent.name}`,
        inline: true
      });
    }

    if (channel.type === ChannelType.GuildVoice || channel.type === ChannelType.GuildStageVoice) {
      embed.addFields({
        name: "👥 User Limit",
        value: channel.userLimit === 0 ? "Unlimited" : `\`${channel.userLimit}\``,
        inline: true
      });
      
      embed.addFields({
        name: "🎚️ Bitrate",
        value: `\`${channel.bitrate / 1000}kbps\``,
        inline: true
      });
    }

    embed.setFooter({
      text: `✨ Requested by ${message.author.username}`,
      iconURL: message.author.displayAvatarURL({ dynamic: true })
    });

    message.reply({ embeds: [embed] });
  },
};
