const Vanity = require("../../schema/vanity");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "pvanity",
  category: "utility",
  description: "Track vanity words in user bios",
  userPerms: ["ManageGuild"],

  execute: async (message, args, client, prefix) => {
    const emoji = "<a:giveaway:1440153256964788306>";

    let color =
      typeof client.color === "string"
        ? parseInt(client.color.replace("#", ""), 16)
        : client.color || 0xffd700;

    const guildId = message.guild.id;

    let data =
      (await Vanity.findOne({ guildId })) ||
      (await Vanity.create({ guildId }));

    const sub = args[0]?.toLowerCase();

    // HELP MENU
    if (!sub)
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} Vanity Tracking System`)
            .setDescription(
              `> Tracks when users add/remove certain text in their **Discord Bio**\n\n` +
                `\`\`\`ini\n[ Commands ]\`\`\`\n` +
                `• ${prefix}vanity add <word>\n` +
                `• ${prefix}vanity remove <word>\n` +
                `• ${prefix}vanity list\n` +
                `• ${prefix}vanity channel <#log>\n` +
                `• ${prefix}vanity reset`
            )
            .setFooter({
              text: "Vanity System Active",
              iconURL: client.user.displayAvatarURL(),
            }),
        ],
      });

    // ADD WORD
    if (sub === "add") {
      const word = args[1]?.toLowerCase();
      if (!word)
        return message.reply("❌ Provide a vanity word to track");

      if (data.words.length >= 5)
        return message.reply("❌ Maximum **5** vanity words allowed");

      if (data.words.includes(word))
        return message.reply("❌ Already tracking this word");

      data.words.push(word);
      await data.save();

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} Vanity Added`)
            .setDescription(
              `\`\`\`ini\n[ Tracked Vanity Word ]\`\`\`\n${word}`
            ),
        ],
      });
    }

    // REMOVE WORD
    if (sub === "remove") {
      const word = args[1]?.toLowerCase();
      if (!word) return message.reply("❌ Provide a word to remove");

      if (!data.words.includes(word))
        return message.reply("❌ That word is not being tracked");

      data.words = data.words.filter((w) => w !== word);
      await data.save();

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} Vanity Removed`)
            .setDescription(
              `\`\`\`ini\n[ Removed Word ]\`\`\`\n${word}`
            ),
        ],
      });
    }

    // LIST
    if (sub === "list") {
      if (!data.words.length)
        return message.reply("❌ No vanity words being tracked yet");

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} Tracked Vanity Words`)
            .setDescription(
              `\`\`\`ini\n[ Active Words ]\`\`\`\n${data.words
                .map((w) => `• ${w}`)
                .join("\n")}`
            ),
        ],
      });
    }

    // SET LOG CHANNEL
    if (sub === "channel") {
      const ch = message.mentions.channels.first();
      if (!ch) return message.reply("❌ Mention the log channel");

      data.logChannel = ch.id;
      await data.save();

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} Vanity Log Channel Set`)
            .setDescription(
              `\`\`\`ini\n[ Logs Channel ]\`\`\`\n${ch}`
            ),
        ],
      });
    }

    // RESET
    if (sub === "reset") {
      data.words = [];
      data.tracked = {};
      await data.save();

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} Vanity System Reset`)
            .setDescription(
              `\`\`\`diff\n- All vanity tracking cleared\n\`\`\`\nSystem refreshed successfully`
            ),
        ],
      });
    }
  },
};