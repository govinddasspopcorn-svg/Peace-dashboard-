const Sticky = require("../../schema/sticky");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "sticky",
  aliases: [],
  category: "utility",
  description: "Sticky message system",
  userPerms: ["ManageGuild"],
  botPerms: ["SendMessages"],

  execute: async (message, args, client, prefix) => {
    const emoji = "<a:giveaway:1440153256964788306>";
    const color =
      typeof client.color === "string"
        ? parseInt(client.color.replace("#", ""), 16)
        : client.color || 0xffd700;

    const sub = args[0]?.toLowerCase();

    const helpEmbed = new EmbedBuilder()
      .setColor(color)
      .setTitle(`${emoji} Sticky System`)
      .setDescription(
        `> **Sticky messages stay at bottom of channel permanently**\n\n` +
          `\`\`\`ini\n[ Commands ]\`\`\`\n` +
          `• ${prefix}sticky add <#channel> <message>\n` +
          `• ${prefix}sticky edit <#channel> <message>\n` +
          `• ${prefix}sticky remove <#channel>\n` +
          `• ${prefix}sticky reset\n`
      )
      .setFooter({
        text: "Sticky Message Manager",
        iconURL: client.user.displayAvatarURL(),
      });

    if (!sub) return message.reply({ embeds: [helpEmbed] });

    // ADD
    if (sub === "add") {
      const channel = message.mentions.channels.first();
      const content = args.slice(2).join(" ");

      if (!channel) return message.reply("❌ Mention a channel");
      if (!content) return message.reply("❌ Provide sticky message");

      await Sticky.findOneAndUpdate(
        { guildId: message.guild.id, channelId: channel.id },
        { message: content, lastMessageId: null },
        { upsert: true }
      );

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} Sticky Added Successfully`)
            .setDescription(
              `\`\`\`ini\n[ Channel ]\`\`\`\n${channel}\n\n` +
                `\`\`\`ini\n[ Message ]\`\`\`\n${content}`
            )
            .setFooter({ text: "Sticky System Enabled" }),
        ],
      });
    }

    // EDIT
    if (sub === "edit") {
      const channel = message.mentions.channels.first();
      const content = args.slice(2).join(" ");

      if (!channel) return message.reply("❌ Mention a channel");
      if (!content) return message.reply("❌ Provide message");

      const sticky = await Sticky.findOne({
        guildId: message.guild.id,
        channelId: channel.id,
      });

      if (!sticky)
        return message.reply("❌ No sticky exists in that channel");

      sticky.message = content;
      await sticky.save();

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} Sticky Updated`)
            .setDescription(
              `\`\`\`ini\n[ Channel ]\`\`\`\n${channel}\n\n` +
                `\`\`\`diff\n+ New Sticky Message\n\`\`\`\n${content}`
            )
            .setFooter({ text: "Sticky Successfully Modified" }),
        ],
      });
    }

    // REMOVE
    if (sub === "remove") {
      const channel = message.mentions.channels.first();
      if (!channel) return message.reply("❌ Mention a channel");

      const sticky = await Sticky.findOne({
        guildId: message.guild.id,
        channelId: channel.id,
      });

      if (!sticky) return message.reply("❌ No sticky exists");

      await Sticky.deleteOne({
        guildId: message.guild.id,
        channelId: channel.id,
      });

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} Sticky Removed`)
            .setDescription(
              `\`\`\`ini\n[ Channel ]\`\`\`\n${channel}\n\nSticky message disabled.`
            )
            .setFooter({ text: "Sticky System Updated" }),
        ],
      });
    }

    // RESET
    if (sub === "reset") {
      await Sticky.deleteMany({ guildId: message.guild.id });

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} Sticky System Reset`)
            .setDescription(
              `\`\`\`diff\n- All sticky messages cleared\n\`\`\`\nSticky system refreshed successfully.`
            )
            .setFooter({ text: "Sticky Database Wiped" }),
        ],
      });
    }
  },
};