const ms = require("ms");

module.exports = {
  name: "remind",
  category: "Utility",
  description: "Set a reminder",
  execute: async (message, args, client, prefix) => {
    const time = args[0];
    const reason = args.slice(1).join(" ");

    if (!time || !ms(time)) return message.reply(`${client.emoji.cross} Please provide a valid time (e.g., 10m, 1h).`);
    if (!reason) return message.reply(`${client.emoji.cross} Please provide a reason for the reminder.`);

    message.reply({
      embeds: [
        new client.embed()
          .setAuthor({ name: "Reminder Set", iconURL: client.user.displayAvatarURL() })
          .setDescription(`${client.emoji.tick} I will remind you in **${time}**: ${reason}`)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
      ]
    });

    setTimeout(() => {
      message.author.send({
        embeds: [
          new client.embed()
            .setAuthor({ name: "Reminder Alert", iconURL: client.user.displayAvatarURL() })
            .setDescription(`🔔 **Reminder:** ${reason}`)
            .setTimestamp()
        ]
      }).catch(() => {
        message.channel.send(`${message.author}, 🔔 **Reminder:** ${reason}`);
      });
    }, ms(time));
  },
};