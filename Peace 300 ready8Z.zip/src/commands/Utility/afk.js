const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
} = require("discord.js");
const db = require("../../schema/afk");

function ordinal(n) {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

module.exports = {
  name: "afk",
  aliases: ["busy"],
  cooldown: 3,

  execute: async (message, args, client) => {
    const reason = args.join(" ") || "AFK";

    // =============================================
    // GLOBAL AFK LISTENER (REAL FIXED)
    // =============================================
    if (!client.__AFK_LISTENER__) {
      client.__AFK_LISTENER__ = true;

      client.on("messageCreate", async (msg) => {
        if (!msg.guild || msg.author.bot) return;

        // REMOVE AFK WHEN USER TALKS
        const self = await db.findOne({ Member: msg.author.id });

        if (self) {
          const afkTime = Math.floor(self.Time / 1000);

          let mentionsText = "No one mentioned you 🙂";

          if (self.Mentions?.length > 0) {
            mentionsText = self.Mentions
              .map(
                (m, i) =>
                  `[${ordinal(i + 1)}](${m.messageUrl})`
              )
              .join(", "); // <<<<<< COMMA FIX
          }

          const embed = new EmbedBuilder()
            .setColor(client.color)
            .setAuthor({
              name: `Welcome Back ${msg.author.username}`,
              iconURL: msg.author.displayAvatarURL(),
            })
            .setDescription(
              `${client.emoji.tick} **AFK Removed**\nYou were AFK **<t:${afkTime}:R>**`
            )
            .addFields([
              {
                name: "Mentions While You Were Gone",
                value: mentionsText,
                inline: false,
              },
            ]);

          await db.deleteOne({ Member: msg.author.id }).catch(() => {});
          return msg.channel.send({ embeds: [embed] }).catch(() => {});
        }

        // LOG & REPLY IF MENTION IS AFK
        const mentioned = msg.mentions.members?.first();
        if (!mentioned) return;

        const data = await db.findOne({ Member: mentioned.id });
        if (!data) return;

        await db.updateOne(
          { Member: mentioned.id },
          {
            $push: {
              Mentions: {
                username: msg.author.username,
                messageUrl: `https://discord.com/channels/${msg.guild.id}/${msg.channel.id}/${msg.id}`,
                timestamp: Date.now(),
              },
            },
          }
        );

        const embed = new EmbedBuilder()
          .setColor(client.color)
          .setAuthor({
            name: `${mentioned.user.username} is AFK`,
            iconURL: mentioned.user.displayAvatarURL(),
          })
          .setDescription(
            `**Reason:** ${data.Reason || "No reason"}\n<t:${Math.floor(
              data.Time / 1000
            )}:R>`
          );

        msg.reply({ embeds: [embed] }).catch(() => {});
      });

      console.log("AFK listener loaded (single instance) ✔");
    }

    // =============================================
    // CONFIRMATION UI
    // =============================================
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("YES")
        .setStyle(ButtonStyle.Success)
        .setLabel("Yes"),
      new ButtonBuilder()
        .setCustomId("NO")
        .setStyle(ButtonStyle.Danger)
        .setLabel("No")
    );

    const embed = new EmbedBuilder()
      .setColor(client.color)
      .setTitle("Enable AFK?")
      .setDescription(`Reason: **${reason}**`);

    const msg = await message.reply({
      embeds: [embed],
      components: [row],
    });

    const filter = (i) => i.user.id === message.author.id;
    const collector = msg.createMessageComponentCollector({
      filter,
      max: 1,
      time: 30000,
    });

    collector.on("collect", async (btn) => {
      await btn.deferUpdate();

      if (btn.customId === "YES") {
        await db.findOneAndUpdate(
          { Member: message.author.id },
          {
            Member: message.author.id,
            Reason: reason,
            Time: Date.now(),
            Mentions: [],
          },
          { upsert: true }
        );

        await msg.edit({
          embeds: [
            new client.embed()
              .setTitle("AFK Enabled")
              .setDescription(
                `${client.emoji.tick} You're now AFK.\nMentions will be logged.`
              )
              .noTimestamp(),
          ],
          components: [],
        });
      } else {
        msg.delete().catch(() => {});
      }
    });

    collector.on("end", () => {
      msg.edit({ components: [] }).catch(() => {});
    });
  },
};