module.exports = {
  name: "weather",
  category: "Utility",
  description: "Check weather for a city",
  execute: async (message, args, client, prefix) => {
    const city = args.join(" ");
    if (!city) return message.reply(`${client.emoji.cross} Please provide a city name.`);
    
    message.reply({
      embeds: [
        new client.embed()
          .setAuthor({ name: `Weather for ${city}`, iconURL: client.user.displayAvatarURL() })
          .setDescription(`${client.emoji.dot} **Condition:** Partly Cloudy\n${client.emoji.dot} **Temperature:** 22°C\n${client.emoji.dot} **Humidity:** 45%`)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
      ]
    });
  },
};