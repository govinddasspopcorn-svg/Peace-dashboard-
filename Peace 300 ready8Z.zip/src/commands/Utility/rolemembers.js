const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "rolemembers",
  category: "Utility",
  aliases: ["rm", "inrole", "membersinrole"],
  cooldown: 3,
  description: "Shows all members with a specific role",
  args: true,
  usage: "<role>",
  userPerms: [],
  botPerms: [],
  owner: false,

  execute: async (message, args, client, prefix) => {
    const role = message.mentions.roles.first() || 
                 message.guild.roles.cache.get(args[0]) || 
                 message.guild.roles.cache.find(r => r.name.toLowerCase() === args.join(" ").toLowerCase());

    if (!role) {
      return message.reply({
        embeds: [
          new client.embed()
            .setDescription(`${client.emoji.cross} | Please provide a valid role!`)
        ]
      });
    }

    const members = role.members;
    
    if (members.size === 0) {
      return message.reply({
        embeds: [
          new client.embed()
            .setTitle(`Members with ${role.name}`)
            .setDescription(`${client.emoji.cross} | No members have this role!`)
        ]
      });
    }

    const memberList = members.map(m => `${m.user.tag}`).join("\n");
    const chunks = [];
    
    // Split into chunks of 20 members per embed field
    for (let i = 0; i < members.size; i += 20) {
      chunks.push(
        members.map(m => `\`${i + 1}.\` ${m}`).slice(i, i + 20).join("\n")
      );
    }

    const embed = new client.embed()
      .setTitle(`👥 Members with ${role.name}`)
      .setDescription(`**Total Members:** \`${members.size}\`\n**Role Color:** ${role.hexColor}\n**Role ID:** \`${role.id}\``)
      .addFields({
        name: `Members (1-${Math.min(20, members.size)})`,
        value: chunks[0] || "None",
        inline: false
      })
      .setFooter({
        text: `✨ Requested by ${message.author.username}${chunks.length > 1 ? ` • Page 1/${chunks.length}` : ''}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true })
      });

    message.reply({ embeds: [embed] });
  },
};
