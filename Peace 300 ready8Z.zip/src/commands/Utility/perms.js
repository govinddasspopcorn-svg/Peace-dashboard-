module.exports = {
  name: "perms",
  category: "Utility",
  aliases: ["permissions"],
  description: "Check user permissions in the server",
  execute: async (message, args, client, prefix) => {
    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
    const permissions = member.permissions.toArray().map(p => `\`${p}\``).join(", ");

    message.reply({
      embeds: [
        new client.embed()
          .setAuthor({ name: `${member.user.tag}'s Permissions`, iconURL: member.user.displayAvatarURL() })
          .setDescription(`${client.emoji.dot} **Permissions:**\n${permissions || "No special permissions."}`)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
      ]
    });
  },
};