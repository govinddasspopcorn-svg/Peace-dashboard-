module.exports = {
  name: "calc",
  category: "Utility",
  aliases: ["calculate"],
  description: "Perform mathematical calculations",
  execute: async (message, args, client, prefix) => {
    const math = require("mathjs");
    const expression = args.join(" ");
    if (!expression) return message.reply(`${client.emoji.cross} Please provide an expression to calculate.`);

    try {
      const result = math.evaluate(expression);
      message.reply({
        embeds: [
          new client.embed()
            .setAuthor({ name: "Calculator", iconURL: client.user.displayAvatarURL() })
            .addFields(
              { name: `${client.emoji.dot} Input`, value: `\`\`\`js\n${expression}\n\`\`\`` },
              { name: `${client.emoji.tick} Output`, value: `\`\`\`js\n${result}\n\`\`\`` }
            )
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
        ]
      });
    } catch (e) {
      message.reply(`${client.emoji.cross} Invalid mathematical expression.`);
    }
  },
};