module.exports = {
  name: "translate",
  category: "Utility",
  description: "Translate text to English",
  execute: async (message, args, client, prefix) => {
    const text = args.join(" ");
    if (!text) return message.reply(`${client.emoji.cross} Please provide text to translate.`);
    
    message.reply({
      embeds: [
        new client.embed()
          .setAuthor({ name: "Translation", iconURL: client.user.displayAvatarURL() })
          .addFields(
            { name: `${client.emoji.dot} Original`, value: text },
            { name: `${client.emoji.tick} Translated (English)`, value: "Translation feature is being set up!" }
          )
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
      ]
    });
  },
};