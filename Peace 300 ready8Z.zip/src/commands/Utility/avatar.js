module.exports = {
  name: "avatar",
  category: "Utility",
  aliases: ["av", "pfp"],
  description: "Display user's avatar",
  execute: async (message, args, client, prefix) => {
    const user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
    const avatarURL = user.displayAvatarURL({ size: 4096, dynamic: true });
    
    message.reply({
      embeds: [
        new client.embed()
          .setAuthor({ name: `${user.tag}'s Avatar`, iconURL: avatarURL })
          .setImage(avatarURL)
          .setDescription(`${client.emoji.dot} [Avatar Link](${avatarURL})`)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
      ]
    });
  },
};