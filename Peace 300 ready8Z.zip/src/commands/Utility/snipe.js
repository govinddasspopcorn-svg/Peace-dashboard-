module.exports = {
  name: "snipe",
  category: "Utility",
  description: "Snipes the last deleted or edited message",
  cooldown: 5,

  execute: async (message, args, client, prefix) => {

    const snipe = client.snipes?.get(message.channel.id);
    if (!snipe) return message.channel.send("There's nothing to snipe!");

    const embed = new client.embed()
      .setAuthor({
        name: snipe.author.tag,
        iconURL: snipe.author.displayAvatarURL({ dynamic: true })
      })
      .setFooter({ text: `Sniped by ${message.author.tag}` })
      .setTimestamp(snipe.time);

    // Deleted OR edited text
    embed.setDescription(
      snipe.content 
        ? snipe.content 
        : snipe.edited ? "*Message was edited*" : "*No content*"
    );

    // Attachments (images, videos, gifs)
    if (snipe.attachment) embed.setImage(snipe.attachment);

    // Sticker support
    if (snipe.sticker) embed.addFields({
      name: "Sticker",
      value: snipe.sticker
    });

    message.channel.send({ embeds: [embed] });
  },
};
