module.exports = {
  name: "banner",
  category: "Utility",
  description: "Display user's banner",
  execute: async (message, args, client, prefix) => {
    const user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
    const fetchUser = await client.users.fetch(user.id, { force: true });
    const bannerURL = fetchUser.bannerURL({ size: 4096, dynamic: true });

    if (!bannerURL) return message.reply(`${client.emoji.cross} This user does not have a banner.`);

    message.reply({
      embeds: [
        new client.embed()
          .setAuthor({ name: `${user.tag}'s Banner`, iconURL: user.displayAvatarURL() })
          .setImage(bannerURL)
          .setDescription(`${client.emoji.dot} [Banner Link](${bannerURL})`)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
      ]
    });
  },
};