const { EmbedBuilder } = require("discord.js");
const Roles = require("../../schema/roles");

module.exports = {
  name: "customrole",

  execute: async (message, args, client, prefix) => {
    const guildId = message.guild.id;
    const guildRoles = await Roles.findOne({ guildId });
    if (!guildRoles || !guildRoles.customRoles?.size) return;

    const cmd = message.content
      .slice(prefix.length)
      .split(/ +/)[0]
      .toLowerCase();

    if (!guildRoles.customRoles.has(cmd)) return;

    const roleId = guildRoles.customRoles.get(cmd);

    const member =
      message.mentions.members.first() ||
      message.guild.members.cache.get(args[0]);

    if (!member)
      return message.channel.send({ content: "Provide a valid user." });

    const role = message.guild.roles.cache.get(roleId);
    if (!role)
      return message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setDescription(`Role not found. Maybe deleted.`)
            .setColor(client.color),
        ],
      });

    let response;

    if (member.roles.cache.has(role.id)) {
      await member.roles.remove(role);
      response = `Removed ${role} from ${member}`;
    } else {
      await member.roles.add(role);
      response = `Added ${role} to ${member}`;
    }

    return message.channel.send({
      embeds: [
        new EmbedBuilder().setDescription(response).setColor(client.color),
      ],
    });
  },
};