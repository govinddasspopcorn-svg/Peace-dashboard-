const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  RoleSelectMenuBuilder,
  PermissionsBitField,
  MessageFlags,
} = require("discord.js");
const Roles = require("../../schema/roles");

module.exports = {
  name: "reqrole",
  category: "Role",
  aliases: ["requiredrole", "rr"],
  description: "Set, remove or view the required role for custom roles.",
  args: false,
  usage: "<set/remove/show/setup> [role]",
  userPerms: ["Administrator"],
  owner: false,

  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription("You must be an **Administrator** to use this command."),
        ],
      });
    }

    const sub = args[0]?.toLowerCase();

    // Create entry if missing
    let data = await Roles.findOne({ guildId: message.guild.id });
    if (!data) data = await Roles.create({ guildId: message.guild.id });

    // --- SHOW CURRENT ---
    if (sub === "show" || !sub) {
      const current = data.reqrole
        ? `<@&${data.reqrole}>`
        : "❌ No required role set.";

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setTitle("Required Role (Custom Roles)")
            .setDescription(`**Current:** ${current}`)
            .setFooter({ text: `Requested by ${message.author.tag}` }),
        ],
      });
    }

    // --- REMOVE ---
    if (sub === "remove" || sub === "reset") {
      data.reqrole = null;
      await data.save();

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`✅ Required Role **has been removed**.`),
        ],
      });
    }

    // --- INTERACTIVE SETUP ---
    if (sub === "setup") {
      const row = new ActionRowBuilder().addComponents(
        new RoleSelectMenuBuilder()
          .setCustomId("reqrole_select")
          .setPlaceholder("Select a role to set as Required Role")
          .setMaxValues(1)
          .setMinValues(1)
      );

      const sent = await message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setTitle("Required Role Setup")
            .setDescription("Select a role below to set it as Required Role."),
        ],
        components: [row],
      });

      const collector = sent.createMessageComponentCollector({ time: 30000 });

      collector.on("collect", async (i) => {
        if (i.user.id !== message.author.id)
          return i.reply({ content: "Not for you.", flags: MessageFlags.Ephemeral });

        const role = i.values[0];

        data.reqrole = role;
        await data.save();

        return i.update({
          embeds: [
            new EmbedBuilder()
              .setColor(client.color)
              .setDescription(`✅ Required Role is now <@&${role}>.`),
          ],
          components: [],
        });
      });

      return;
    }

    // --- SET (manual) ---
    if (sub === "set") {
      const role =
        message.mentions.roles.first() || message.guild.roles.cache.get(args[1]);

      if (!role) {
        return message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(client.color)
              .setDescription(`❌ Please mention a valid role.`),
          ],
        });
      }

      data.reqrole = role.id;
      await data.save();

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription(`✅ Required Role has been set to ${role}.`),
        ],
      });
    }

    // --- INVALID ---
    return message.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(client.color)
          .setDescription(`❌ Invalid usage.\nUse:\n\`${prefix}reqrole set @role\`\n\`${prefix}reqrole remove\`\n\`${prefix}reqrole show\`\n\`${prefix}reqrole setup\``),
      ],
    });
  },
};
