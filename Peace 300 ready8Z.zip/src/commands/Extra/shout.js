module.exports = {
  name: "shout",
  category: "Extra",
  description: "Make the bot shout a message",
  execute: async (message, args, client, prefix) => {
    const content = args.join(" ");
    if (!content) return message.reply(`${client.emoji.cross} What should I shout?`);
    message.channel.send(`${client.emoji.dot} 📢 **${content.toUpperCase()}**`);
  },
};