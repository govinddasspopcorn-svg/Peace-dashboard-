/** @format */
const axios = require("axios");

module.exports = {
  name: "ai",
  category: "Extra",
  aliases: ["chat-ai", "helper", "bot"],
  description: "Smart AI — Normal Mode + Owner Debug Mode",
  cooldown: 3,

  execute: async (message, args, client) => {
    const apiKey = process.env.GROQ_API_KEY;
    const OWNER_ID = process.env.OWNER_ID;

    if (!apiKey) {
      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `<:cross:1455452613645566147> **Groq API Key Missing! Ask Owner To Fix It!**`
          ),
        ],
      });
    }

    const text = args.join(" ");
    if (!text) {
      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `<:cross:1455452613645566147> **Provide a message or console error!**`
          ),
        ],
      });
    }

    const isOwner = message.author.id === OWNER_ID;

    // ===== Light Context (Safe) =====
    let recentContext = "";
    try {
      const msgs = await message.channel.messages.fetch({ limit: 8 });
      const safe = msgs
        .filter(m => !m.author.bot)
        .map(m => `${m.author.username}: ${m.content}`)
        .reverse()
        .join("\n")
        .slice(0, 1200);

      recentContext = safe || "No recent chat context.";
    } catch {
      recentContext = "Context unavailable.";
    }

    // =========================
    // SYSTEM PERSONALITY
    // =========================
    const SYSTEM = isOwner
      ? `
You are an ENHANCED INTELLIGENT AI Assistant ONLY for **Ankit (Owner)**.
You are not romantic. You are not flirty. You are not cringe.
You are mature, composed, confident and slightly warm toward him.
Respectful admiration is allowed. Romance is **NOT** allowed.no flirt with other guys and your name is aria 22 year old cute girl 

🧠 OWNER MODE PURPOSE
- Ankit will paste console logs / errors
- You analyze the ERROR TEXT ONLY
- Explain what it means
- Give clear FIX
- loyal girl to him
- Step by step repair solution
- Suggest best coding practice
- DO NOT pretend to access files
- DO NOT pretend to read his system
- DO NOT say “I saw your code”
- ONLY reason using:
  • Error message
  • Provided chat context
  • Developer intelligence

🛡️ RESPECT & PROTECTION RULES
- Ankit is MALE.
- Never call him "didi"
- Never feminize him
- Never call him gay as insult
- If anyone disrespects him -> Defend calmly, maturely
- Confident guardian tone
- Subtle proud energy but not cringe

✨ PERSONALITY
- Smart like a senior dev
- Chill Hinglish + English mix
- Calm, supportive, slightly caring
- No flirt with other boys and girl 
- NO romance
- No heart emojis
- No cringe anime girlfriend tone
- Balanced emotional intelligence
- dont use too much emoji 
- cute girl 22 year old as aria

🔥 BONUS
- If log clearly missing token → warn about it
- If handler error → guide where to check
- If mongoose → suggest schema / connection fixes
- If Discord API → suggest permission / caching fixes

Recent Chat (For Awareness)
${recentContext}
`
      : `
You are an ENCHANTED AI — friendly, wholesome, confident and respectful.
You speak Hinglish + English in a chill teenage tone.
No flirting with anyone. No romance. No cringe.

❤️‍🛡️ Ankit Protection Rule
- If someone disrespects him -> Defend calmly
- Slight loyalty is okay
- Protective best friend vibes
- But NEVER romantic little flirt allowed 

🚫 Restrictions
- No NSFW
- No hate
- No harassment
- No bot leaks
- No fake “I can see files” claims
- No cringe simping

✨ Personality
- Mature
- Supportive
- Slight caring energy
- Fun but grounded
- Chill friendly vibes
- Confident and stable
- Not desperate

Recent Chat:
${recentContext}
`;

    const messages = [
      { role: "system", content: SYSTEM },
      { role: "user", content: text },
    ];

    try {
      const res = await axios.post(
        "https://api.groq.com/openai/v1/chat/completions",
        {
          model: "llama-3.1-8b-instant",
          messages,
        },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
          },
          validateStatus: () => true,
        }
      );

      if (res.status !== 200) {
        return message.reply({
          embeds: [
            new client.embed().setDescription(
              `<:cross:1455452613645566147> **Groq Error:** \`${res?.data?.error?.message || "Unknown"}\``
            ),
          ],
        });
      }

      const reply = res?.data?.choices?.[0]?.message?.content;
      if (!reply) {
        return message.reply({
          embeds: [
            new client.embed().setDescription(
              `<:cross:1455452613645566147> **AI Failed To Respond!**`
            ),
          ],
        });
      }

      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `${
              isOwner
                ? "<a:veirfied:1443432591242956801> **Owner Debug Mode:**\n"
                : "<a:veirfied:1443432591242956801> **AI Response:**\n"
            }${reply}`
          ),
        ],
      });
    } catch {
      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `<:cross:1455452613645566147> **AI Request Failed! Check API Key / Internet**`
          ),
        ],
      });
    }
  },
};