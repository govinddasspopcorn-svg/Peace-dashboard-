const Vanity = require("../../schema/vanity");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "pvanity",
  category: "Extra",
  description: "Set up the vanity system for your server.",
  usage: "<on/off/logs/add/remove/role/scan>",
  userPerms: ["ManageGuild"],
  args: true,
  cooldown: 5,
  execute: async (message, args, client, prefix) => {
    if (message.author.id !== process.env.OWNER_ID) {
      return message.reply({ embeds: [new client.embed().d("Only the bot owner can use this command!")] });
    }

    const subCommand = args[0].toLowerCase();
    let data = await Vanity.findOne({ guildId: message.guild.id });
    if (!data) data = await Vanity.create({ guildId: message.guild.id });

    if (subCommand === "on") {
      data.enabled = true;
      await data.save();
      return message.reply({ embeds: [new client.embed().d("Vanity system has been **enabled**.")] });
    }

    if (subCommand === "off") {
      data.enabled = false;
      await data.save();
      return message.reply({ embeds: [new client.embed().d("Vanity system has been **disabled**.")] });
    }

    if (subCommand === "logs") {
      const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
      if (!channel) return message.reply("Please mention a valid channel.");
      data.logChannel = channel.id;
      await data.save();
      return message.reply({ embeds: [new client.embed().d(`Vanity log channel set to ${channel}.`)] });
    }

    if (subCommand === "add") {
      const vanity = args.slice(1).join(" ");
      if (!vanity) return message.reply("Please provide a vanity string.");
      data.vanity = vanity;
      await data.save();
      return message.reply({ embeds: [new client.embed().d(`Vanity string set to **${vanity}**.`)] });
    }

    if (subCommand === "role") {
      const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]);
      if (!role) return message.reply("Please mention a valid role.");
      data.roleId = role.id;
      await data.save();
      return message.reply({ embeds: [new client.embed().d(`Vanity role set to ${role}.`)] });
    }

    if (subCommand === "remove") {
      data.vanity = null;
      await data.save();
      return message.reply({ embeds: [new client.embed().d("Vanity string has been removed.")] });
    }

    if (subCommand === "scan") {
      if (!data.enabled || !data.vanity) return message.reply("Vanity system must be enabled and a vanity string set first.");
      
      const msg = await message.reply("Fetching all members and scanning statuses... this may take a moment.");
      
      try {
        const members = await message.guild.members.fetch({ withPresences: true });
        let count = 0;
        const role = message.guild.roles.cache.get(data.roleId);
        const logChannel = message.guild.channels.cache.get(data.logChannel);

        for (const [id, member] of members) {
          if (member.user.bot) continue;
          
          const activities = member.presence?.activities || [];
          const customStatus = activities.find(a => a.type === 4);
          const statusText = customStatus ? customStatus.state : "";

          // Check Custom Status (where users put server links/vanities)
          const hasInStatus = statusText && statusText.toLowerCase().includes(data.vanity.toLowerCase());

          if (hasInStatus) {
            if (role && !member.roles.cache.has(role.id)) {
              await member.roles.add(role).catch(() => {});
              count++;
              if (logChannel) {
                const embed = new EmbedBuilder()
                  .setColor(client.color || "#00ff00")
                  .setAuthor({ name: member.user.tag, iconURL: member.user.displayAvatarURL() })
                  .setDescription(`${member} was found with vanity \`${data.vanity}\` in status during scan. Role added.`)
                  .setTimestamp();
                logChannel.send({ embeds: [embed] }).catch(() => {});
              }
            }
          }
        }
        return msg.edit({ content: null, embeds: [new client.embed().d(`Scan complete! Checked everyone and added roles to **${count}** users.`)] });
      } catch (error) {
        console.error("Scan error:", error);
        return msg.edit("An error occurred during the scan. Ensure the bot has **GUILD_PRESENCES** and **GUILD_MEMBERS** intents enabled.");
      }
    }

    return message.reply({ embeds: [new client.embed().d(`**Vanity System**\nUsage: \`${prefix}vanity <on/off/logs/add/remove/role/scan>\``)] });
  },
};
