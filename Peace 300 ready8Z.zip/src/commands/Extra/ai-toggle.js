/** @format */
const AiConfig = require("../../schema/ai-config.js");

module.exports = {
  name: "ai-toggle",
  category: "Extra",
  aliases: ["aitoggle", "ai-enable", "ai-disable"],
  description: "Enable or Disable AI Chat (Bot Owner Only)",
  cooldown: 3,

  execute: async (message, args, client) => {
    const OWNER_ID = process.env.OWNER_ID;

    if (!OWNER_ID) {
      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `<:cross:1455452613645566147> **OWNER_ID Missing In ENV!**`
          ),
        ],
      });
    }

    if (message.author.id !== OWNER_ID) {
      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `<:cross:1455452613645566147> **Only Bot Owner Can Toggle AI!**`
          ),
        ],
      });
    }

    let data = await AiConfig.findOne({ guildId: message.guild.id });

    // If not exists → create enabled = true by default
    if (!data) {
      data = await AiConfig.create({
        guildId: message.guild.id,
        enabled: true,
      });

      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `<a:veirfied:1443432591242956801> **AI Enabled Successfully!**`
          ),
        ],
      });
    }

    // Toggle
    data.enabled = !data.enabled;
    await data.save();

    return message.reply({
      embeds: [
        new client.embed().setDescription(
          `${
            data.enabled
              ? "<a:veirfied:1443432591242956801> **AI Enabled Successfully!**"
              : "<:cross:1455452613645566147> **AI Disabled Successfully!**"
          }`
        ),
      ],
    });
  },
};