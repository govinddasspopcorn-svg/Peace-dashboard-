const Onboarding = require("../../schema/onboardingSetup");

const TICK = "<a:veirfied:1443432591242956801>";
const CROSS = "<:cross:1455452613645566147>";
const DOT = "<:host:1440232674999537760>";

module.exports = {
  name: "onboarding",
  aliases: ["onb"],

  async execute(message, args, client) {

    const config = await Onboarding.findOne({ guildId: message.guild.id });

    if (!config || !config.roles.length) {
      return message.reply({
        embeds: [
          new client.embed()
            .setColor(client.color)
            .setTitle(`${CROSS} Onboarding Not Setup`)
            .setDescription(
              `${DOT} Use \`${client.prefix}setup-onboarding\` first.`
            )
        ]
      });
    }

    if (!args.length) {
      return message.reply({
        embeds: [
          new client.embed()
            .setColor(client.color)
            .setDescription(`${CROSS} | Provide user mentions / IDs to check.`)
        ]
      });
    }

    const ids = args.slice(0, 20);
    let completed = [];
    let pending = [];

    for (const input of ids) {
      const id = input.replace(/[^0-9]/g, "");
      const member = message.guild.members.cache.get(id);

      if (!member) {
        pending.push(`${CROSS} <@${id}> • Not in server`);
        continue;
      }

      const hasRole = config.roles.some(r => member.roles.cache.has(r));
      const created = Math.floor(member.user.createdTimestamp / 1000);

      if (hasRole)
        completed.push(`${TICK} <@${id}> • Account: <t:${created}:R>`);
      else
        pending.push(`${CROSS} <@${id}> • Account: <t:${created}:R>`);
    }

    return message.reply({
      embeds: [
        new client.embed()
          .setColor(client.color)
          .setTitle(`<:music:1417430118820745298> Onboarding Status`)
          .setDescription(
            `**${TICK} onboarding completed :**\n${
              completed.length ? completed.join("\n") : "None"
            }\n\n` +
            `**${CROSS} Not completed :**\n${
              pending.length ? pending.join("\n") : "None"
            }`
          )
      ]
    });
  }
};