/** @format */
const AiMemory = require("../../schema/ai-memory.js");
const AiConfig = require("../../schema/ai-config.js");

module.exports = {
  name: "aireset",
  category: "Extra",
  aliases: ["aireset", "ai-clear", "aiwipe"],
  description: "Reset AI memory / data",
  cooldown: 3,

  execute: async (message, args, client) => {
    console.log("-------------------------------------------------");
    console.log("[AI-RESET] Command Triggered");
    console.log("[AI-RESET] Guild:", message.guild?.id || "DM");
    console.log("[AI-RESET] User:", message.author.id);

    if (!message.guild) {
      console.log("[AI-RESET] ❌ Blocked in DM");
      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `<:cross:1455452613645566147> **This command can only be used in servers!**`
          ),
        ],
      });
    }

    // Must be Owner OR Server Owner
    if (
      message.author.id !== client.config.ownerID &&
      message.author.id !== message.guild.ownerId
    ) {
      console.log("[AI-RESET] ❌ Unauthorized User");
      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `<:cross:1455452613645566147> Only **Bot Owner / Server Owner** can reset AI Data!`
          ),
        ],
      });
    }

    const option = args[0]?.toLowerCase();
    console.log("[AI-RESET] Option:", option || "none");

    // No option
    if (!option) {
      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `**AI Reset Options**\n\n` +
              `\`aireset guild\` — Reset all AI memory in this guild\n` +
              `\`aireset user @user\` — Reset AI memory of a user\n` +
              `\`aireset full\` — Wipe EVERYTHING (Guild + Users)`
          ),
        ],
      });
    }

    // =======================
    // RESET GUILD MEMORY
    // =======================
    if (option === "guild") {
      console.log("[AI-RESET] Resetting Guild Memory…");

      await AiMemory.deleteMany({ guildId: message.guild.id }).catch((err) =>
        console.log("[AI-RESET][ERROR] Guild Reset Failed", err)
      );

      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `<a:veirfied:1443432591242956801> **AI Memory Reset For Guild Successfully!**`
          ),
        ],
      });
    }

    // =======================
    // RESET USER MEMORY
    // =======================
    if (option === "user") {
      const user = message.mentions.users.first();

      if (!user) {
        return message.reply({
          embeds: [
            new client.embed().setDescription(
              `<:cross:1455452613645566147> **Mention a user to reset their AI data!**`
            ),
          ],
        });
      }

      console.log("[AI-RESET] Resetting User:", user.id);

      await AiMemory.deleteMany({
        guildId: message.guild.id,
        userId: user.id,
      }).catch((err) => console.log(err));

      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `<a:veirfied:1443432591242956801> **AI Memory Cleared For <@${user.id}>**`
          ),
        ],
      });
    }

    // =======================
    // FULL WIPE
    // =======================
    if (option === "full") {
      console.log("[AI-RESET] FULL WIPE EXECUTED!!!");

      await AiMemory.deleteMany({ guildId: message.guild.id }).catch(() => {});
      await AiConfig.deleteMany({ guildId: message.guild.id }).catch(() => {});

      return message.reply({
        embeds: [
          new client.embed().setDescription(
            `<a:veirfied:1443432591242956801> **FULL AI DATA WIPE Completed!**`
          ),
        ],
      });
    }

    // Invalid Option
    console.log("[AI-RESET] ❌ Invalid Option");
    return message.reply({
      embeds: [
        new client.embed().setDescription(
          `<:cross:1455452613645566147> Invalid Option!\nUse:\n\`aireset guild\`\n\`aireset user @user\`\n\`aireset full\``
        ),
      ],
    });
  },
};