const Onboarding = require("../../schema/onboardingSetup");

const TICK = "<a:veirfied:1443432591242956801>";
const CROSS = "<:cross:1455452613645566147>";
const DOT = "<:host:1440232674999537760>";

module.exports = {
  name: "setup-onboarding",
  aliases: ["setonboard", "onboardsetup"],

  async execute(message, args, client) {

    if (!message.member.permissions.has("Administrator")) {
      return message.reply({
        embeds: [
          new client.embed()
            .setColor(client.color)
            .setDescription(`${CROSS} | Only **Administrators** can use this command.`)
        ]
      });
    }

    if (!args.length) {
      return message.reply({
        embeds: [
          new client.embed()
            .setColor(client.color)
            .setDescription(
              `${CROSS} | Mention **1 - 3 roles** to set onboarding roles.\n\n` +
              `${DOT} Example:\n\`${client.prefix}setup-onboarding @Role1 @Role2\``
            )
        ]
      });
    }

    const roles = [...new Set(
      args.slice(0, 3).map(r => r.replace(/[^0-9]/g, ""))
    )].filter(id => message.guild.roles.cache.has(id));

    if (!roles.length) {
      return message.reply({
        embeds: [
          new client.embed()
            .setColor(client.color)
            .setDescription(`${CROSS} | No valid roles provided.`)
        ]
      });
    }

    await Onboarding.findOneAndUpdate(
      { guildId: message.guild.id },
      { roles },
      { upsert: true }
    );

    return message.reply({
      embeds: [
        new client.embed()
          .setColor(client.color)
          .setTitle(`${TICK} Onboarding Setup Completed`)
          .setDescription(
            `${DOT} Members will be considered **Onboarded** if they have:\n` +
            roles.map(r => `<@&${r}>`).join("\n")
          )
      ]
    });
  }
};