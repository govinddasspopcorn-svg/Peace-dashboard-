module.exports = {
  name: "ai-toggle",
  category: "extra",
  description: "Enable or disable AI chat in a channel",
  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has("ManageGuild")) return message.reply("You need `Manage Server` permission.");
    
    // Toggle logic would normally involve a database (MongoDB in this bot)
    // For now, we simulate the toggle
    const status = args[0] === "on" ? "enabled" : "disabled";
    message.reply(`${client.emoji.tick} AI chat has been **${status}** in this server.`);
  },
};