const axios = require("axios");

module.exports = {
  name: "chat-ai",
  category: "extra",
  description: "Chat with AI using Groq API",
  execute: async (message, args, client, prefix) => {
    const input = args.join(" ");
    if (!input) return message.reply("Please provide a message to chat with AI.");

    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey || apiKey === "your_groq_api_key_here") {
      return message.reply("Groq AI is not configured. Please set `GROQ_API_KEY` in the environment.");
    }

    const msg = await message.reply(`${client.emoji.loading} AI is thinking...`);

    try {
      const response = await axios.post(
        "https://api.groq.com/openai/v1/chat/completions",
        {
          model: "mixtral-8x7b-32768",
          messages: [{ role: "user", content: input }],
        },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
          },
        }
      );

      const aiResponse = response.data.choices[0].message.content;
      
      msg.edit({
        content: null,
        embeds: [
          new client.embed()
            .setAuthor({ name: "PeaceZ AI", iconURL: client.user.displayAvatarURL() })
            .setDescription(aiResponse.length > 2048 ? aiResponse.substring(0, 2045) + "..." : aiResponse)
            .setFooter({ text: "Powered by Groq" })
        ]
      });
    } catch (error) {
      console.error(error);
      msg.edit("Failed to get a response from Groq AI. Check your API key or usage limits.");
    }
  },
};