module.exports = {
  name: "log-enable",
  category: "Config",
  description: "Enable logging",
  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has("ManageGuild")) return message.reply("You need `Manage Server` permission.");
    message.reply(`${client.emoji.tick} Logging has been **enabled**.`);
  },
};