module.exports = {
  name: "setlog",
  category: "Config",
  description: "Set the logging channel",
  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has("ManageGuild")) return message.reply(`${client.emoji.cross} You need \`Manage Server\` permission.`);
    const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);
    if (!channel) return message.reply(`${client.emoji.cross} Please mention a channel.`);
    
    message.reply({
      embeds: [
        new client.embed()
          .setAuthor({ name: "Logging Configuration", iconURL: client.user.displayAvatarURL() })
          .setDescription(`${client.emoji.tick} Logging channel has been set to ${channel}.`)
          .setFooter({ text: `Action by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
      ]
    });
  },
};