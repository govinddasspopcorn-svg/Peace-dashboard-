module.exports = {
  name: "log-status",
  category: "Config",
  description: "Check logging status",
  execute: async (message, args, client, prefix) => {
    message.reply({
      embeds: [
        new client.embed()
          .setTitle("Logging Status")
          .setDescription(`**Status:** Enabled\n**Channel:** <#${message.channel.id}>`)
      ]
    });
  },
};