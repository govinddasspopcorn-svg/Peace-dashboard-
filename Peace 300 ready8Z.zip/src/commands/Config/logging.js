const { 
  EmbedBuilder, 
  ActionRowBuilder, 
  StringSelectMenuBuilder, 
  ChannelSelectMenuBuilder,
  ChannelType,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField
} = require("discord.js");
const Logging = require("../../schema/logging");

module.exports = {
  name: "logging",
  aliases: ["logs", "setlog"],
  category: "Config",
  description: "Advanced Logging Management System",
  execute: async (message, args, client, prefix) => {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
      return message.reply({ embeds: [new EmbedBuilder().setColor(client.colors.error).setDescription(`${client.emoji.cross} | You need \`Manage Server\` permission.`)] });
    }

    let config = await Logging.findOne({ guildId: message.guild.id });
    if (!config) {
      config = new Logging({ guildId: message.guild.id });
      await config.save();
    }

    const generateEmbed = () => {
      return new EmbedBuilder()
        .setAuthor({ name: "Logging Configuration", iconURL: client.user.displayAvatarURL() })
        .setColor(config.isEnabled ? client.colors.success : client.colors.error)
        .setThumbnail(message.guild.iconURL({ dynamic: true }))
        .setDescription(
          `🛡️ **System Status:** ${config.isEnabled ? `${client.emoji.tick} Enabled` : `${client.emoji.cross} Disabled`}\n` +
          `📍 **Log Channel:** ${config.channelId ? `<#${config.channelId}>` : "None"}\n\n` +
          `Use the menu below to configure your server logs.`
        )
        .setFooter({ text: "Peace Logging Security", iconURL: client.user.displayAvatarURL() });
    };

    const row = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("log_main_menu")
        .setPlaceholder("Manage Logging Settings")
        .addOptions([
          { label: "Enable Logs", value: "enable", description: "Turn on the logging system", emoji: "✅" },
          { label: "Disable Logs", value: "disable", description: "Turn off the logging system", emoji: "❌" },
          { label: "Set Log Channel", value: "set_channel", description: "Choose where logs are sent", emoji: "📍" },
          { label: "Event Settings", value: "events", description: "Pick specific events to log", emoji: "⚙️" },
        ])
    );

    const mainMsg = await message.reply({ embeds: [generateEmbed()], components: [row] });

    const collector = mainMsg.createMessageComponentCollector({
      filter: (i) => i.user.id === message.author.id,
      time: 300000
    });

    collector.on("collect", async (interaction) => {
      if (interaction.customId === "log_main_menu") {
        const val = interaction.values[0];

        if (val === "enable") {
          config.isEnabled = true;
          await config.save();
          return interaction.update({ embeds: [generateEmbed()], components: [row] });
        }

        if (val === "disable") {
          config.isEnabled = false;
          await config.save();
          return interaction.update({ embeds: [generateEmbed()], components: [row] });
        }

        if (val === "set_channel") {
          const chanRow = new ActionRowBuilder().addComponents(
            new ChannelSelectMenuBuilder()
              .setCustomId("log_chan_select")
              .addChannelTypes(ChannelType.GuildText)
              .setPlaceholder("Select a log channel")
          );
          return interaction.update({ content: "Select a channel for logs:", components: [chanRow] });
        }

        if (val === "events") {
          const eventOpts = Object.keys(config.events).map(e => ({
            label: e.replace(/([A-Z])/g, ' $1').trim(),
            value: e,
            description: config.events[e] ? "Status: Enabled" : "Status: Disabled",
            emoji: config.events[e] ? client.emoji.tick : client.emoji.cross
          }));

          const eventRow = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
              .setCustomId("log_event_toggle")
              .setPlaceholder("Select event to toggle")
              .addOptions(eventOpts.slice(0, 25))
          );
          
          const backButton = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("log_home").setLabel("Back").setStyle(ButtonStyle.Secondary)
          );

          return interaction.update({ content: "Toggle specific logging events:", components: [eventRow, backButton] });
        }
      }

      if (interaction.customId === "log_chan_select") {
        config.channelId = interaction.values[0];
        config.isEnabled = true;
        await config.save();
        return interaction.update({ content: null, embeds: [generateEmbed()], components: [row] });
      }

      if (interaction.customId === "log_event_toggle") {
        const event = interaction.values[0];
        config.events[event] = !config.events[event];
        await config.save();
        
        const eventOpts = Object.keys(config.events).map(e => ({
          label: e.replace(/([A-Z])/g, ' $1').trim(),
          value: e,
          description: config.events[e] ? "Status: Enabled" : "Status: Disabled",
          emoji: config.events[e] ? client.emoji.tick : client.emoji.cross
        }));

        const eventRow = new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId("log_event_toggle")
            .setPlaceholder("Select event to toggle")
            .addOptions(eventOpts.slice(0, 25))
        );

        return interaction.update({ components: [eventRow, interaction.message.components[1]] });
      }

      if (interaction.customId === "log_home") {
        return interaction.update({ content: null, embeds: [generateEmbed()], components: [row] });
      }
    });
  }
};
