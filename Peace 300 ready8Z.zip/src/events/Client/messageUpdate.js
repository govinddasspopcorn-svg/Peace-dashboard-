const { EmbedBuilder } = require("discord.js");
const Logging = require("../../schema/logging");

module.exports = {
  name: "messageUpdate",
  run: async (client, oldMessage, newMessage) => {
    if (!newMessage.guild || newMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return;
    
    const config = await Logging.findOne({ guildId: newMessage.guild.id });
    if (!config?.isEnabled || !config.events.messageUpdate || !config.channelId) return;

    const logChan = newMessage.guild.channels.cache.get(config.channelId) || await newMessage.guild.channels.fetch(config.channelId).catch(() => null);
    if (!logChan) {
      console.warn(`[LOGGING] Log channel ${config.channelId} not found in guild ${newMessage.guild.id}`);
      return;
    }

    // Check permissions before sending
    if (!logChan.permissionsFor(client.user).has(["SendMessages", "EmbedLinks"])) {
      console.warn(`[LOGGING] Missing permissions in log channel ${config.channelId}`);
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle("📝 Message Edited")
      .setColor("#FFFF00")
      .setAuthor({ name: newMessage.author.tag, iconURL: newMessage.author.displayAvatarURL({ dynamic: true }) })
      .addFields(
        { name: "Channel", value: `${newMessage.channel} (\`${newMessage.channel.id}\`)`, inline: true },
        { name: "Before", value: oldMessage.content?.slice(0, 1024) || "*(No text)*", inline: false },
        { name: "After", value: newMessage.content?.slice(0, 1024) || "*(No text)*", inline: false }
      )
      .setFooter({ text: `Message ID: ${newMessage.id}` })
      .setTimestamp();

    await logChan.send({ embeds: [embed] }).catch(() => null);
  }
};
