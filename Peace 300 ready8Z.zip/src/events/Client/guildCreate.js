const { WebhookClient, EmbedBuilder } = require("discord.js");
const {
  Webhooks: { guild_join },
} = require("../../config.js");
const moment = require("moment");

module.exports = {
  name: "guildCreate",
  run: async (client, guild) => {
    const web = new WebhookClient({ url: guild_join });

    // SAFEST WAY TO GET OWNER
    let ownerUser = null;
    try {
      ownerUser = await client.users.fetch(guild.ownerId).catch(() => null);
    } catch {}

    const vanity = guild.vanityURLCode
      ? `[Here is ${guild.name} invite](https://discord.gg/${guild.vanityURLCode})`
      : `Don't have vanity`;

    // ===================== WEBHOOK LOG ===================== //
    const embed = new client.embed()
      .thumb(guild.iconURL({ size: 1024 }))
      .t(`🔗 Joined a Guild !!`)
      .addFields([
        { name: "Server Name:", value: `> \`${guild.name}\`` },
        { name: "Server Id:", value: `> \`${guild.id}\`` },
        {
          name: "Server Owner:",
          value: `> \`${ownerUser?.tag || "Unknown"}\` ${guild.ownerId || "Unknown"}`,
        },
        { name: "Member Count", value: `> \`${guild.memberCount}\` Members` },
        {
          name: "Creation Date",
          value: `> \`${moment.utc(guild.createdAt).format("DD/MMM/YYYY")}\``,
        },
        { name: "Guild Invite", value: `> ${vanity}` },
      ])
      .setFooter({
        text: `Total Server Count [ ${client.guilds.cache.size} ]`,
        iconURL: client.user.displayAvatarURL(),
      })
      .setTimestamp();

    web.send({ embeds: [embed] }).catch(() => {});

    // ===================== DM SERVER OWNER ===================== //
    try {
      if (ownerUser) {
        const support =
          process.env.SUPPORT_SERVER || "Support server not set";

        await ownerUser.send({
          embeds: [
            new EmbedBuilder()
              .setColor(client.color || 0xffd700)
              .setTitle("Thanks for Adding Me ❤️")
              .setDescription(
                `Hey **${ownerUser.username}**, thanks for adding **${client.user.username}** to **${guild.name}**!\n\n`
                + `If you need help:\n`
                + `• Prefix: \`${client.prefix || "!"}\`\n`
                + `• Support: [Support Server](${support})`
              )
              .setFooter({
                text: `Love Peace's Team <3`,
                iconURL: client.user.displayAvatarURL(),
              })
              .setTimestamp(),
          ],
        }).catch(() => {});
      }
    } catch {}

    // ===================== DM BOT OWNER ===================== //
    try {
      const botOwnerId = client.config.ownerID;
      const botOwner = await client.users.fetch(botOwnerId).catch(() => null);

      if (botOwner) {
        await botOwner.send({
          embeds: [
            new EmbedBuilder()
              .setColor(client.color || 0x00ff94)
              .setTitle("📥 Bot Added to a Guild")
              .setDescription(
                `**Guild:** \`${guild.name}\` (${guild.id})\n`
                + `**Owner:** ${ownerUser?.tag || "Unknown"} (${guild.ownerId || "?"})\n`
                + `**Members:** \`${guild.memberCount}\`\n\n`
                + `Invite: ${vanity}`
              )
              .setFooter({
                text: `Total Servers: ${client.guilds.cache.size}`,
                iconURL: client.user.displayAvatarURL(),
              })
              .setTimestamp(),
          ],
        }).catch(() => {});
      }
    } catch {}
  },
};