const Vanity = require("../../schema/vanity");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "presenceUpdate",
  run: async (client, oldPresence, newPresence) => {
    if (!newPresence || !newPresence.guild || !newPresence.member || newPresence.member.user.bot) return;

    const { guild, member } = newPresence;
    const data = await Vanity.findOne({ guildId: guild.id });

    if (!data || !data.enabled || !data.vanity) return;

    const activities = newPresence.activities || [];
    const customStatus = activities.find(a => a.type === 4);
    const statusText = customStatus ? customStatus.state : "";
    
    // Case-insensitive check anywhere in status
    const hasInStatus = statusText && statusText.toLowerCase().includes(data.vanity.toLowerCase());

    const role = guild.roles.cache.get(data.roleId);
    const logChannel = guild.channels.cache.get(data.logChannel);

    const oldStatusText = oldPresence?.activities.find(a => a.type === 4)?.state || "";
    const hadInStatusBefore = oldStatusText.toLowerCase().includes(data.vanity.toLowerCase());

    if (hasInStatus && !hadInStatusBefore) {
      if (role && !member.roles.cache.has(role.id)) {
        await member.roles.add(role).catch(() => {});
      }
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setColor(client.color || "#00ff00")
          .setAuthor({ name: member.user.tag, iconURL: member.user.displayAvatarURL() })
          .setDescription(`${member} has added the vanity \`${data.vanity}\` to their status. Role added.`)
          .setTimestamp();
        logChannel.send({ embeds: [embed] }).catch(() => {});
      }
    } else if (!hasInStatus && hadInStatusBefore) {
      if (role && member.roles.cache.has(role.id)) {
        await member.roles.remove(role).catch(() => {});
      }
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setColor("#ff0000")
          .setAuthor({ name: member.user.tag, iconURL: member.user.displayAvatarURL() })
          .setDescription(`${member} has removed the vanity \`${data.vanity}\` from their status. Role removed.`)
          .setTimestamp();
        logChannel.send({ embeds: [embed] }).catch(() => {});
      }
    }
  }
};
