/** @format
 *
 * Arrkiii By Ozuma xd
 * © 2024 Arrkiii Development
 *
 */
const {
  EmbedBuilder,
  PermissionsBitField,
  ActionRowBuilder,
  ButtonStyle,
  ButtonBuilder,
  WebhookClient,
  version,
} = require("discord.js");
const db = require("../../schema/prefix.js");
const bl = require("../../schema/blacklist");
const IgnoreChannelModel = require("../../schema/ignorechannel");
const VoteBypassUserModel = require("../../schema/votebypassuser");
const db4 = require("../../schema/noprefix");
const cooldowns = new Map();
const Sticky = require("../../schema/sticky");

module.exports = {
  name: "messageCreate",
  run: async (client, message) => {
    if (message.author.bot) return;
      
      // ================= STICKY SYSTEM ================= //
try {
  const Sticky = require("../../schema/sticky");
  const { EmbedBuilder } = require("discord.js");

  if (message.guild) {
    const sticky = await Sticky.findOne({
      guildId: message.guild.id,
      channelId: message.channel.id,
    });

    if (sticky) {
      // delete previous sticky
      if (sticky.lastMessageId) {
        const old = await message.channel.messages
          .fetch(sticky.lastMessageId)
          .catch(() => null);

        if (old) old.delete().catch(() => {});
      }

      // color fix
      const color =
        typeof message.client?.color === "string"
          ? parseInt(message.client.color.replace("#", ""), 16)
          : message.client?.color || 0xffd700;

      // send sticky embed box
      const sent = await message.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(color)
            .setDescription(
              `\`\`\`ini\n[ Sticky Message ]\n\`\`\`\n${sticky.message}`
            ),
        ],
      });

      sticky.lastMessageId = sent.id;
      await sticky.save();
    }
  }
} catch {}
// ================= END STICKY ================= //
      
    let prefix = client.prefix;
    const ress = await db.findOne({ Guild: message.guildId });
    if (ress && ress.Prefix) prefix = ress.Prefix;
    const reacter = new RegExp(`^<@!?${client.owner}>( |)$`);

    if (message.content.includes(client.owner)) {
      await message.react(client.emoji.owner).catch(() => {});
    }

    const mention = new RegExp(`^<@!?${client.user.id}>( |)$`);
    if (message.content.match(mention)) {
      if (
        !message.guild.members.me.permissions.has(
          PermissionsBitField.resolve("SendMessages"),
        )
      )
        return await message.author
          .send({
            content: `I don't have **\`SEND_MESSAGES\`** permission in <#${message.channelId}>.`,
          })
          .catch(() => null);

      if (
        !message.guild.members.me.permissions.has(
          PermissionsBitField.resolve("ViewChannel"),
        )
      )
        return;

      if (
        !message.guild.members.me.permissions.has(
          PermissionsBitField.resolve("EmbedLinks"),
        )
      )
        return await message.channel
          .send({
            content: `I don't have **\`EMBED_LINKS\`** permission in <#${message.channelId}>.`,
          })
          .catch(() => {});

      const embed = new EmbedBuilder()
        .setAuthor({ name: client.user.username, iconURL: client.user.displayAvatarURL() })
        .setColor(client.color)
        .setDescription(
          `Hey ${message.author}, I am **${client.user.username}**!\n\n` +
          `🛡️ **Security:** Advanced Antinuke & Logging\n` +
          `🎵 **Music:** High-quality audio support\n` +
          `⚙️ **Prefix:** My prefix for this server is \`${prefix}\`\n\n` +
          `Type \`${prefix}help\` to see all my commands!`
        )
        .setThumbnail(client.user.displayAvatarURL())
        .setFooter({
          text: `Developed with ❤️ by Peace Team`,
          iconURL: client.user.displayAvatarURL(),
        })
        .setTimestamp();

      const actionRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel("Invite Me")
          .setStyle(ButtonStyle.Link)
          .setURL(client.config.links.invite),
        new ButtonBuilder()
          .setLabel("Support Server")
          .setStyle(ButtonStyle.Link)
          .setURL(client.config.links.support),
        new ButtonBuilder()
          .setLabel("Vote")
          .setStyle(ButtonStyle.Link)
          .setURL(`https://top.gg/bot/${client.user.id}/vote`)
      );

      return await message.channel.send({
        embeds: [embed],
        components: [actionRow],
      }).catch(() => null);
    }

    const np = [];
    const npData = await db4.findOne({
      userId: message.author.id,
      noprefix: true,
    });
    if (npData) np.push(message.author.id);

    const regex = new RegExp(`^<@!?${client.user.id}>`);
    const pre = message.content.match(regex)
      ? message.content.match(regex)[0]
      : prefix;
    if (!np.includes(message.author.id)) {
      if (!message.content.startsWith(pre)) return;
    }

    const args =
      np.includes(message.author.id) === false
        ? message.content.slice(pre.length).trim().split(/ +/)
        : message.content.startsWith(pre) === true
          ? message.content.slice(pre.length).trim().split(/ +/)
          : message.content.trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    const command =
      client.commands.get(commandName) ||
      client.commands.find(
        (cmd) => cmd.aliases && cmd.aliases.includes(commandName),
      );

    if (!command) return;
      
          const blusers = await bl.findOne({userId: message.author.id })
    if (blusers) {
      const embed = new client.embed().a(`You have been blacklisted from using the bot!`, message.author.displayAvatarURL());
      const m = await message.channel.send({ embeds: [embed] }).catch(() => null);
      setTimeout(() => m.delete().catch(() => null), 5000);
      return;
    }

    if (!cooldowns.has(command.name)) {
      cooldowns.set(command.name, new Map());
    }

    const now = Date.now();
    const timestamps = cooldowns.get(command.name);
    const cooldownAmount = (command.cooldown || 3) * 1000; // Default cooldown: 3 seconds

    if (timestamps.has(message.author.id)) {
      const expirationTime = timestamps.get(message.author.id) + cooldownAmount;

      if (now < expirationTime) {
        const timeLeft = Math.round(expirationTime / 1_000);
        const cooldownEmbed = new EmbedBuilder()
          .setColor(client.color)
          .setDescription(
            `Please wait **<t:${timeLeft}:R>** before reusing the \`${command.name}\` command.`,
          );
        return message.reply({ embeds: [cooldownEmbed] }).then((msg) => {
          const delayTime = expirationTime - now; // Calculate the remaining cooldown time
          setTimeout(() => {
            msg.delete();
          }, delayTime);
        });
      }
    }
    timestamps.set(message.author.id, now);
    setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);

    const ICHchannelId = message.channel.id;
    const isIgnored = await IgnoreChannelModel.findOne({
      guildId: message.guild.id,
      channelId: ICHchannelId,
    });
    if (isIgnored) {
      const baap = new EmbedBuilder()
        .setAuthor({
          name: `This channel is set to ignored channel..`,
          iconURL: message.author.displayAvatarURL(),
        })
        .setColor(client.color);
      const ignoreMessage = await message.channel.send({ embeds: [baap] }).catch(() => null);
      setTimeout(() => {
        ignoreMessage.delete().catch(console.error);
      }, 3000);
      return;
    }

    if (command.voteonly) {
      const hasVoted = await client.topgg.hasVoted(message.author.id);
      const voteBypassUser = await VoteBypassUserModel.findOne({
        userId: message.author.id,
      });
      if (!hasVoted && !voteBypassUser) {
        const embed = new EmbedBuilder()
          .setDescription(
            `__This Command Is Only For Our Voters So Vote Us Now By [Clicking Here](https://top.gg/bot/${client.user.id}/vote)__`,
          )
          .setColor(client.color);
        return message.channel.send({ embeds: [embed] }).catch(() => null);
      }
    }

    if (
      !message.guild.members.me.permissions.has(
        PermissionsBitField.resolve("SendMessages"),
      )
    )
      return await message.author
        .send({
          content: `I don't have **\`SEND_MESSAGES\`** permission in <${message.guild.name}> to execute this **\`${command.name}\`** command.`,
        })
        .catch(() => {});

    if (
      !message.guild.members.me.permissions.has(
        PermissionsBitField.resolve("ViewChannel"),
      )
    )
      return;

    if (
      !message.guild.members.me.permissions.has(
        PermissionsBitField.resolve("EmbedLinks"),
      )
    )
      return await message.author
        .send({
          content: `I don't have **\`EMBED_LINKS\`** permission in <#${message.guild.name}> to execute this **\`${command.name}\`** command.`,
        })
        .catch(() => {});

    if (command.args && !args.length) {
      let reply = `You didn't provide any arguments, ${message.author}!`;

      if (command.usage) {
        reply += `\nUsage: \`${prefix}${command.name} ${command.usage}\``;
      }

      const embed = new EmbedBuilder()
        .setColor(client.color)
        .setDescription(reply);
      return message.channel.send({ embeds: [embed] }).catch(() => null);
    }

    if (command.botPerms) {
      if (
        !message.guild.members.me.permissions.has(
          PermissionsBitField.resolve(command.botPerms || []),
        )
      ) {
        const embed = new EmbedBuilder().setDescription(
          `I don't have **\`${command.botPerms}\`** permission in <#${message.channelId}> to execute this **\`${command.name}\`** command.`,
        );
        return message.channel.send({ embeds: [embed] }).catch(() => null);
      }
    }
    if (command.userPerms) {
      if (
        !message.member.permissions.has(
          PermissionsBitField.resolve(command.userPerms || []),
        )
      ) {
        const embed = new EmbedBuilder()
          .setColor(client.color)
          .setDescription(
            `You don't have **\`${command.userPerms}\`** permission in <#${message.channelId}> to execute this **\`${command.name}\`** command.`,
          );
        return message.channel.send({ embeds: [embed] }).catch(() => null);
      }
    }

    if (command.owner && message.author.id !== `${client.owner}`) {
      const ozuma = await client.users.fetch(`1266043322129059925`);
      const Ozuma_xd = await client.channels.cache.get(`1266043322129059925`);
      const embed = new EmbedBuilder().setColor(client.color).setAuthor({
        name: `| Only ${ozuma.displayName} can use this cmds!`,
        iconURL: message.author.displayAvatarURL(),
      });
      return message.channel.send({ embeds: [embed] }).catch(() => null);
    }

    const player = client.manager.players.get(message.guild.id);
    if (command.player && !player) {
      return message.channel.send(`i'm not in any vc!`).catch(() => null);;
    }
    if (command.inVoiceChannel && !message.member.voice.channelId) {
      const embed = new EmbedBuilder().setColor(client.color).setAuthor({
        name: `Your are not in any vc`,
        iconURL: message.author.displayAvatarURL(),
        url: client.config.links.support,
      });
      return message.channel.send({ embeds: [embed] }).catch(() => null);
    }

    if (command.sameVoiceChannel) {
      if (message.guild.members.me.voice.channel) {
        if (
          message.guild.members.me.voice.channelId !==
          message.member.voice.channelId
        ) {
          const embed = new EmbedBuilder().setColor(client.color).setAuthor({
            name: `Your are not in same vc`,
            iconURL: message.author.displayAvatarURL(),
            url: client.config.links.support,
          });
          return message.channel.send({ embeds: [embed] }).catch(() => null);
        }
      }
    }
    //

    command.execute(message, args, client, prefix).catch((e) => {
      console.log(e);
    });
    if (command && command.execute) {
      const log = client.channels.cache.get(`1266043322129059925`);
      const web = new WebhookClient({
        url: client.config.Webhooks.cmdrun,
      });
      const commandlog = new EmbedBuilder()
        .setAuthor({
          name: message.author.tag,
          iconURL: message.author.displayAvatarURL({ dynamic: true }),
        })
        .setColor(client.color)
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setTimestamp()
        .setDescription(
          `Command Just Used In : \`${message.guild.name} | ${message.guild.id}\`\n Command Used In Channel : \`${message.channel.name} | ${message.channel.id}\`\n Command Name : \`${command.name}\`\n Command Executor : \`${message.author.tag} | ${message.author.id}\`\n Command Content : \`${message.content}\``,
        );
      web.send({ embeds: [commandlog] });
    }
  },
};
