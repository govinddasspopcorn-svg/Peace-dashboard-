const AntiMention = require("../../schema/antimention");
const AntiCaps = require("../../schema/anticaps");
const AntiInvite = require("../../schema/antiinvite");
const AntiStickerSpam = require("../../schema/antistickerspam");

// Track sticker spam per user
const stickerTracker = new Map();

module.exports = {
  name: "messageCreate",
  run: async (client, message) => {
    if (!message.guild || message.author.bot) return;

    const guildId = message.guildId;
    const member = message.member;

    // Anti-Sticker Spam (silent deletion)
    if (message.stickers.size > 0) {
      const antiStickerData = await AntiStickerSpam.findOne({ guildId });
      
      if (!antiStickerData || antiStickerData.isEnabled !== false) {
        // Check whitelist
        const isWhitelisted = 
          antiStickerData?.whitelistUsers?.includes(message.author.id) ||
          member.roles.cache.some(role => antiStickerData?.whitelistRoles?.includes(role.id));

        if (!isWhitelisted) {
          const userId = message.author.id;
          const now = Date.now();
          
          if (!stickerTracker.has(userId)) {
            stickerTracker.set(userId, []);
          }
          
          const userStickers = stickerTracker.get(userId);
          userStickers.push(now);
          
          // Remove old entries (older than 1 minute)
          const timeframe = antiStickerData?.timeframe || 60000;
          const filtered = userStickers.filter(timestamp => now - timestamp < timeframe);
          stickerTracker.set(userId, filtered);
          
          // Check if threshold exceeded
          const threshold = antiStickerData?.stickerThreshold || 10;
          if (filtered.length >= threshold) {
            try {
              await message.delete();
              // Silent deletion - no notification
            } catch (e) {
              console.error("Failed to delete sticker spam:", e);
            }
          }
        }
      }
    }

    // Anti-Mention
    const antiMentionData = await AntiMention.findOne({ guildId });
    if (antiMentionData?.isEnabled) {
      const isWhitelisted = 
        antiMentionData.whitelistUsers?.includes(message.author.id) ||
        member.roles.cache.some(role => antiMentionData.whitelistRoles?.includes(role.id));

      if (!isWhitelisted) {
        const mentionCount = message.mentions.users.size + message.mentions.roles.size;
        const threshold = antiMentionData.mentionThreshold || 5;

        if (mentionCount > threshold) {
          try {
            await message.delete();
            
            const punishment = antiMentionData.punishment || "delete";
            
            switch (punishment) {
              case "warn":
                await message.channel.send({
                  content: `${message.author}, you have been warned for mass mentions!`,
                  allowedMentions: { users: [] }
                }).then(msg => setTimeout(() => msg.delete().catch(() => {}), 5000));
                break;
                
              case "timeout":
                await member.timeout(5 * 60 * 1000, "Mass mention spam");
                break;
                
              case "kick":
                await member.kick("Mass mention spam");
                break;
            }
          } catch (e) {
            console.error("Anti-mention error:", e);
          }
        }
      }
    }

    // Anti-Caps
    const antiCapsData = await AntiCaps.findOne({ guildId });
    if (antiCapsData?.isEnabled) {
      const isWhitelisted = 
        antiCapsData.whitelistUsers?.includes(message.author.id) ||
        member.roles.cache.some(role => antiCapsData.whitelistRoles?.includes(role.id));

      if (!isWhitelisted && message.content.length >= 5) {
        const text = message.content;
        const upperCount = (text.match(/[A-Z]/g) || []).length;
        const letterCount = (text.match(/[A-Za-z]/g) || []).length;
        
        if (letterCount > 0) {
          const capsPercentage = (upperCount / letterCount) * 100;
          const threshold = antiCapsData.capsPercentage || 70;

          if (capsPercentage > threshold) {
            try {
              await message.delete();
              
              const punishment = antiCapsData.punishment || "delete";
              
              switch (punishment) {
                case "warn":
                  await message.channel.send({
                    content: `${message.author}, please don't use excessive caps!`,
                    allowedMentions: { users: [] }
                  }).then(msg => setTimeout(() => msg.delete().catch(() => {}), 5000));
                  break;
                  
                case "timeout":
                  await member.timeout(5 * 60 * 1000, "Excessive caps lock");
                  break;
                  
                case "mute":
                  await member.timeout(10 * 60 * 1000, "Excessive caps lock");
                  break;
              }
            } catch (e) {
              console.error("Anti-caps error:", e);
            }
          }
        }
      }
    }

    // Anti-Invite
    const antiInviteData = await AntiInvite.findOne({ guildId });
    if (antiInviteData?.isEnabled) {
      const isWhitelisted = 
        antiInviteData.whitelistUsers?.includes(message.author.id) ||
        antiInviteData.whitelistChannels?.includes(message.channel.id) ||
        member.roles.cache.some(role => antiInviteData.whitelistRoles?.includes(role.id));

      if (!isWhitelisted) {
        const inviteRegex = /(discord\.gg|discord\.com\/invite|discordapp\.com\/invite)\/[a-zA-Z0-9]+/gi;
        
        if (inviteRegex.test(message.content)) {
          try {
            await message.delete();
            
            const punishment = antiInviteData.punishment || "delete";
            
            switch (punishment) {
              case "warn":
                await message.channel.send({
                  content: `${message.author}, invite links are not allowed!`,
                  allowedMentions: { users: [] }
                }).then(msg => setTimeout(() => msg.delete().catch(() => {}), 5000));
                break;
                
              case "timeout":
                await member.timeout(15 * 60 * 1000, "Posting invite links");
                break;
                
              case "kick":
                await member.kick("Posting invite links");
                break;
            }
          } catch (e) {
            console.error("Anti-invite error:", e);
          }
        }
      }
    }
  }
};

// Clean up old sticker tracker entries every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [userId, timestamps] of stickerTracker.entries()) {
    const filtered = timestamps.filter(t => now - t < 120000);
    if (filtered.length === 0) {
      stickerTracker.delete(userId);
    } else {
      stickerTracker.set(userId, filtered);
    }
  }
}, 5 * 60 * 1000);
