const { WebhookClient, EmbedBuilder } = require("discord.js");
const {
  Webhooks: { guild_leave },
} = require("../../config.js");
const VoiceRole = require("../../schema/voicerole");
const AntiSpam = require("../../schema/antispam");
const db = require("../../schema/antilink");
const arr = require("../../schema/ar");
const AutoRole = require("../../schema/autorole");
const moment = require("moment");

module.exports = {
  name: "guildDelete",
  run: async (client, guild) => {
    try {
      const vc = await VoiceRole.findOne({ guildId: guild.id });
      const antiLinkData = await db.findOne({ guildId: guild.id });
      const antiSpamData = await AntiSpam.findOne({ guildId: guild.id });
      const ardata = await arr.findOne({ guildId: guild.id });
      const AutoroleData = await AutoRole.findOne({ guildId: guild.id });

      if (AutoroleData) await AutoroleData.delete().catch(() => {});
      if (vc) await vc.delete().catch(() => {});
      if (antiLinkData) await antiLinkData.delete().catch(() => {});
      if (antiSpamData) await antiSpamData.delete().catch(() => {});
      if (ardata) await ardata.delete().catch(() => {});

      const web = new WebhookClient({ url: guild_leave });
      const own = await guild?.fetchOwner().catch(() => null);

      // ===================== WEBHOOK LOG ===================== //
      if (web) {
        const embed = new client.embed()
          .thumb(guild.iconURL({ dynamic: true, size: 1024 }))
          .t(`📤 Left a Guild !!`)
          .addFields([
            { name: "Name", value: `\`${guild.name}\`` },
            { name: "ID", value: `\`${guild.id}\`` },
            {
              name: "Owner",
              value: `\`${own?.user?.tag || "Unknown User"} [ ${own?.id || "Unknown"} ]\``,
            },
            { name: "Member Count", value: `\`${guild.memberCount || 0}\` Members` },
            {
              name: "Creation Date",
              value: `\`${moment.utc(guild.createdAt).format("DD/MMM/YYYY")}\``,
            },
            {
              name: `${client.user.username}'s Server Count`,
              value: `\`${client.guilds.cache.size}\` Servers`,
            },
          ])
          .setTimestamp();

        web.send({ embeds: [embed] }).catch(() => {});
      }

      // ===================== DM SERVER OWNER ===================== //
      try {
        if (own) {
          const support = process.env.SUPPORT_SERVER || "Support not set";

          await own.send({
            embeds: [
              new EmbedBuilder()
                .setColor(client.color || 0xff4444)
                .setTitle("💔 Bot Left Your Server")
                .setDescription(
                  `Hey **${own.user.username}**, **${client.user.username}** has left your server **${guild.name}**.\n\n`
                  + `If this wasn't intentional, you can invite me again:\n`
                  + `[Invite Me Back](${client.config?.links?.invite || "https://discord.com/oauth2"})\n`
                  + `Support: [Support Server](${support})`
                )
                .setFooter({
                  text: `Love Peace's Team <3`,
                  iconURL: client.user.displayAvatarURL(),
                })
                .setTimestamp(),
            ],
          }).catch(() => {});
        }
      } catch {}

      // ===================== DM BOT OWNER ===================== //
      try {
        const botOwnerId = client.config.ownerID;
        const botOwner = await client.users.fetch(botOwnerId).catch(() => null);

        if (botOwner) {
          await botOwner.send({
            embeds: [
              new EmbedBuilder()
                .setColor(0xff0000)
                .setTitle("📤 Bot Removed From a Guild")
                .setDescription(
                  `**Guild:** \`${guild.name}\` (${guild.id})\n`
                  + `**Members:** \`${guild.memberCount || 0}\`\n`
                  + `**Owner:** ${own?.user?.tag || "Unknown"} (${own?.id || "?"})\n\n`
                  + `Total Servers Now: **${client.guilds.cache.size}**`
                )
                .setTimestamp(),
            ],
          }).catch(() => {});
        }
      } catch {}

    } catch (error) {
      console.error("Error in guildDelete event:", error);
    }
  },
};