const afk = require("../../schema/afk");
const moment = require("moment");
const { ButtonBuilder, ActionRowBuilder, ButtonStyle } = require("discord.js");

module.exports = {
  name: "messageCreate",
  run: async (client, message) => {
    if (!message.guild || message.author.bot) return;

    const mentioned = message.mentions.members.first();
    if (mentioned) {
      const data = await afk.findOne({
        Guild: message.guildId,
        Member: mentioned.id,
      });
      if (data) {
        await afk.updateOne(
          { Guild: message.guildId, Member: mentioned.id },
          { 
            $push: { 
              Mentions: {
                userId: message.author.id,
                username: message.author.username,
                message: message.content.substring(0, 100),
                timestamp: Date.now(),
                messageUrl: message.url
              }
            }
          }
        );
        
        const jumpButton = new ButtonBuilder()
          .setLabel("Jump to Message")
          .setStyle(ButtonStyle.Link)
          .setURL(message.url)
          .setEmoji("🔗");
        
        const row = new ActionRowBuilder().addComponents(jumpButton);
        
        message.reply({
          embeds: [
            new client.embed()
              .setTitle("User is AFK")
              .d(`${client.emoji.warn} **${mentioned.user.username}** is currently AFK\n\n**Reason:** ${data.Reason}\n**Since:** <t:${Math.round(data.Time / 1000)}:R>`)
              .setFooter({ text: "✨ They'll be notified when they return" })
              .noTimestamp(),
          ],
          components: [row]
        });
      }
    }

    const authorData = await afk.findOne({
      Guild: message.guildId,
      Member: message.author.id,
    });
    if (authorData) {
      const afkDuration = Math.round((Date.now() - authorData.Time) / 1000);
      const mentions = authorData.Mentions || [];
      
      await afk.deleteOne({
        Guild: message.guildId,
        Member: message.author.id,
      });

      let mentionText = "";
      const components = [];
      
      if (mentions.length > 0) {
        const recentMentions = mentions.slice(-3).reverse();
        mentionText = "\n\n**Recent Mentions:**\n" + recentMentions.map((m, i) => 
          `• **${m.username}**: ${m.message.length > 50 ? m.message.substring(0, 50) + '...' : m.message} (<t:${Math.round(m.timestamp / 1000)}:R>)`
        ).join('\n');
        
        // Add jump buttons for recent mentions
        if (recentMentions.length > 0 && recentMentions[0].messageUrl) {
          const buttons = recentMentions
            .filter(m => m.messageUrl)
            .slice(0, 3)
            .map((m, i) => 
              new ButtonBuilder()
                .setLabel(`Jump to Mention ${i + 1}`)
                .setStyle(ButtonStyle.Link)
                .setURL(m.messageUrl)
                .setEmoji("🔗")
            );
          
          if (buttons.length > 0) {
            components.push(new ActionRowBuilder().addComponents(buttons));
          }
        }
      }
      
      message.reply({
        embeds: [
          new client.embed()
            .setTitle("Welcome Back!")
            .setDescription(
              `${client.emoji.tick} Your AFK status has been removed\n\n` +
              `**You were AFK for:** <t:${Math.round(authorData.Time / 1000)}:R>` +
              (mentions.length > 0 ? `\n**Total Mentions:** ${mentions.length}` : '') +
              mentionText
            )
            .setFooter({ text: "✨ Good to have you back" })
            .noTimestamp(),
        ],
        components: components
      });
    }
  },
};
