const { EmbedBuilder } = require("discord.js");
const Logging = require("../../schema/logging");

module.exports = {
  name: "messageDelete",
  run: async (client, message) => {
    // snipe logic
    if (message.partial || !message.guild || message.author?.bot) return;

    client.snipes = client.snipes || new Map();
    client.snipes.set(message.channel.id, {
      content: message.content,
      author: message.author,
      image: message.attachments.first()?.proxyURL || null,
      time: Date.now(),
    });

    // logging logic
    const config = await Logging.findOne({ guildId: message.guild.id });
    if (!config?.isEnabled || !config.events.messageDelete || !config.channelId) return;

    const logChan = message.guild.channels.cache.get(config.channelId) || await message.guild.channels.fetch(config.channelId).catch(() => null);
    if (!logChan) {
      console.warn(`[LOGGING] Log channel ${config.channelId} not found in guild ${message.guild.id}`);
      return;
    }

    // Check permissions before sending
    if (!logChan.permissionsFor(client.user).has(["SendMessages", "EmbedLinks"])) {
      console.warn(`[LOGGING] Missing permissions in log channel ${config.channelId}`);
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle("🗑️ Message Deleted")
      .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
      .setColor("#FF0000")
      .addFields(
        { name: "Author", value: `${message.author} (\`${message.author.id}\`)`, inline: true },
        { name: "Channel", value: `${message.channel} (\`${message.channel.id}\`)`, inline: true },
        { name: "Content", value: message.content?.slice(0, 1024) || "*(No text content)*", inline: false }
      )
      .setFooter({ text: `Message ID: ${message.id}` })
      .setTimestamp();

    if (message.attachments.size > 0) {
      embed.addFields({ name: "Attachments", value: `${message.attachments.size} file(s)`, inline: true });
    }

    await logChan.send({ embeds: [embed] }).catch(() => null);
  },
};
