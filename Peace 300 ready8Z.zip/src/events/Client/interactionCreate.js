const {
  InteractionType,
  PermissionsBitField,
  PermissionFlagsBits,
  EmbedBuilder,
  MessageFlags,
  ChannelType,
} = require("discord.js");

const db = require("../../schema/prefix.js");
const db3 = require("../../schema/setup");

const { TicketConfig, Ticket, TicketCategory } = require("../../schema/ticket.js");
const TicketHandler = require("../../utils/ticketHandler");

module.exports = {
  name: "interactionCreate",

  run: async (client, interaction) => {
    let prefix = client.prefix;
    const ress = await db.findOne({ Guild: interaction.guildId });
    if (ress?.Prefix) prefix = ress.Prefix;

    /* ================= AUTOCOMPLETE ================= */
    if (interaction.isAutocomplete()) {
      if (interaction.commandName === "setticket") {
        try {
          const categories = await TicketCategory.find({
            Guild: interaction.guildId,
            Enabled: true,
          }).limit(25);

          return interaction.respond(
            categories.map(cat => ({
              name: `${cat.Emoji} ${cat.Name}`,
              value: cat._id.toString(),
            }))
          );
        } catch {
          return interaction.respond([]);
        }
      }
      return;
    }

    /* ================= SLASH COMMANDS ================= */
    if (interaction.type === InteractionType.ApplicationCommand) {
      const command = client.slashCommands.get(interaction.commandName);
      if (!command) return;

      const embed = new EmbedBuilder().setColor(client.color);

      if (command.botPerms) {
        if (!interaction.guild.members.me.permissions.has(
          PermissionsBitField.resolve(command.botPerms)
        )) {
          embed.setDescription(
            `I don't have **\`${command.botPerms}\`** permission in ${interaction.channel}`
          );
          return interaction.reply({ embeds: [embed] });
        }
      }

      if (command.userPerms) {
        if (!interaction.member.permissions.has(
          PermissionsBitField.resolve(command.userPerms)
        )) {
          embed.setDescription(
            `You don't have **\`${command.userPerms}\`** permission in ${interaction.channel}`
          );
          return interaction.reply({ embeds: [embed] });
        }
      }

      try {
        await command.run(client, interaction, prefix);
      } catch (e) {
        console.error("Slash Command Error:", e);
        if (!interaction.replied && !interaction.deferred) {
          await interaction.reply({
            content: "❌ An unexpected error occurred while executing this command.",
            flags: MessageFlags.Ephemeral,
          }).catch(() => null);
        } else {
          await interaction.editReply({ 
            content: "❌ An unexpected error occurred while executing this command." 
          }).catch(() => null);
        }
      }
    }

    /* ================= MODAL ================= */
    if (interaction.isModalSubmit()) {
      try {
        const command = require("../../commands/Profile/bioset");
        return command.modalHandler(interaction);
      } catch (e) {
        console.error("Modal Error:", e);
      }
    }

    /* ================= SELECT MENU ================= */
    if (interaction.isStringSelectMenu()) {
      if (
        interaction.customId === "ticket_dropdown" ||
        interaction.customId === "ticket_category_select"
      ) {
        try {
          await interaction.deferReply({ ephemeral: true });

          const category = await TicketCategory.findById(interaction.values[0]);
          if (!category || !category.Enabled)
            return interaction.editReply({
              content: "❌ Invalid / disabled ticket category.",
            });

          const channel = await client.ticket.createTicket({
            guild: interaction.guild,
            user: interaction.user,
            category,
          });

          return interaction.editReply({
            content: `🎫 Ticket created: ${channel}`,
          });
        } catch (e) {
          console.log("Ticket Dropdown Error", e);
          return interaction.reply({
            ephemeral: true,
            content: "❌ Failed to create ticket",
          });
        }
      }
    }

    /* ================= BUTTONS ================= */
    if (interaction.isButton()) {
      const ticketHandler = new TicketHandler(client);

      /* ---- DROP CLAIM ---- */
      if (interaction.customId === "claim_drop") {
        try {
          const { claimDrop } = require("../../system/spawnDrop.js");
          const { getRarityData, formatNumber } = require("../../system/rarityChooser.js");

          const result = await claimDrop(
            client,
            interaction.guildId,
            interaction.user.id,
            interaction.user.username
          );

          if (!result.success)
            return interaction.reply({
              ephemeral: true,
              content: "❌ This drop is no longer claimable.",
            });

          const data = getRarityData(result.rarity);

          const claimedEmbed = new EmbedBuilder()
            .setColor(data.color)
            .setTitle(`${data.emoji} Drop Claimed!`)
            .setDescription(
              `Claimed by **${interaction.user.username}**\n\n<a:owo:1442395441181229177> +${formatNumber(
                result.owoAmount
              )}`
            );

          await interaction.message.edit({
            embeds: [claimedEmbed],
            components: [],
          });

          return interaction.reply({
            ephemeral: false,
            content: `🎉 ${interaction.user} claimed a **${data.label}** drop!`,
          });
        } catch (e) {
          console.log("Drop button error", e);
        }
      }

      /* ---- NEW TICKET PANEL BUTTON ---- */
      if (interaction.customId.startsWith("ticket_btn_")) {
        try {
          await interaction.deferReply({ ephemeral: true });

          const category = await TicketCategory.findById(
            interaction.customId.replace("ticket_btn_", "")
          );

          if (!category || !category.Enabled)
            return interaction.editReply({
              content: "❌ Ticket panel disabled / invalid.",
            });

          const ch = await client.ticket.createTicket({
            guild: interaction.guild,
            user: interaction.user,
            category,
          });

          return interaction.editReply({
            content: `🎫 Ticket created: ${ch}`,
          });
        } catch (e) {
          console.log("Ticket Button Error", e);
          return interaction.reply({
            ephemeral: true,
            content: "❌ Failed to open ticket",
          });
        }
      }

      /* ---- NEW SYSTEM TICKET CONTROLS ---- */
      if (interaction.customId === "close_ticket")
        return ticketHandler.handleCloseTicket(interaction);

      if (interaction.customId === "call_staff")
        return ticketHandler.handleCallStaff(interaction);

      if (interaction.customId === "delete_with_transcript")
        return ticketHandler.handleDeleteWithTranscript(interaction);

      /* ---- LEGACY CREATE TICKET ---- */
      if (interaction.customId === "create_ticket") {
        try {
          await interaction.deferReply({ ephemeral: true });

          const config = await TicketConfig.findOne({
            Guild: interaction.guildId,
          });

          if (!config)
            return interaction.editReply({
              content: "Ticket system not configured.",
            });

          const existing = await Ticket.findOne({
            Guild: interaction.guildId,
            User: interaction.user.id,
            Closed: false,
          });

          if (existing)
            return interaction.editReply({
              content: `You already have a ticket: <#${existing.Channel}>`,
            });

          const num = config.TicketCount + 1;
          const category = interaction.guild.channels.cache.get(config.Category);

          const channel = await interaction.guild.channels.create({
            name: `ticket-${num}`,
            type: ChannelType.GuildText,
            parent: category?.id,
            permissionOverwrites: [
              { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
              {
                id: interaction.user.id,
                allow: [
                  PermissionFlagsBits.ViewChannel,
                  PermissionFlagsBits.SendMessages,
                  PermissionFlagsBits.ReadMessageHistory,
                ],
              },
              {
                id: config.SupportRole,
                allow: [
                  PermissionFlagsBits.ViewChannel,
                  PermissionFlagsBits.SendMessages,
                  PermissionFlagsBits.ManageChannels,
                ],
              },
            ],
          });

          await Ticket.create({
            Guild: interaction.guildId,
            Channel: channel.id,
            User: interaction.user.id,
            TicketNumber: num,
          });

          config.TicketCount = num;
          await config.save();

          return interaction.editReply({
            content: `🎫 Ticket created: ${channel}`,
          });
        } catch (e) {
          console.log("Legacy Ticket Error", e);
        }
      }

      /* ---- LEGACY DELETE TICKET ---- */
      if (interaction.customId === "delete_ticket") {
        try {
          const ticket = await Ticket.findOne({
            Guild: interaction.guildId,
            Channel: interaction.channelId,
          });

          if (!ticket)
            return interaction.reply({
              ephemeral: true,
              content: "Invalid ticket channel.",
            });

          await interaction.reply({
            ephemeral: true,
            content: "Deleting ticket...",
          });

          await interaction.channel.delete();
          await Ticket.deleteOne({ _id: ticket._id });
        } catch (e) {
          console.log("Legacy delete error", e);
        }
      }

      /* ---- MUSIC PLAYER ---- */
      const data = await db3.findOne({ Guild: interaction.guildId });
      if (
        data &&
        interaction.channelId === data.Channel &&
        interaction.message.id === data.Message
      )
        return client.emit("playerButtons", interaction, data);
    }
  },
};