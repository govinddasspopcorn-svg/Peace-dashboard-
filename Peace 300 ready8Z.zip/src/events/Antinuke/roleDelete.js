const { EmbedBuilder, AuditLogEvent } = require("discord.js");
const AntiNuke = require("../../schema/antinuke");

module.exports = {
  name: "roleDelete",
  run: async (client, role) => {
    try {
      const config = await AntiNuke.findOne({ guildId: role.guild.id });
      if (!config?.isEnabled || !config.events.roleDelete) return;

      const auditLogs = await role.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.RoleDelete }).catch(() => null);
      const logEntry = auditLogs?.entries.first();
      if (!logEntry) return;

      const { executor, createdTimestamp } = logEntry;
      if (Date.now() - createdTimestamp > 5000) return;

      const isAuthorized = [role.guild.ownerId, client.user.id, ...config.extraOwners].includes(executor.id);
      const isEventWhitelisted = (config.whitelistedEvents.get("roleDelete") || []).includes(executor.id);
      if (isAuthorized || isEventWhitelisted) return;

      // PUNISH FIRST
      if (config.punishment === "ban") {
        await role.guild.members.ban(executor.id, { reason: "Peace Antinuke: Unauthorized Role Deletion" }).catch(() => null);
      } else if (config.punishment === "kick") {
        await role.guild.members.kick(executor.id, "Peace Antinuke: Unauthorized Role Deletion").catch(() => null);
      }

      // RECOVERY: Restore role
      const restoredRole = await role.guild.roles.create({
        name: role.name,
        color: role.color,
        hoist: role.hoist,
        permissions: role.permissions,
        mentionable: role.mentionable,
        position: role.position,
        reason: "Peace Antinuke: Auto-Recovery System"
      }).catch(() => null);

      // LOGGING
      if (config.logChannelId) {
        const logChan = role.guild.channels.cache.get(config.logChannelId);
        if (logChan) {
          const logEmbed = new EmbedBuilder()
            .setAuthor({ name: "Security Alert: Role Deleted", iconURL: executor.displayAvatarURL() })
            .setColor("#FF0000")
            .setThumbnail(executor.displayAvatarURL({ dynamic: true }))
            .setDescription(
              `**Action:** Role Deletion\n` +
              `**Target Role:** ${role.name}\n` +
              `**Executor:** ${executor.tag} (\`${executor.id}\`)\n` +
              `**Recovery:** ${restoredRole ? "✅ Role Restored" : "❌ Restoration Failed"}\n` +
              `**Outcome:** Actor ${config.punishment === "none" ? "Logged" : `${config.punishment}ned`}`
            )
            .setFooter({ text: "Peace Security", iconURL: client.user.displayAvatarURL() })
            .setTimestamp();
          await logChan.send({ embeds: [logEmbed] }).catch(() => null);
        }
      }
    } catch (err) {
      console.error("[ANTINUKE] roleDelete error:", err);
    }
  },
};
