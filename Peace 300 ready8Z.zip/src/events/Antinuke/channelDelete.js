const { EmbedBuilder, AuditLogEvent, ChannelType, PermissionsBitField } = require("discord.js");
const AntiNuke = require("../../schema/antinuke");

module.exports = {
  name: "channelDelete",
  run: async (client, channel) => {
    try {
      const config = await AntiNuke.findOne({ guildId: channel.guild.id });
      if (!config?.isEnabled || !config.events.channelDelete) return;

      const auditLogs = await channel.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelDelete }).catch(() => null);
      const logEntry = auditLogs?.entries.first();
      if (!logEntry) return;

      const { executor, createdTimestamp } = logEntry;
      if (Date.now() - createdTimestamp > 5000) return;

      const isAuthorized = [channel.guild.ownerId, client.user.id, ...config.extraOwners].includes(executor.id);
      const isEventWhitelisted = (config.whitelistedEvents.get("channelDelete") || []).includes(executor.id);
      if (isAuthorized || isEventWhitelisted) return;

      // PUNISH FIRST
      if (config.punishment === "ban") {
        await channel.guild.members.ban(executor.id, { reason: "Peace Antinuke: Unauthorized Channel Deletion" }).catch(() => null);
      } else if (config.punishment === "kick") {
        const executorMember = await channel.guild.members.fetch(executor.id).catch(() => null);
        if (executorMember) await executorMember.kick("Peace Antinuke: Unauthorized Channel Deletion").catch(() => null);
      }

      // REVERSE THE ACTION: RESTORE CHANNEL
      const restoredChannel = await channel.guild.channels.create({
        name: channel.name,
        type: channel.type,
        topic: channel.topic,
        nsfw: channel.nsfw,
        bitrate: channel.bitrate,
        userLimit: channel.userLimit,
        parent: channel.parentId,
        position: channel.position,
        permissionOverwrites: channel.permissionOverwrites.cache.map(ov => ({
          id: ov.id,
          allow: ov.allow,
          deny: ov.deny,
          type: ov.type
        })),
        reason: "Peace Antinuke: Auto-Recovery System"
      }).catch(err => {
        console.error("[ANTINUKE] Auto-Recovery Failed:", err);
        return null;
      });

      // LOGGING
      if (config.logChannelId) {
        const logChan = channel.guild.channels.cache.get(config.logChannelId);
        if (logChan) {
          const logEmbed = new EmbedBuilder()
            .setAuthor({ name: "Security Alert: Channel Deleted", iconURL: executor.displayAvatarURL() })
            .setColor("#FF0000")
            .setDescription(
              `**Action:** Channel Deletion\n` +
              `**Target:** #${channel.name}\n` +
              `**Executor:** ${executor.tag} (\`${executor.id}\`)\n` +
              `**Recovery:** ${restoredChannel ? "✅ Channel Restored" : "❌ Restoration Failed"}\n` +
              `**Punishment:** ${config.punishment.toUpperCase()}`
            )
            .setTimestamp();
          await logChan.send({ embeds: [logEmbed] }).catch(() => null);
        }
      }
    } catch (err) {
      console.error("[ANTINUKE] channelDelete error:", err);
    }
  },
};
