const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const AntiNuke = require("../../schema/antinuke");

module.exports = {
  name: "messageCreate",
  run: async (client, message) => {
    try {
      if (!message.guild || message.author.bot) return;

      const hasEveryone = message.content.includes("@everyone");
      const hasHere = message.content.includes("@here");
      if (!hasEveryone && !hasHere) return;

      const data = await AntiNuke.findOne({ guildId: message.guild.id });
      if (!data?.isEnabled || !data.events.antiEveryone) return;

      const m = message.member;
      const isAuthorized = [message.guild.ownerId, client.user.id, ...data.extraOwners].includes(m.id);
      const isEventWhitelisted = (data.whitelistedEvents.get("antiEveryone") || []).includes(m.id);

      if (isAuthorized || isEventWhitelisted) return;

      // Check if user has legitimate permission (Admin bypass)
      if (m.permissions.has(PermissionsBitField.Flags.Administrator)) return;

      // ACTION
      await message.delete().catch(() => {});
      
      if (data.punishment === "ban") {
        await m.ban({ reason: "Peace Antinuke: Unauthorized @everyone/@here mention" }).catch(() => null);
      } else if (data.punishment === "kick") {
        await m.kick("Peace Antinuke: Unauthorized @everyone/@here mention").catch(() => null);
      }

      // Extra safety: sweep for recent everyone/here messages from this user in this channel
      // AND delete the channel if it was recently created by the nuker (for channel creation pings)
      if (message.channel.createdTimestamp > (Date.now() - 60000)) {
         await message.channel.delete("Peace Antinuke: Unauthorized Channel Creation with Mention").catch(() => null);
      } else {
        const messages = await message.channel.messages.fetch({ limit: 20 }).catch(() => null);
        if (messages) {
          const userMessages = messages.filter(msg => 
            msg.author.id === message.author.id && 
            (msg.content.includes("@everyone") || msg.content.includes("@here"))
          );
          for (const msg of userMessages.values()) {
            await msg.delete().catch(() => null);
          }
        }
      }

      // LOGGING
      if (data.logChannelId) {
        const logChan = message.guild.channels.cache.get(data.logChannelId);
        if (logChan) {
          const logEmbed = new EmbedBuilder()
            .setAuthor({ name: "Security Alert: Unauthorized Mention", iconURL: message.author.displayAvatarURL() })
            .setColor("#FF0000")
            .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
            .setDescription(
              `**Action:** Unauthorized @everyone/@here\n` +
              `**Executor:** ${message.author.tag} (\`${message.author.id}\`)\n` +
              `**Channel:** ${message.channel}\n` +
              `**Outcome:** Message Deleted & User ${data.punishment === "none" ? "Logged" : `${data.punishment}ned`}`
            )
            .setFooter({ text: "Peace Security", iconURL: client.user.displayAvatarURL() })
            .setTimestamp();
          await logChan.send({ embeds: [logEmbed] }).catch(() => null);
        }
      }
    } catch (err) {
      console.error("[ANTINUKE] antiEveryone error:", err);
    }
  },
};
