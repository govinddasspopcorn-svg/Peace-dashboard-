const { EmbedBuilder, AuditLogEvent } = require("discord.js");
const AntiNuke = require("../../schema/antinuke");

module.exports = {
  name: "guildBanAdd",
  run: async (client, ban) => {
    try {
      const config = await AntiNuke.findOne({ guildId: ban.guild.id });
      if (!config?.isEnabled || !config.events.ban) return;

      const auditLogs = await ban.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MemberBanAdd }).catch(() => null);
      const logEntry = auditLogs?.entries.first();
      if (!logEntry) return;

      const { executor, createdTimestamp } = logEntry;
      if (Date.now() - createdTimestamp > 5000) return;

      const isAuthorized = [ban.guild.ownerId, client.user.id, ...config.extraOwners].includes(executor.id);
      const isEventWhitelisted = (config.whitelistedEvents.get("ban") || []).includes(executor.id);
      if (isAuthorized || isEventWhitelisted) return;

      if (config.punishment === "ban") {
        await ban.guild.members.ban(executor.id, { reason: "Peace Antinuke: Unauthorized User Ban" }).catch(() => null);
      } else if (config.punishment === "kick") {
        const executorMember = await ban.guild.members.fetch(executor.id).catch(() => null);
        if (executorMember) await executorMember.kick("Peace Antinuke: Unauthorized User Ban").catch(() => null);
      }

      // ACTION: UNBAN TARGET
      await ban.guild.members.unban(ban.user.id, "Peace Antinuke: Unauthorized Ban Reversal").catch(() => null);

      // LOGGING
      if (config.logChannelId) {
        const logChan = ban.guild.channels.cache.get(config.logChannelId);
        if (logChan) {
          const logEmbed = new EmbedBuilder()
            .setAuthor({ name: "Security Alert: Unauthorized Ban", iconURL: executor.displayAvatarURL() })
            .setColor("#FF0000")
            .setThumbnail(executor.displayAvatarURL({ dynamic: true }))
            .setDescription(
              `**Action:** Unauthorized Ban\n` +
              `**Target:** ${ban.user.tag} (\`${ban.user.id}\`)\n` +
              `**Executor:** ${executor.tag} (\`${executor.id}\`)\n` +
              `**Recovery:** ✅ User Unbanned\n` +
              `**Outcome:** Actor ${config.punishment === "none" ? "Logged" : `${config.punishment}ned`}`
            )
            .setFooter({ text: "Peace Security", iconURL: client.user.displayAvatarURL() })
            .setTimestamp();
          await logChan.send({ embeds: [logEmbed] }).catch(() => null);
        }
      }
    } catch (err) {
      console.error("[ANTINUKE] antiBan error:", err);
    }
  },
};
