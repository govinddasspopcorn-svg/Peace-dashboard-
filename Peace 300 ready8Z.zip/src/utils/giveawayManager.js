const { EmbedBuilder } = require("discord.js");
const Giveaway = require("../schema/giveaway");

class GiveawayManager {
  constructor(client) {
    this.client = client;
    this.timers = new Map();
  }

  /** Parse duration like 1m 2h 3d */
  parseDuration(time) {
    if (!time || typeof time !== "string") return 0;
    const regex = /(\d+)(s|m|h|d|w)/g;
    let match;
    let duration = 0;
    while ((match = regex.exec(time)) !== null) {
      const value = parseInt(match[1], 10);
      const unit = match[2];
      if (unit === "s") duration += value * 1000;
      if (unit === "m") duration += value * 60 * 1000;
      if (unit === "h") duration += value * 60 * 60 * 1000;
      if (unit === "d") duration += value * 24 * 60 * 60 * 1000;
      if (unit === "w") duration += value * 7 * 24 * 60 * 60 * 1000;
    }
    return duration;
  }

  /** CREATE GIVEAWAY – NOW SUPPORTS PREFIX + SLASH */
  async createGiveaway(context, prize, durationMs, winners = 1, channelId = null) {
    try {
      const isSlash = !!context.user;
      const user = isSlash ? context.user : context.author;
      const guild = context.guild;
      const channel = channelId
        ? await guild.channels.fetch(channelId).catch(() => null)
        : context.channel;

      if (!channel) return { success: false, error: "Channel not found." };

      const now = Date.now();
      const endTime = now + durationMs;

      // ⭐ PREMIUM GOLD GIVEAWAY UI (your original design)
      const embed = new EmbedBuilder()
        .setColor("#FFD700")
        .setTitle("        <:gift:1442729822676582573> **GIVEAWAY** <:gift:1442729822676582573>")
        .setDescription(
`
 <:WELCOME:1442385037805752380> **Prize:** ${prize}
<:CROWN:1442384899372875776>**Hosted by:** <@${user.id}>
<a:HEART:1442384835829170217> **Winners:** ${winners}

<a:time:1440233667048902737> **Ends:** <t:${Math.floor(endTime / 1000)}:R>  

<a:giveaway:1440153256964788306> **React with this emoji to enter!**
`
        );

      const message = await channel.send({ embeds: [embed] });

      // Reaction enter emoji
      try {
        await message.react("<a:giveaway:1440153256964788306>");
      } catch (err) {}

      const doc = await Giveaway.create({
        guildId: guild.id,
        channelId: channel.id,
        messageId: message.id,
        hostId: user.id,
        prize,
        winners,
        startTime: now,
        endTime,
        ended: false,
        participants: [],
        emoji: "<a:giveaway:1440153256964788306>",
      });

      this._scheduleEnd(doc);

      return { success: true, id: doc._id };
    } catch (err) {
      console.error("createGiveaway error:", err);
      return { success: false, error: err.message || "Unknown error" };
    }
  }

  /** SCHEDULE END */
  _scheduleEnd(doc) {
    const timeLeft = Math.max(0, doc.endTime - Date.now());

    if (this.timers.has(doc.messageId)) {
      clearTimeout(this.timers.get(doc.messageId));
    }

    const t = setTimeout(() => this.endGiveaway(doc.messageId), timeLeft);
    this.timers.set(doc.messageId, t);
  }

  /** LOAD GIVEAWAYS ON START */
  async loadGiveaways() {
    try {
      const now = Date.now();
      const active = await Giveaway.find({ ended: false, endTime: { $gt: now } }).lean();

      for (const doc of active) {
        const guild = await this.client.guilds.fetch(doc.guildId).catch(() => null);
        if (!guild) continue;

        const channel = await guild.channels.fetch(doc.channelId).catch(() => null);
        if (!channel) continue;

        const msg = await channel.messages.fetch(doc.messageId).catch(() => null);
        if (msg) {
          try {
            const existing = msg.reactions.cache.find(r => {
              if (r.emoji.id) return r.emoji.id === doc.emoji.replace(/\D/g, "");
              return r.emoji.name === doc.emoji;
            });

            if (!existing) {
              await msg.react(doc.emoji).catch(() => {});
            }
          } catch (e) {}
        }

        this._scheduleEnd(doc);
      }
      return true;
    } catch (err) {
      console.error("loadGiveaways error:", err);
      return false;
    }
  }

  /** END GIVEAWAY */
  async endGiveaway(messageId) {
    try {
      const doc = await Giveaway.findOne({ messageId, ended: false });
      if (!doc) return;

      const channel = await this.client.channels.fetch(doc.channelId).catch(() => null);
      if (!channel) {
        doc.ended = true;
        await doc.save();
        return;
      }

      const msg = await channel.messages.fetch(doc.messageId).catch(() => null);

      let participants = doc.participants || [];

      // Fetch from reaction if DB empty
      if ((!participants || participants.length === 0) && msg) {
        const reaction = msg.reactions.cache.find(r => r.emoji.id === "1440153256964788306");
        if (reaction) {
          const users = await reaction.users.fetch();
          participants = users.filter(u => !u.bot).map(u => u.id);
        }
      }

      // No participants case
      if (participants.length === 0) {
        const noEmbed = new EmbedBuilder()
          .setColor("#FFD700")
          .setTitle("<a:HEART:1442384835829170217> Giveaway Ended — No Participants")
          .setDescription(`Nobody entered the giveaway for **${doc.prize}**.`);
        await channel.send({ embeds: [noEmbed] });

        doc.ended = true;
        await doc.save();
        return;
      }

      // Pick winners
      const winners = [];
      const pool = [...new Set(participants)];
      const pickCount = Math.min(doc.winners || 1, pool.length);

      for (let i = 0; i < pickCount; i++) {
        const idx = Math.floor(Math.random() * pool.length);
        winners.push(pool.splice(idx, 1)[0]);
      }

      doc.winnerUsers = winners;
      doc.ended = true;
      await doc.save();

      // ⭐ PREMIUM GOLD END EMBED
      const endEmbed = new EmbedBuilder()
        .setColor("#FFD700")
        .setTitle("<:gift:1442729822676582573> **GIVEAWAY ENDED!**")
        .setDescription(
`
<:WELCOME:1442385037805752380> **Prize:** ${doc.prize}
<:CROWN:1442384899372875776> **Hosted by:** <@${doc.hostId}>

<a:HEART:1442384835829170217> **Winner(s):**  
${winners.map(id => `<@${id}>`).join(", ")}

<a:giveaway:1440153256964788306> Thanks for participating!
`
        );

      await channel.send({ embeds: [endEmbed] });

      if (this.timers.has(messageId)) {
        clearTimeout(this.timers.get(messageId));
        this.timers.delete(messageId);
      }
    } catch (err) {
      console.error("endGiveaway error:", err);
    }
  }

  /** REROLL */
  async rerollGiveaway(messageId) {
    try {
      const doc = await Giveaway.findOne({ messageId, ended: true });
      if (!doc) return { success: false, error: "Giveaway not found or not ended." };

      const participants = doc.participants || [];
      if (participants.length === 0)
        return { success: false, error: "No participants to reroll." };

      const pool = [...new Set(participants)];
      const winner = pool[Math.floor(Math.random() * pool.length)];

      doc.winnerUsers = [winner];
      await doc.save();

      return { success: true, winner };
    } catch (err) {
      console.error("rerollGiveaway error:", err);
      return { success: false, error: err.message || "Unknown" };
    }
  }
}

module.exports = GiveawayManager;
