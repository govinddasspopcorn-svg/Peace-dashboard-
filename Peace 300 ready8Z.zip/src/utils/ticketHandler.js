const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

const {
  Ticket,
  TicketCategory,
  TicketCounter,
} = require("../schema/ticket");

const Transcript = require("discord-html-transcripts");

class TicketHandler {
  constructor(client) {
    this.client = client;
  }

  /* ===========================================
        CREATE TICKET
  ============================================ */
  async createTicket({ guild, user, category }) {
    try {

      // ================= PER PANEL LIMIT =================
      const existing = await Ticket.findOne({
        Guild: guild.id,
        User: user.id,
        CategoryId: category._id,
        Status: { $ne: "closed" }
      });

      if (existing) {
        const ch = guild.channels.cache.get(existing.Channel);
        return { blocked: true, channel: ch || null };
      }

      // ================= AUTO SAFE CATEGORY CREATION =================
      let openCategoryId = category.OpenCategory || null;
      let closedCategoryId = category.ClosedCategory || null;
      let logsChannelId = category.LogsChannel || null;

      // -------- OPEN CATEGORY --------
      if (!openCategoryId) {
        const openCat = await guild.channels.create({
          name: "🎫 Open Tickets",
          type: 4
        });

        category.OpenCategory = openCat.id;
        await category.save();
        openCategoryId = openCat.id;
      }

      let openCatObj = guild.channels.cache.get(openCategoryId);
      if (!openCatObj || openCatObj.type !== 4) {
        const openCat = await guild.channels.create({
          name: "🎫 Open Tickets",
          type: 4
        });

        category.OpenCategory = openCat.id;
        await category.save();
        openCategoryId = openCat.id;
      }

      // -------- CLOSED CATEGORY --------
      if (!closedCategoryId) {
        const closedCat = await guild.channels.create({
          name: "🔒 Closed Tickets",
          type: 4
        });

        category.ClosedCategory = closedCat.id;
        await category.save();
        closedCategoryId = closedCat.id;
      }

      let closedCatObj = guild.channels.cache.get(closedCategoryId);
      if (!closedCatObj || closedCatObj.type !== 4) {
        const closedCat = await guild.channels.create({
          name: "🔒 Closed Tickets",
          type: 4
        });

        category.ClosedCategory = closedCat.id;
        await category.save();
        closedCategoryId = closedCat.id;
      }

      // -------- LOGS CHANNEL --------
      if (!logsChannelId) {
        const logs = await guild.channels.create({
          name: "📜 ticket-logs",
          type: 0
        });

        category.LogsChannel = logs.id;
        await category.save();
        logsChannelId = logs.id;
      }

      // ================= Counter =================
      let counter = await TicketCounter.findOne({ Guild: guild.id });

      if (!counter)
        counter = await TicketCounter.create({
          Guild: guild.id,
          Count: 1,
        });

      const ticketNumber = counter.Count;
      counter.Count++;
      await counter.save();

      // ================= Create Channel =================
      const channel = await guild.channels.create({
        name: `ticket-${ticketNumber}`,
        type: 0,
        parent: openCategoryId,
        permissionOverwrites: [
          { id: guild.id, deny: ["ViewChannel"] },

          {
            id: user.id,
            allow: [
              "ViewChannel",
              "SendMessages",
              "AttachFiles",
              "EmbedLinks",
            ],
          },

          ...(category.SupportRoles || []).map(r => ({
            id: r,
            allow: ["ViewChannel", "SendMessages", "AttachFiles"],
          })),
        ],
      });

      // ================= Save DB =================
      await Ticket.create({
        Guild: guild.id,
        Channel: channel.id,
        User: user.id,
        Status: "open",
        TicketNumber: ticketNumber,
        CategoryId: category._id,
        CreatedAt: new Date(),
      });

      // ================= Ticket Message =================
      const embed = new EmbedBuilder()
        .setColor("#2b2d31")
        .setTitle(`<a:ticket:1414311755311484958> Ticket Created`)
        .setDescription(
          `${user}\n\n` +
          `<:member:1451140903409287305> **User:** ${user}\n` +
          `<:note:1451140914717265960> Please explain your issue in detail.\n` +
          `<:mod:1451140943091597323> Staff will assist you shortly.`
        )
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("close_ticket")
          .setLabel("Close")
          .setStyle(ButtonStyle.Danger),

        new ButtonBuilder()
          .setCustomId("call_staff")
          .setLabel("Call Staff")
          .setStyle(ButtonStyle.Secondary),

        new ButtonBuilder()
          .setCustomId("delete_with_transcript")
          .setLabel("Delete + Transcript")
          .setStyle(ButtonStyle.Primary)
      );

      await channel.send({
        content: `<@${user.id}>`,
        embeds: [embed],
        components: [row],
      });

      // ================= OPEN LOGS =================
      if (category?.LogsChannel) {
        const log = guild.channels.cache.get(category.LogsChannel);
        if (log)
          log.send({
            embeds: [
              new EmbedBuilder()
                .setColor("#2b2d31")
                .setTitle(`<a:ticket:1414311755311484958> Ticket Opened`)
                .setDescription(
                  `<:member:1451140903409287305> User: ${user}\n` +
                  `<:note:1451140914717265960> Panel: **${category.Name}**\n` +
                  `#️⃣ Number: **${ticketNumber}**\n` +
                  `📌 Channel: ${channel}`
                )
                .setTimestamp()
            ]
          }).catch(() => {});
      }

      // 🔥 THIS FIXES [object Object]
      return channel;

    } catch (err) {
      console.log("Ticket Create Error:", err);
      return null;
    }
  }

  /* ===========================================
        CLOSE TICKET
  ============================================ */
  async handleCloseTicket(interaction) {
    const ticket = await Ticket.findOne({
      Channel: interaction.channel.id,
      Guild: interaction.guild.id,
    });

    if (!ticket)
      return interaction.reply({
        content: "❌ This is not a registered ticket.",
        ephemeral: true,
      });

    if (ticket.Status === "closed")
      return interaction.reply({
        content: "❌ Ticket already closed.",
        ephemeral: true,
      });

    ticket.Status = "closed";
    ticket.ClosedAt = new Date();
    ticket.ClosedBy = interaction.user.id;
    await ticket.save();

    await interaction.reply({
      content: "✅ Ticket closed successfully.",
      ephemeral: true,
    });

    const category = await TicketCategory.findById(ticket.CategoryId);
    if (category?.ClosedCategory) {
      const closedCat = interaction.guild.channels.cache.get(category.ClosedCategory);
      if (closedCat)
        interaction.channel.setParent(closedCat.id).catch(() => {});
    }

    await interaction.channel.send({
      embeds: [
        new EmbedBuilder()
          .setColor("#ff4747")
          .setTitle(`🔒 Ticket Closed`)
          .setDescription(
            `<:note:1451140914717265960> This ticket is now closed.\n` +
            `<:responder:1451140931313995917> Use **Delete + Transcript** to permanently delete.`
          )
      ]
    });
  }

  /* ===========================================
        CALL STAFF
  ============================================ */
  async handleCallStaff(interaction) {
    const ticket = await Ticket.findOne({
      Channel: interaction.channel.id,
      Guild: interaction.guild.id,
    });

    if (!ticket)
      return interaction.reply({
        content: "❌ This is not a registered ticket.",
        ephemeral: true,
      });

    const category = await TicketCategory.findById(ticket.CategoryId);

    if (!category)
      return interaction.reply({
        content: "<:cross:1455452613645566147> Ticket category missing.",
        ephemeral: true,
      });

    if (!category.SupportRoles?.length)
      return interaction.reply({
        content: "<:cross:1455452613645566147> No support roles configured.",
        ephemeral: true,
      });

    const pings = category.SupportRoles.map(r => `<@&${r}>`).join(" ");

    return interaction.reply({
      content: `🚨 **Staff Requested!**\n${pings}`,
    });
  }

  /* ===========================================
        DELETE + TRANSCRIPT
  ============================================ */
  async handleDeleteWithTranscript(interaction) {
    const ticket = await Ticket.findOne({
      Channel: interaction.channel.id,
      Guild: interaction.guild.id,
    });

    if (!ticket)
      return interaction.reply({
        content: "❌ This is not a registered ticket.",
        ephemeral: true,
      });

    const category = await TicketCategory.findById(ticket.CategoryId);

    ticket.Status = "closed";
    ticket.ClosedAt = new Date();
    ticket.ClosedBy = interaction.user.id;
    await ticket.save();

    const attachment = await Transcript.createTranscript(interaction.channel);

    // ================= LOGS =================
    if (category?.LogsChannel) {
      const log = interaction.guild.channels.cache.get(category.LogsChannel);
      if (log)
        await log.send({
          embeds: [
            new EmbedBuilder()
              .setColor("#2b2d31")
              .setTitle(`<:delete:1455452260774711441> Ticket Deleted`)
              .setDescription(
                `<:member:1451140903409287305> User: <@${ticket.User}>\n` +
                `<:note:1451140914717265960> Panel: **${category.Name}**\n` +
                `📌 Channel: ${interaction.channel.name}\n` +
                `<:mod:1451140943091597323> Staff: ${interaction.user}`
              )
              .setTimestamp()
          ],
          files: [attachment]
        }).catch(() => {});
    }

    // ================= DM USER =================
    try {
      const user = await this.client.users.fetch(ticket.User);
      await user.send({
        embeds: [
          new EmbedBuilder()
            .setColor("#2b2d31")
            .setTitle(`<a:ticket:1414311755311484958> Your Ticket Has Been Closed`)
            .setDescription(
              `<:note:1451140914717265960> Panel: **${category.Name}**\n` +
              `<:mod:1451140943091597323> Staff: ${interaction.user}\n\n` +
              `📄 Transcript attached.`
            )
            .setTimestamp()
        ],
        files: [attachment]
      }).catch(() => {});
    } catch {}

    await interaction.reply({
      content: "<:delete:1455452260774711441> Ticket deleted with transcript.",
      ephemeral: true,
    });

    setTimeout(() => {
      interaction.channel.delete().catch(() => {});
    }, 2000);
  }
}

module.exports = TicketHandler;