const DropUser = require("../schema/dropUser");
const DropGuild = require("../schema/dropGuild");

async function getUser(userId) {
  let user = await DropUser.findOne({ UserId: userId });
  if (!user) {
    user = new DropUser({ UserId: userId });
    await user.save();
  }
  return user;
}

async function saveUser(user) {
  return await user.save();
}

async function getGuild(guildId) {
  let guild = await DropGuild.findOne({ GuildId: guildId });
  if (!guild) {
    guild = new DropGuild({ GuildId: guildId });
    await guild.save();
  }
  return guild;
}

async function saveGuild(guild) {
  return await guild.save();
}

async function getAllEnabledGuilds() {
  return await DropGuild.find({ enabled: true });
}

async function resetUserData(userId) {
  await DropUser.findOneAndUpdate(
    { UserId: userId },
    {
      owo: 0,
      ltc: 0,
      dropsClaimed: 0,
      rarityStats: {
        mythical: 0,
        legendary: 0,
        rare: 0,
        uncommon: 0,
        common: 0,
      },
      cooldowns: {
        mythical: 0,
        legendary: 0,
        rare: 0,
      },
      claimHistory: [],
    },
    { upsert: true }
  );
}

async function addOwoToUser(userId, amount) {
  const user = await getUser(userId);
  user.owo += amount;
  await saveUser(user);
  return user;
}

async function getLeaderboard(limit = 10) {
  return await DropUser.find({}).sort({ owo: -1 }).limit(limit);
}

module.exports = {
  getUser,
  saveUser,
  getGuild,
  saveGuild,
  getAllEnabledGuilds,
  resetUserData,
  addOwoToUser,
  getLeaderboard,
  DropUser,
  DropGuild,
};
