const { chooseRarity, getRarityData, formatNumber } = require("./rarityChooser.js");
const db = require("../utils/dropsDB.js");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

const DROP_EXPIRY_MS = 5 * 60 * 1000;

async function expireCurrentDrop(client, guild) {
  if (guild.activeDrop && guild.activeDrop.messageId && guild.activeDrop.rarity) {
    try {
      const channel = await client.channels.fetch(guild.dropChannel).catch(() => null);
      if (channel) {
        const message = await channel.messages.fetch(guild.activeDrop.messageId).catch(() => null);
        if (message) {
          const expiredEmbed = new EmbedBuilder()
            .setColor("#666666")
            .setTitle("Drop Expired!")
            .setDescription(`The **${guild.activeDrop.rarity.toUpperCase()}** drop has expired. No one claimed it!`)
            .setTimestamp();
          await message.edit({ embeds: [expiredEmbed], components: [] }).catch(() => null);
        }
      }
    } catch (e) {
      console.error("Error expiring drop message:", e);
    }
  }

  guild.activeDrop = {
    rarity: null,
    rewardOwo: 0,
    rewardLtc: 0,
    spawnedAt: 0,
    expiresAt: 0,
    messageId: null,
  };
  await db.saveGuild(guild);
}

async function spawnDropForGuild(client, guildId, prefix = "!", forceRarity = null) {
  const guild = await db.getGuild(guildId);
  if (!guild || !guild.enabled || !guild.dropChannel) return { success: false, reason: "not_configured" };

  const now = Date.now();

  if (guild.activeDrop && guild.activeDrop.rarity) {
    if (now < guild.activeDrop.expiresAt) {
      return { success: false, reason: "active_drop_exists" };
    } else {
      await expireCurrentDrop(client, guild);
    }
  }

  let rarity, data;
  if (forceRarity) {
    rarity = forceRarity.toLowerCase();
    data = getRarityData(rarity);
  } else {
    const result = chooseRarity();
    rarity = result.rarity;
    data = result.data;
  }

  const channel = await client.channels.fetch(guild.dropChannel).catch(() => null);
  if (!channel) return { success: false, reason: "channel_not_found" };

  const expiresAt = now + DROP_EXPIRY_MS;

  const embed = new EmbedBuilder()
    .setColor(data.color)
    .setTitle(`${data.emoji} ${data.label} Drop!`)
    .setDescription(
      `A **${data.label}** drop has appeared!\n\n` +
      `**Rewards:**\n` +
      `<a:owo:1442395441181229177> **${formatNumber(data.reward)} OWO**\n` +
      (data.ltc > 0 ? `<a:ltc:1442395484802121822> **$${data.ltc.toFixed(2)} LTC**\n` : "") +
      `\nType \`${prefix}dclaim\` or \`/dclaim\` to claim!\n` +
      `First claimer wins! Expires <t:${Math.floor(expiresAt / 1000)}:R>`
    )
    .setFooter({ text: `Be quick! This drop expires in 5 minutes.` })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("claim_drop")
      .setLabel("Claim Drop!")
      .setStyle(ButtonStyle.Success)
      .setEmoji("🎁")
  );

  const sentMessage = await channel.send({ embeds: [embed], components: [row] });

  guild.activeDrop = {
    rarity: rarity,
    rewardOwo: data.reward,
    rewardLtc: data.ltc,
    spawnedAt: now,
    expiresAt: expiresAt,
    messageId: sentMessage.id,
  };
  guild.totalDrops += 1;
  await db.saveGuild(guild);

  console.log(`[DROP] Spawned ${rarity.toUpperCase()} drop in guild ${guildId}`);

  return { success: true, rarity, data, messageId: sentMessage.id };
}

async function claimDrop(client, guildId, userId, username) {
  const guild = await db.getGuild(guildId);
  const now = Date.now();

  if (!guild.activeDrop || !guild.activeDrop.rarity) {
    return { success: false, reason: "no_active_drop" };
  }

  if (now > guild.activeDrop.expiresAt) {
    await expireCurrentDrop(client, guild);
    return { success: false, reason: "drop_expired" };
  }

  const rarity = guild.activeDrop.rarity;
  const data = getRarityData(rarity);
  const user = await db.getUser(userId);

  if (data.cooldownMs > 0) {
    const userCooldown = user.cooldowns[rarity] || 0;
    if (now < userCooldown) {
      const remaining = Math.ceil((userCooldown - now) / 1000);
      const hours = Math.floor(remaining / 3600);
      const days = Math.floor(hours / 24);
      let timeStr = "";
      if (days > 0) timeStr = `${days} day(s)`;
      else if (hours > 0) timeStr = `${hours} hour(s)`;
      else timeStr = `${Math.ceil(remaining / 60)} minute(s)`;
      return { success: false, reason: "cooldown", timeRemaining: timeStr, rarity };
    }
  }

  user.owo += guild.activeDrop.rewardOwo;
  user.ltc += guild.activeDrop.rewardLtc;
  user.dropsClaimed += 1;
  user.rarityStats[rarity] = (user.rarityStats[rarity] || 0) + 1;

  if (data.cooldownMs > 0) {
    user.cooldowns[rarity] = now + data.cooldownMs;
  }

  user.claimHistory.push({
    rarity: rarity,
    owoAmount: guild.activeDrop.rewardOwo,
    ltcAmount: guild.activeDrop.rewardLtc,
    claimedAt: new Date(),
    guildId: guildId,
  });

  await db.saveUser(user);

  if (guild.activeDrop.rewardLtc > 0) {
    console.log("=".repeat(60));
    console.log("[LTC PAYMENT REQUIRED]");
    console.log(`User: ${username} (${userId})`);
    console.log(`Rarity: ${rarity.toUpperCase()}`);
    console.log(`LTC Amount: $${guild.activeDrop.rewardLtc.toFixed(2)}`);
    console.log(`OWO Amount: ${formatNumber(guild.activeDrop.rewardOwo)}`);
    console.log(`Timestamp: ${new Date().toISOString()}`);
    console.log("=".repeat(60));
  }

  const claimedRarity = rarity;
  const claimedOwo = guild.activeDrop.rewardOwo;
  const claimedLtc = guild.activeDrop.rewardLtc;
  const messageId = guild.activeDrop.messageId;

  guild.activeDrop = {
    rarity: null,
    rewardOwo: 0,
    rewardLtc: 0,
    spawnedAt: 0,
    expiresAt: 0,
    messageId: null,
  };
  guild.totalClaimed += 1;
  await db.saveGuild(guild);

  return {
    success: true,
    rarity: claimedRarity,
    owoAmount: claimedOwo,
    ltcAmount: claimedLtc,
    messageId: messageId,
  };
}

module.exports = {
  spawnDropForGuild,
  claimDrop,
  expireCurrentDrop,
  DROP_EXPIRY_MS,
};
