const RARITIES = {
  mythical: {
    chance: 0.5,
    reward: 500000,
    ltc: 0.10,
    color: "#FF00FF",
    emoji: "<:mythical:1442729822676582573>",
    cooldownMs: 7 * 24 * 60 * 60 * 1000,
    label: "MYTHICAL",
  },
  legendary: {
    chance: 1.0,
    reward: 250000,
    ltc: 0.05,
    color: "#FFD700",
    emoji: "<:legendary:1442729822676582573>",
    cooldownMs: 5 * 24 * 60 * 60 * 1000,
    label: "LEGENDARY",
  },
  rare: {
    chance: 2.5,
    reward: 100000,
    ltc: 0.02,
    color: "#0099FF",
    emoji: "<:rare:1442729822676582573>",
    cooldownMs: 24 * 60 * 60 * 1000,
    label: "RARE",
  },
  uncommon: {
    chance: 6.0,
    reward: 25000,
    ltc: 0.0095,
    color: "#00FF00",
    emoji: "<:uncommon:1442729822676582573>",
    cooldownMs: 6 * 60 * 60 * 1000,
    label: "UNCOMMON",
  },
  common: {
    chance: 90.0,
    reward: 5000,
    ltc: 0,
    color: "#AAAAAA",
    emoji: "<:common:1442729822676582573>",
    cooldownMs: 0,
    label: "COMMON",
  },
};

function chooseRarity() {
  const roll = Math.random() * 100;
  let cumulative = 0;

  for (const [rarity, data] of Object.entries(RARITIES)) {
    cumulative += data.chance;
    if (roll < cumulative) {
      return { rarity, data };
    }
  }

  return { rarity: "common", data: RARITIES.common };
}

function getRarityData(rarity) {
  return RARITIES[rarity] || RARITIES.common;
}

function getAllRarities() {
  return RARITIES;
}

function formatNumber(n) {
  return typeof n === "number" ? n.toLocaleString() : n || 0;
}

module.exports = {
  chooseRarity,
  getRarityData,
  getAllRarities,
  formatNumber,
  RARITIES,
};
