const db = require("../utils/dropsDB.js");
const { spawnDropForGuild, expireCurrentDrop } = require("./spawnDrop.js");

const DROP_INTERVAL_MS = 30 * 60 * 1000;
const RAIN_INTERVAL_MS = 1 * 60 * 1000;
const CHECK_INTERVAL_MS = 60 * 1000;

let spawnerInterval = null;

function startAutoSpawner(client, prefix = "!") {
  if (spawnerInterval) {
    clearInterval(spawnerInterval);
  }

  const guildTimers = new Map();

  spawnerInterval = setInterval(async () => {
    try {
      const guilds = await db.getAllEnabledGuilds();
      const now = Date.now();

      for (const guild of guilds) {
        const guildId = guild.GuildId;
        
        if (guild.activeDrop && guild.activeDrop.rarity && now > guild.activeDrop.expiresAt) {
          await expireCurrentDrop(client, guild);
        }

        const isRainMode = guild.rainMode && now < guild.rainEndTime;
        const interval = isRainMode ? RAIN_INTERVAL_MS : DROP_INTERVAL_MS;

        const lastSpawn = guildTimers.get(guildId) || 0;
        
        if (now - lastSpawn >= interval) {
          if (!guild.activeDrop || !guild.activeDrop.rarity) {
            const result = await spawnDropForGuild(client, guildId, prefix);
            if (result.success) {
              guildTimers.set(guildId, now);
              console.log(`[AUTO-SPAWNER] Spawned drop in guild ${guildId} (Rain: ${isRainMode})`);
            }
          }
        }

        if (guild.rainMode && now >= guild.rainEndTime) {
          guild.rainMode = false;
          guild.rainEndTime = 0;
          await db.saveGuild(guild);
          console.log(`[RAIN MODE] Ended for guild ${guildId}`);
        }
      }
    } catch (err) {
      console.error("[AUTO-SPAWNER ERROR]:", err);
    }
  }, CHECK_INTERVAL_MS);

  console.log("[AUTO-SPAWNER] Started - Checking every 60s, drops every 30min");
}

function stopAutoSpawner() {
  if (spawnerInterval) {
    clearInterval(spawnerInterval);
    spawnerInterval = null;
    console.log("[AUTO-SPAWNER] Stopped");
  }
}

async function enableRainMode(guildId, durationMinutes = 30) {
  const guild = await db.getGuild(guildId);
  guild.rainMode = true;
  guild.rainEndTime = Date.now() + (durationMinutes * 60 * 1000);
  await db.saveGuild(guild);
  console.log(`[RAIN MODE] Enabled for guild ${guildId} for ${durationMinutes} minutes`);
  return guild.rainEndTime;
}

async function disableRainMode(guildId) {
  const guild = await db.getGuild(guildId);
  guild.rainMode = false;
  guild.rainEndTime = 0;
  await db.saveGuild(guild);
  console.log(`[RAIN MODE] Disabled for guild ${guildId}`);
}

module.exports = {
  startAutoSpawner,
  stopAutoSpawner,
  enableRainMode,
  disableRainMode,
  DROP_INTERVAL_MS,
  RAIN_INTERVAL_MS,
};
