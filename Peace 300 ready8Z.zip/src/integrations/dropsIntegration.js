const db = require('../utils/dropsDB.js');
const { startAutoSpawner } = require('../system/autoSpawnerLoop.js');

function init(client, options = {}) {
  const prefix = options.prefix || (client.prefix ? client.prefix : (require('../config').prefix || '!'));
  
  startAutoSpawner(client, prefix);

  console.log("[DROPS] Integration initialized with prefix:", prefix);
}

module.exports = { init };
