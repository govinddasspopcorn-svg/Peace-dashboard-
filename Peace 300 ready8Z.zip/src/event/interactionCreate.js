const {
  TicketCategory
} = require("../schema/ticket");

module.exports = {
  name: "interactionCreate",

  async execute(interaction, client) {
    try {

      // =========================
      // BUTTON TICKET
      // =========================
      if (interaction.isButton()) {

        if (interaction.customId.startsWith("ticket_btn_")) {

          await interaction.deferReply({ ephemeral: true }).catch(() => {});

          const categoryId = interaction.customId.replace("ticket_btn_", "");
          const category = await TicketCategory.findById(categoryId);

          if (!category || !category.Enabled)
            return interaction.editReply({
              content: "❌ Ticket panel disabled / invalid.",
              ephemeral: true
            });

          const channel = await client.ticket.createTicket({
            guild: interaction.guild,
            user: interaction.user,
            category
          });

          return interaction.editReply({
            content: `🎫 Ticket created: ${channel}`,
            ephemeral: true
          });
        }
      }

      // =========================
      // DROPDOWN TICKET
      // =========================
      if (interaction.isStringSelectMenu()) {

        if (interaction.customId === "ticket_dropdown") {

          await interaction.deferReply({ ephemeral: true }).catch(() => {});

          const categoryId = interaction.values[0];
          const category = await TicketCategory.findById(categoryId);

          if (!category || !category.Enabled)
            return interaction.editReply({
              content: "❌ Ticket panel disabled / invalid.",
              ephemeral: true
            });

          const channel = await client.ticket.createTicket({
            guild: interaction.guild,
            user: interaction.user,
            category
          });

          return interaction.editReply({
            content: `🎫 Ticket created: ${channel}`,
            ephemeral: true
          });
        }
      }

      // Other interactions continue normally (bot slash cmds etc handled by your other system)

    } catch (err) {
      console.log("Ticket Interaction Error:", err);

      try {
        if (interaction.deferred || interaction.replied)
          return interaction.followUp({ content: "❌ Something went wrong.", ephemeral: true });

        return interaction.reply({ content: "❌ Something went wrong.", ephemeral: true });
      } catch {}
    }
  }
};