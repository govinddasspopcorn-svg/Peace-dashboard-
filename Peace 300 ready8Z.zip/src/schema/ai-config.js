const mongoose = require("mongoose");

const AiSchema = new mongoose.Schema({
  guildId: { type: String, required: true },
  enabled: { type: Boolean, default: false },
  allowedChannels: { type: [String], default: [] }
});

module.exports = mongoose.models.AiConfig || mongoose.model("AiConfig", AiSchema);