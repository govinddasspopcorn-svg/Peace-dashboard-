const mongo = require("mongoose");

const Schema = new mongo.Schema({
  Member: { type: String, unique: true },
  Reason: String,
  Time: Number,

  Mentions: [
    {
      username: String,
      messageUrl: String,
      timestamp: Number,
    },
  ],
});

module.exports = mongo.model("afk", Schema);