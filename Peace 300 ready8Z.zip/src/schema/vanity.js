const mongoose = require("mongoose");

const schema = new mongoose.Schema({
  guildId: String,
  logChannel: String,
  words: { type: [String], default: [] },
  tracked: { type: Map, default: {} }
});

module.exports = mongoose.model("Vanity", schema);