const mongoose = require("mongoose");

const antiStickerSpamSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  isEnabled: { type: Boolean, default: true }, // Auto-enabled
  stickerThreshold: { type: Number, default: 10 }, // 10+ stickers
  timeframe: { type: Number, default: 60000 }, // in 1 minute (60000ms)
  whitelistUsers: { type: [String], default: [] },
  whitelistRoles: { type: [String], default: [] },
});

module.exports = mongoose.model("AntiStickerSpam", antiStickerSpamSchema);
