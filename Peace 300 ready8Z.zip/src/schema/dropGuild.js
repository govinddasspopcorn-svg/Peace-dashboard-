const mongoose = require("mongoose");

const dropGuildSchema = new mongoose.Schema({
  GuildId: { type: String, required: true, unique: true },
  enabled: { type: Boolean, default: false },
  dropChannel: { type: String, default: null },
  activeDrop: {
    rarity: { type: String, default: null },
    rewardOwo: { type: Number, default: 0 },
    rewardLtc: { type: Number, default: 0 },
    spawnedAt: { type: Number, default: 0 },
    expiresAt: { type: Number, default: 0 },
    messageId: { type: String, default: null },
  },
  rainMode: { type: Boolean, default: false },
  rainEndTime: { type: Number, default: 0 },
  totalDrops: { type: Number, default: 0 },
  totalClaimed: { type: Number, default: 0 },
});

module.exports = mongoose.model("DropGuild", dropGuildSchema);
