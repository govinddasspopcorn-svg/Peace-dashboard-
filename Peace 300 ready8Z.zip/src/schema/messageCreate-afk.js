const { EmbedBuilder } = require("discord.js");
const db = require("../../schema/afk");

module.exports = {
  name: "messageCreate",

  run: async (client, message) => {
    if (!message.guild || message.author.bot) return;

    // REMOVE AFK WHEN USER TALKS (GLOBAL)
    const userAFK = await db.findOne({ Member: message.author.id });
    if (userAFK) {
      await db.deleteOne({ Member: message.author.id }).catch(() => {});
      return message.channel.send({
        content: `${client.emoji.tick} Welcome back **${message.author.username}**, AFK removed globally.`
      }).catch(() => {});
    }

    // CHECK IF MENTIONED USER IS AFK
    const mentioned = message.mentions.members?.first();
    if (!mentioned) return;

    const afkData = await db.findOne({ Member: mentioned.id });
    if (!afkData) return;

    const embed = new EmbedBuilder()
      .setColor(client.color)
      .setAuthor({
        name: `${mentioned.user.username} is AFK`,
        iconURL: mentioned.user.displayAvatarURL()
      })
      .setDescription(
        `**Reason:** ${afkData.Reason || "No reason"}\n<t:${Math.floor(
          afkData.Time / 1000
        )}:R>`
      );

    message.reply({ embeds: [embed] }).catch(() => {});
  }
};