const mongoose = require("mongoose");

const AntiNukeSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  isEnabled: { type: Boolean, default: false },
  extraOwners: { type: [String], default: [] },
  whitelistUsers: { type: [String], default: [] },
  whitelistRoles: { type: [String], default: [] },
  logChannelId: { type: String, default: null },
  punishment: { type: String, default: "ban" }, // ban, kick, none
  events: {
    ban: { type: Boolean, default: true },
    kick: { type: Boolean, default: true },
    unban: { type: Boolean, default: true },
    roleCreate: { type: Boolean, default: true },
    roleDelete: { type: Boolean, default: true },
    roleUpdate: { type: Boolean, default: true },
    channelCreate: { type: Boolean, default: true },
    channelDelete: { type: Boolean, default: true },
    channelUpdate: { type: Boolean, default: true },
    webhookUpdate: { type: Boolean, default: true },
    emojiUpdate: { type: Boolean, default: true },
    guildUpdate: { type: Boolean, default: true },
    botAdd: { type: Boolean, default: true },
    antiEveryone: { type: Boolean, default: true },
  },
  whitelistedEvents: {
    type: Map,
    of: [String], // Map event name to list of user IDs
    default: new Map(),
  }
});

module.exports = mongoose.model("AntiNuke", AntiNukeSchema);
