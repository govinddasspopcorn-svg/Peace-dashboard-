const { Schema, model } = require("mongoose");

const LoggingSchema = new Schema({
  guildId: { type: String, required: true, unique: true },
  channelId: { type: String, default: null },
  isEnabled: { type: Boolean, default: false },
  events: {
    messageDelete: { type: Boolean, default: true },
    messageUpdate: { type: Boolean, default: true },
    channelCreate: { type: Boolean, default: true },
    channelDelete: { type: Boolean, default: true },
    roleCreate: { type: Boolean, default: true },
    roleDelete: { type: Boolean, default: true },
    memberJoin: { type: Boolean, default: true },
    memberLeave: { type: Boolean, default: true },
    voiceJoin: { type: Boolean, default: true },
    voiceLeave: { type: Boolean, default: true },
  }
});

module.exports = model("Logging", LoggingSchema);
