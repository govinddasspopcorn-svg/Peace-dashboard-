const { model, Schema } = require("mongoose");

module.exports = model(
  "ticket-config",
  new Schema({
    Guild: String,
    OpenCategory: String,
    ClosedCategory: String,
    LogsChannel: String,
    Cooldown: { type: Number, default: 60 }
  })
);