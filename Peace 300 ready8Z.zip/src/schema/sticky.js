const mongoose = require("mongoose");

const stickySchema = new mongoose.Schema({
  guildId: String,
  channelId: String,
  message: String,
  lastMessageId: String
});

module.exports = mongoose.model("Sticky", stickySchema);