const mongoose = require("mongoose");

const warningSchema = new mongoose.Schema({
  guildId: { type: String, required: true },
  userId: { type: String, required: true },
  warnings: [{
    warnId: String,
    reason: String,
    moderator: String,
    timestamp: { type: Number, default: Date.now }
  }],
  punishments: [{
    type: String, // timeout, kick, ban
    reason: String,
    timestamp: Number
  }]
});

warningSchema.index({ guildId: 1, userId: 1 });

module.exports = mongoose.model("Warnings", warningSchema);
