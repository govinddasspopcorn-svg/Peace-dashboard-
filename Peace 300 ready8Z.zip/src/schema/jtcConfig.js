const mongoose = require("mongoose");

const JTCConfig = new mongoose.Schema({

  guildId: String,

  hubChannelId: String,

  categoryId: String,

  interfaceChannelId: String

});

module.exports = mongoose.model("JTCConfig", JTCConfig);