const { model, Schema } = require("mongoose");

module.exports = model(
  "OnboardingSetup",
  new Schema({
    guildId: { type: String, required: true, unique: true },
    roles: { type: Array, default: [] } // stores allowed onboarding roles
  })
);