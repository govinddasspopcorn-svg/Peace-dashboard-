const mongoose = require("mongoose");

const AiMemorySchema = new mongoose.Schema({
  guildId: { type: String, required: true },
  userId: { type: String, required: true },

  // cute ai bestie profile save
  userProfile: {
    username: String,
    firstSeen: Date,
    lastSeen: Date,
    totalMessages: { type: Number, default: 0 },
    trustLevel: { type: Number, default: 1 }, // auto grows
  },

  // main memory for chatting
  shortMemory: [
    {
      role: String, // user / assistant
      content: String,
      time: Date,
    }
  ],

  // long term saved memory about user
  longMemory: [
    {
      note: String,
      importance: { type: Number, default: 1 }, // 1 normal - 5 highly important
      time: Date,
    }
  ],

  stats: {
    totalConversations: { type: Number, default: 0 },
    lastConversation: Date,
  },

  lastUpdated: Date,
});

module.exports =
  mongoose.models.AiMemory || mongoose.model("AiMemory", AiMemorySchema);