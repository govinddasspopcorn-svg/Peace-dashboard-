const mongoose = require("mongoose");

const antiCapsSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  isEnabled: { type: Boolean, default: false },
  capsPercentage: { type: Number, default: 70 }, // 70% caps allowed
  punishment: { type: String, default: "delete" }, // delete, warn, timeout, mute
  whitelistUsers: { type: [String], default: [] },
  whitelistRoles: { type: [String], default: [] },
});

module.exports = mongoose.model("AntiCaps", antiCapsSchema);
