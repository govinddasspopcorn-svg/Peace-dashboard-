const mongoose = require("mongoose");

const dropUserSchema = new mongoose.Schema({
  UserId: { type: String, required: true, unique: true },
  owo: { type: Number, default: 0 },
  ltc: { type: Number, default: 0 },
  dropsClaimed: { type: Number, default: 0 },
  rarityStats: {
    mythical: { type: Number, default: 0 },
    legendary: { type: Number, default: 0 },
    rare: { type: Number, default: 0 },
    uncommon: { type: Number, default: 0 },
    common: { type: Number, default: 0 },
  },
  cooldowns: {
    mythical: { type: Number, default: 0 },
    legendary: { type: Number, default: 0 },
    rare: { type: Number, default: 0 },
  },
  claimHistory: [{
    rarity: String,
    owoAmount: Number,
    ltcAmount: Number,
    claimedAt: { type: Date, default: Date.now },
    guildId: String,
  }],
});

module.exports = mongoose.model("DropUser", dropUserSchema);
