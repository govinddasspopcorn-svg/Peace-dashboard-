const { model, Schema } = require("mongoose");

/* ================= TICKET ================= */
const TicketSchema = new Schema({
  Guild: String,
  Channel: String,
  User: String,

  Status: { type: String, default: "open" },   // open | closed
  TicketNumber: Number,
  CategoryId: String,

  CreatedAt: { type: Date, default: Date.now },
  ClosedAt: Date,
  ClosedBy: String,
  ClaimedBy: String
});

/* ================= CATEGORY / PANEL ================= */
const CategorySchema = new Schema({
  Guild: String,
  Name: String,
  Emoji: { type: String, default: "🎫" },
  Description: String,

  Enabled: { type: Boolean, default: true },

  OpenCategory: String,
  ClosedCategory: String,
  SupportRoles: { type: Array, default: [] },

  PanelType: String,   // button | dropdown

  // ⭐ NEW — PANEL WISE LOGS + DM SUPPORT
  LogsChannel: { type: String, default: null },
  DmUser: { type: Boolean, default: true }
});

/* ================= COUNTER ================= */
const CounterSchema = new Schema({
  Guild: String,
  Count: { type: Number, default: 1 }
});

/* ================= LOGS ================= */
const LogSchema = new Schema({
  Guild: String,
  Channel: String
});

/* ================= BAN ================= */
const BanSchema = new Schema({
  Guild: String,
  User: String
});

/* ================= SETTINGS ================= */
const SettingsSchema = new Schema({
  Guild: String,
  GlobalLimit: Number,
  CooldownMs: Number
});

module.exports = {
  Ticket: model("ticket", TicketSchema),
  TicketCategory: model("ticket-category", CategorySchema),
  TicketCounter: model("ticket-counter", CounterSchema),
  TicketLogs: model("ticket-logs", LogSchema),
  TicketBan: model("ticket-ban", BanSchema),
  TicketSettings: model("ticket-settings", SettingsSchema)
};