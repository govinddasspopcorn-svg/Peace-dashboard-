const mongoose = require("mongoose");

const warnSettingsSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  punishments: {
    type: Map,
    of: String,
    default: new Map([
      ['3', 'timeout'],    // 3 warns = timeout
      ['5', 'kick'],       // 5 warns = kick
      ['7', 'ban']         // 7 warns = ban
    ])
  },
  resetDaily: { type: Boolean, default: true }, // Reset warn count daily
  lastReset: { type: Number, default: Date.now }
});

module.exports = mongoose.model("WarnSettings", warnSettingsSchema);
