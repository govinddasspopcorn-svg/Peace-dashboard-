const mongoose = require("mongoose");

const roleSchema = new mongoose.Schema(
  {
    guildId: { type: String, required: true, unique: true },

    reqrole: { type: String, default: null },
    official: { type: String, default: null },
    friend: { type: String, default: null },
    guest: { type: String, default: null },
    girl: { type: String, default: null },
    vip: { type: String, default: null },

    customRoles: {
      type: Map,
      of: String,
      default: {},
    },
  },
  { timestamps: true },
);

module.exports = mongoose.model("Roles", roleSchema);