const { model, Schema } = require("mongoose");

const giveawaySchema = new Schema({
  guildId: { type: String, required: true },
  channelId: { type: String, required: true },
  messageId: { type: String, required: true },
  hostId: { type: String, required: true },
  prize: { type: String, required: true },
  winners: { type: Number, required: true, default: 1 },
  startTime: { type: Number, required: true },
  endTime: { type: Number, required: true },
  ended: { type: Boolean, default: false },
  participants: { type: [String], default: [] },
  winnerUsers: { type: [String], default: [] },
  emoji: { type: String, default: "<a:giveaway:1440153256964788306>" }
});

module.exports = model("Giveaway", giveawaySchema);
