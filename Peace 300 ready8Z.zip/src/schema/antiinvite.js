const mongoose = require("mongoose");

const antiInviteSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  isEnabled: { type: Boolean, default: false },
  punishment: { type: String, default: "delete" }, // delete, warn, timeout, kick
  whitelistUsers: { type: [String], default: [] },
  whitelistRoles: { type: [String], default: [] },
  whitelistChannels: { type: [String], default: [] },
});

module.exports = mongoose.model("AntiInvite", antiInviteSchema);
