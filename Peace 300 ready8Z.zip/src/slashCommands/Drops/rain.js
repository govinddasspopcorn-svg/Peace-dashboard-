const { EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const { enableRainMode, disableRainMode } = require("../../system/autoSpawnerLoop.js");
const db = require("../../utils/dropsDB.js");

module.exports = {
  name: "rain",
  description: "Enable rain mode (Owner only)",
  userPerms: [],
  botPerms: ["SendMessages", "EmbedLinks"],
  options: [
    {
      name: "duration",
      description: "Duration in minutes (1-120) or 0 to disable",
      type: ApplicationCommandOptionType.Integer,
      required: false,
      minValue: 0,
      maxValue: 120,
    },
  ],

  run: async (client, interaction, prefix) => {
    await interaction.deferReply({ ephemeral: false });

    // OWNER CHECK
    const BOT_OWNER = process.env.OWNER_ID;
    if (interaction.user.id !== BOT_OWNER) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder().setColor("#FF0000").setDescription("❌ | Only the **Bot Owner** can use this command!")
        ],
      });
    }

    const guild = await db.getGuild(interaction.guildId);

    if (!guild.enabled || !guild.dropChannel) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder().setColor("#FF0000").setDescription("❌ | Drops not configured! Use `/dropchannel`.")
        ],
      });
    }

    const duration = interaction.options.getInteger("duration");

    if (duration === 0) {
      await disableRainMode(interaction.guildId);
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor("#00FF00")
            .setTitle("🌧️ Rain Mode Disabled")
            .setDescription("Drops will now return to normal spawn rate (30 minutes).")
        ],
      });
    }

    const actualDuration = duration || 30;
    const endTime = await enableRainMode(interaction.guildId, actualDuration);

    const embed = new EmbedBuilder()
      .setColor("#00BFFF")
      .setTitle("🌧️ Rain Mode Enabled!")
      .setDescription(
        `Drops will now spawn **every 2 minutes**!\n\n` +
        `**Duration:** ${actualDuration} minutes\n` +
        `**Ends:** <t:${Math.floor(endTime / 1000)}:R>`
      )
      .setTimestamp();

    return interaction.editReply({ embeds: [embed] });
  },
};