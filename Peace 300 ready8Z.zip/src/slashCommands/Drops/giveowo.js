const { EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const db = require("../../utils/dropsDB.js");
const { formatNumber } = require("../../system/rarityChooser.js");

module.exports = {
  name: "giveowo",
  description: "Give OWO to a user (Owner only)",
  userPerms: [],
  botPerms: ["SendMessages", "EmbedLinks"],
  options: [
    {
      name: "user",
      description: "The user to give OWO to",
      type: ApplicationCommandOptionType.User,
      required: true,
    },
    {
      name: "amount",
      description: "Amount of OWO",
      type: ApplicationCommandOptionType.Integer,
      required: true,
      minValue: 1,
    },
  ],

  run: async (client, interaction) => {
    await interaction.deferReply({ ephemeral: false });

    // OWNER CHECK
    const BOT_OWNER = process.env.OWNER_ID;
    if (interaction.user.id !== BOT_OWNER) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription("❌ | Only the **Bot Owner** can use this command!")
        ],
      });
    }

    const target = interaction.options.getUser("user");
    const amount = interaction.options.getInteger("amount");

    const user = await db.addOwoToUser(target.id, amount);

    const embed = new EmbedBuilder()
      .setColor("#00FF00")
      .setTitle("✅ OWO Given!")
      .setDescription(
        `Gave **${formatNumber(amount)} OWO** to ${target}.\n\n` +
        `**New Balance:** ${formatNumber(user.owo)}`
      )
      .setThumbnail(target.displayAvatarURL({ size: 128 }))
      .setTimestamp();

    return interaction.editReply({ embeds: [embed] });
  },
};