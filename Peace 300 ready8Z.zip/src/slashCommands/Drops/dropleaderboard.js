const { EmbedBuilder } = require("discord.js");
const db = require("../../utils/dropsDB.js");
const { formatNumber } = require("../../system/rarityChooser.js");

module.exports = {
  name: "dropleaderboard",
  description: "View the top drop collectors",
  userPerms: [],
  botPerms: ["SendMessages", "EmbedLinks"],

  run: async (client, interaction) => {
    await interaction.deferReply({ ephemeral: false });

    const leaderboard = await db.getLeaderboard(10);

    if (!leaderboard || leaderboard.length === 0) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(client.color)
            .setDescription("❌ | No one has claimed any drops yet!")
        ],
      });
    }

    let leaderboardText = "";
    const medals = ["🥇", "🥈", "🥉"];

    for (let i = 0; i < leaderboard.length; i++) {
      const user = leaderboard[i];
      const rank = i < 3 ? medals[i] : `**#${i + 1}**`;
      
      let username = "Unknown User";
      try {
        const fetchedUser = await client.users.fetch(user.UserId).catch(() => null);
        if (fetchedUser) username = fetchedUser.username;
      } catch (e) {}

      leaderboardText += `${rank} **${username}**\n`;
      leaderboardText += `   <a:owo:1442395441181229177> ${formatNumber(user.owo)} OWO`;
      if (user.ltc > 0) {
        leaderboardText += ` | <a:ltc:1442395484802121822> $${user.ltc.toFixed(2)} LTC`;
      }
      leaderboardText += ` | 🎁 ${user.dropsClaimed} claims\n\n`;
    }

    const embed = new EmbedBuilder()
      .setColor(client.color)
      .setTitle("🏆 Drop Leaderboard")
      .setDescription(leaderboardText)
      .setFooter({ text: "Use /dbal to check your own balance!" })
      .setTimestamp();

    return interaction.editReply({ embeds: [embed] });
  },
};
