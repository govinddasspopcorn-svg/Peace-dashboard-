const { EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const db = require("../../utils/dropsDB.js");
const { formatNumber } = require("../../system/rarityChooser.js");

module.exports = {
  name: "dbal",
  description: "Check your drop balance and stats",
  userPerms: [],
  botPerms: ["SendMessages", "EmbedLinks"],
  options: [
    {
      name: "user",
      description: "The user to check balance for",
      type: ApplicationCommandOptionType.User,
      required: false,
    },
  ],

  run: async (client, interaction) => {
    await interaction.deferReply({ ephemeral: false });

    const target = interaction.options.getUser("user") || interaction.user;
    const user = await db.getUser(target.id);

    const stats = user.rarityStats || { mythical: 0, legendary: 0, rare: 0, uncommon: 0, common: 0 };

    const embed = new EmbedBuilder()
      .setColor(client.color)
      .setTitle("👤 Drop Balance")
      .setThumbnail(target.displayAvatarURL({ size: 256 }))
      .addFields(
        {
          name: "💰 Balance",
          value: 
            `<a:owo:1442395441181229177> **OWO:** ${formatNumber(user.owo || 0)}\n Or` +
            `<a:ltc:1442395484802121822> **LTC:** $${(user.ltc || 0).toFixed(2)}`,
          inline: true,
        },
        {
          name: "🎁 Drops Claimed",
          value: `**${formatNumber(user.dropsClaimed || 0)}** total`,
          inline: true,
        },
        {
          name: "📊 Rarity Stats",
          value:
            `<:mythical:1442729822676582573> Mythical: **${formatNumber(stats.mythical || 0)}**\n` +
            `<:legendary:1442729822676582573> Legendary: **${formatNumber(stats.legendary || 0)}**\n` +
            `<:rare:1442729822676582573> Rare: **${formatNumber(stats.rare || 0)}**\n` +
            `<:uncommon:1442729822676582573> Uncommon: **${formatNumber(stats.uncommon || 0)}**\n` +
            `<:common:1442729822676582573> Common: **${formatNumber(stats.common || 0)}**`,
          inline: false,
        }
      )
      .setFooter({ text: `Requested by ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
      .setTimestamp();

    return interaction.editReply({ embeds: [embed] });
  },
};
