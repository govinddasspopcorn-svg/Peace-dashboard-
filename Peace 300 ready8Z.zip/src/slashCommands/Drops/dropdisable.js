const { EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../utils/dropsDB.js");

module.exports = {
  name: "dropdisable",
  description: "Disable drops in this server",
  userPerms: ["ManageGuild"],
  botPerms: ["SendMessages", "EmbedLinks"],

  options: [],

  run: async (client, interaction, prefix) => {
    await interaction.deferReply({ ephemeral: false });

    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription("❌ | You need **Manage Server** permission to use this command!")
        ],
      });
    }

    const guild = await db.getGuild(interaction.guildId);

    if (!guild.enabled) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription("❌ | Drops are already disabled in this server!")
        ],
      });
    }

    guild.enabled = false;
    guild.dropChannel = null;
    // optional: clear active drop
    guild.activeDrop = {
      rarity: null,
      rewardOwo: 0,
      rewardLtc: 0,
      spawnedAt: 0,
      expiresAt: 0,
      messageId: null,
    };

    await db.saveGuild(guild);

    const embed = new EmbedBuilder()
      .setColor("#FF9900")
      .setTitle("🚫 Drops Disabled")
      .setDescription(
        "Automatic drops are now **disabled** in this server" +
        `Use `/dropchannel` again to enable and set a drop channel.`
      )
      .setTimestamp();

    return interaction.editReply({ embeds: [embed] });
  },
};