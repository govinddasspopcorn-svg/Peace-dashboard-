const { EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const db = require("../../utils/dropsDB.js");

module.exports = {
  name: "resetuser",
  description: "Reset a user's drop data (Owner only)",
  userPerms: [],
  botPerms: ["SendMessages", "EmbedLinks"],
  options: [
    {
      name: "user",
      description: "The user to reset",
      type: ApplicationCommandOptionType.User,
      required: true,
    },
  ],

  run: async (client, interaction) => {
    await interaction.deferReply({ ephemeral: false });

    // OWNER ONLY
    const BOT_OWNER = process.env.OWNER_ID;
    if (interaction.user.id !== BOT_OWNER) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder().setColor("#FF0000").setDescription("❌ | Only the **Bot Owner** can use this command!")
        ],
      });
    }

    const target = interaction.options.getUser("user");

    await db.resetUserData(target.id);

    const embed = new EmbedBuilder()
      .setColor("#00FF00")
      .setTitle("✅ User Reset")
      .setDescription(
        `Reset drop data for **${target.username}**:\n` +
        `• OWO: 0\n• LTC: $0.00\n• Drops: 0\n• All cooldowns cleared`
      )
      .setThumbnail(target.displayAvatarURL({ size: 128 }))
      .setTimestamp();

    return interaction.editReply({ embeds: [embed] });
  },
};