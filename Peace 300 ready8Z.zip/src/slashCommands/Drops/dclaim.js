const { EmbedBuilder } = require("discord.js");
const { claimDrop } = require("../../system/spawnDrop.js");
const { getRarityData, formatNumber } = require("../../system/rarityChooser.js");

module.exports = {
  name: "dclaim",
  description: "Claim the active drop in the server",
  userPerms: [],
  botPerms: ["SendMessages", "EmbedLinks"],

  run: async (client, interaction) => {
    await interaction.deferReply({ ephemeral: false });

    const result = await claimDrop(client, interaction.guildId, interaction.user.id, interaction.user.username);

    if (!result.success) {
      let errorMsg = "";
      switch (result.reason) {
        case "no_active_drop":
          errorMsg = "There is no active drop to claim right now!";
          break;
        case "drop_expired":
          errorMsg = "That drop has expired! Wait for the next one.";
          break;
        case "cooldown":
          errorMsg = `You're on cooldown for **${result.rarity.toUpperCase()}** drops! Wait **${result.timeRemaining}** before claiming this rarity again.`;
          break;
        default:
          errorMsg = "Something went wrong. Please try again.";
      }

      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription(`❌ | ${errorMsg}`)
        ],
      });
    }

    const data = getRarityData(result.rarity);

    const embed = new EmbedBuilder()
      .setColor(data.color)
      .setTitle(`${data.emoji} Drop Claimed!`)
      .setDescription(
        `**${interaction.user.username}** claimed a **${data.label}** drop!\n\n` +
        `**Rewards:**\n` +
        `<a:owo:1442395441181229177> **+${formatNumber(result.owoAmount)} OWO**\n Or` +
        (result.ltcAmount > 0 ? `<a:ltc:1442395484802121822> **+$${result.ltcAmount.toFixed(2)} LTC**\n` : "")
      )
      .setThumbnail(interaction.user.displayAvatarURL({ size: 256 }))
      .setFooter({ text: "Congratulations! Use /dbal to check your balance." })
      .setTimestamp();

    if (result.messageId) {
      try {
        const dropMessage = await interaction.channel.messages.fetch(result.messageId).catch(() => null);
        if (dropMessage) {
          const claimedEmbed = new EmbedBuilder()
            .setColor(data.color)
            .setTitle(`${data.emoji} Drop Claimed!`)
            .setDescription(`This **${data.label}** drop was claimed by **${interaction.user.username}**!`)
            .setTimestamp();
          await dropMessage.edit({ embeds: [claimedEmbed], components: [] }).catch(() => null);
        }
      } catch (e) {}
    }

    return interaction.editReply({ embeds: [embed] });
  },
};
