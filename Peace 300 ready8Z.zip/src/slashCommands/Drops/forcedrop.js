const { EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const { spawnDropForGuild } = require("../../system/spawnDrop.js");
const { RARITIES } = require("../../system/rarityChooser.js");

module.exports = {
  name: "forcedrop",
  description: "Force spawn a drop (Owner only)",
  userPerms: [],
  botPerms: ["SendMessages", "EmbedLinks"],
  options: [
    {
      name: "rarity",
      description: "Rarity of the drop",
      type: ApplicationCommandOptionType.String,
      required: false,
      choices: [
        { name: "Mythical", value: "mythical" },
        { name: "Legendary", value: "legendary" },
        { name: "Rare", value: "rare" },
        { name: "Uncommon", value: "uncommon" },
        { name: "Common", value: "common" },
      ],
    },
  ],

  run: async (client, interaction, prefix) => {
    await interaction.deferReply({ ephemeral: true });

    // OWNER CHECK
    const BOT_OWNER = process.env.OWNER_ID;
    if (interaction.user.id !== BOT_OWNER) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription("❌ | Only the **Bot Owner** can use this command!")
        ],
      });
    }

    const forceRarity = interaction.options.getString("rarity") || null;

    const result = await spawnDropForGuild(client, interaction.guildId, prefix || "/", forceRarity);

    if (!result.success) {
      let msg = "";
      if (result.reason === "not_configured") msg = "Drops not configured! Use `/dropchannel`.";
      else if (result.reason === "active_drop_exists") msg = "There is already an active drop.";
      else if (result.reason === "channel_not_found") msg = "Drop channel not found.";
      else msg = "Failed to spawn drop.";

      return interaction.editReply({
        embeds: [new EmbedBuilder().setColor("#FF0000").setDescription(`❌ | ${msg}`)],
      });
    }

    const embed = new EmbedBuilder()
      .setColor("#00FF00")
      .setDescription(`✅ | Spawned a **${result.rarity.toUpperCase()}** drop!`)
      .setTimestamp();

    return interaction.editReply({ embeds: [embed] });
  },
};