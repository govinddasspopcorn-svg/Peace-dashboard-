const { EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const db = require("../../utils/dropsDB.js");

module.exports = {
  name: "dropchannel",
  description: "Set the channel where drops will spawn",
  userPerms: [],
  botPerms: ["SendMessages", "EmbedLinks"],
  options: [
    {
      name: "channel",
      description: "The channel where drops will spawn",
      type: ApplicationCommandOptionType.Channel,
      required: false,
    },
  ],

  run: async (client, interaction, prefix) => {
    await interaction.deferReply({ ephemeral: false });

    // OWNER CHECK
    const BOT_OWNER = process.env.OWNER_ID;
    if (interaction.user.id !== BOT_OWNER) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor("#FF0000")
            .setDescription("❌ | Only the **Bot Owner** can use this command!")
        ],
      });
    }

    const channel = interaction.options.getChannel("channel") || interaction.channel;

    if (!channel.isTextBased()) {
      return interaction.editReply({
        embeds: [
          new EmbedBuilder().setColor("#FF0000").setDescription("❌ | Invalid channel!")
        ],
      });
    }

    const guild = await db.getGuild(interaction.guildId);
    guild.dropChannel = channel.id;
    guild.enabled = true;
    await db.saveGuild(guild);

    const embed = new EmbedBuilder()
      .setColor("#00FF00")
      .setTitle("✅ Drop Channel Set!")
      .setDescription(
        `Drops will now spawn in ${channel}!\n\n` +
        `Use:\n` +
        `\`/dclaim\` - Claim drops\n` +
        `\`/forcedrop\` - Force a drop\n` +
        `\`/rain\` - Rain mode`
      )
      .setTimestamp();

    return interaction.editReply({ embeds: [embed] });
  },
};