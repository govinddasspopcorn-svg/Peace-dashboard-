const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits
} = require("discord.js");

const {
  TicketCategory,
  TicketSettings
} = require("../../schema/ticket");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ticket-quicksetup")
    .setDescription("Fully guided ticket panel setup"),

  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator))
      return interaction.reply({
        content: "❌ You must be an Admin to use this.",
        ephemeral: true
      });

    const Q = "<:Queue:1455451575198683218>";
    const X = "<:cross:1455452613645566147>";

    const ask = async (content) => {
      await interaction.followUp({
        embeds: [
          new EmbedBuilder()
            .setColor("#ffaa00")
            .setDescription(`${Q} ${content}`)
        ],
        ephemeral: true
      });

      const msg = await interaction.channel.awaitMessages({
        filter: m => m.author.id === interaction.user.id,
        max: 1,
        time: 300000
      }).catch(() => null);

      return msg?.first()?.content;
    };

    await interaction.reply({
      content: `${Q} **Slash Ticket Quick Setup Started**`,
      ephemeral: true
    });

    try {
      /* ================= GLOBAL SETTINGS ================= */
      await TicketSettings.findOneAndUpdate(
        { Guild: interaction.guild.id },
        {
          Guild: interaction.guild.id,
          GlobalLimit: 1,
          CooldownMs: 12000
        },
        { upsert: true }
      );

      /* ================= PANEL NAME ================= */
      const Name = await ask("Enter **Panel Name**\nExample: Support / Help / Paid / Staff Apply");
      if (!Name) throw "cancel";

      /* ================= EMOJI ================= */
      const EmojiAsk = await ask("Enter Emoji or type `none`");
      const Emoji = EmojiAsk?.toLowerCase() === "none"
        ? Q
        : EmojiAsk;

      /* ================= DESCRIPTION ================= */
      const Description = await ask("Enter **Panel Description**");
      if (!Description) throw "cancel";

      /* ================= PANEL TYPE ================= */
      const TypeAsk = await ask("Type `button` or `dropdown`");
      const PanelType = ["button", "dropdown"].includes(TypeAsk?.toLowerCase())
        ? TypeAsk.toLowerCase()
        : "button";

      /* ================= OPEN CATEGORY ================= */
      const openAsk = await ask("Mention **OPEN Tickets Category**");
      const OpenCategory =
        interaction.guild.channels.cache.get(openAsk?.replace(/[<#>]/g, ""))?.id;

      if (!OpenCategory)
        return interaction.followUp({ content: `${X} Invalid Open Category`, ephemeral: true });

      /* ================= CLOSED CATEGORY ================= */
      const closedAsk = await ask("Mention **CLOSED Tickets Category** or type `none`");
      const ClosedCategory =
        closedAsk?.toLowerCase() === "none"
          ? null
          : interaction.guild.channels.cache.get(closedAsk?.replace(/[<#>]/g, ""))?.id;

      /* ================= SUPPORT ROLES ================= */
      const roleAsk = await ask("Mention Support Roles or type `none`");
      const SupportRoles =
        roleAsk?.toLowerCase() === "none"
          ? []
          : roleAsk.split(" ")
              .map(x => interaction.guild.roles.cache.get(x.replace(/[<@&>]/g, "")))
              .filter(r => r)
              .map(r => r.id);

      /* ================= SAVE DB ================= */
      const category = await TicketCategory.create({
        Guild: interaction.guild.id,
        Name,
        Emoji,
        Description,
        Enabled: true,
        OpenCategory,
        ClosedCategory,
        SupportRoles,
        PanelType
      });

      /* ================= LOGS CHANNEL AUTO ================= */
      try {
        const logs = await interaction.guild.channels.create({
          name: `${Name.toLowerCase().replace(/ /g, "-")}-logs`,
          type: ChannelType.GuildText,
          permissionOverwrites: [
            { id: interaction.guild.id, deny: ["ViewChannel"] },
            ...SupportRoles.map(r => ({
              id: r,
              allow: ["ViewChannel", "SendMessages", "ReadMessageHistory"]
            }))
          ]
        });

        category.LogsChannel = logs.id;
        await category.save();

        await logs.send({
          embeds: [
            new EmbedBuilder()
              .setColor("#2b2d31")
              .setTitle("🧾 Ticket Logs Enabled")
              .setDescription(
                `📂 Panel: **${Name}**\n` +
                `🛡️ Support: ${
                  SupportRoles?.length
                    ? SupportRoles.map(r => `<@&${r}>`).join(", ")
                    : "None"
                }\n\nLogs Enabled:\n• Ticket Open\n• Ticket Close\n• Transcript\n• DM`
              )
          ]
        });
      } catch {}

      /* ================= PANEL CHANNEL ================= */
      const panelAsk = await ask("Mention Panel Channel");
      const PanelChannel =
        interaction.guild.channels.cache.get(panelAsk?.replace(/[<#>]/g, ""));

      if (!PanelChannel)
        return interaction.followUp({ content: `${X} Invalid Panel Channel`, ephemeral: true });

      /* ================= PANEL EMBED ================= */
      const embed = new EmbedBuilder()
        .setColor("#2b2d31")
        .setTitle(`${Emoji} ${Name} Tickets`)
        .setDescription(
          `${Description}\n\n` +
          `Click below to create a ticket`
        )
        .setTimestamp();

      let components = [];

      if (PanelType === "button") {
        components = [
          new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId(`ticket_btn_${category._id}`)
              .setLabel("Open Ticket")
              .setEmoji("<a:ticket:1414311755311484958>")
              .setStyle(ButtonStyle.Primary)
          )
        ];
      } else {
        components = [
          new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
              .setCustomId("ticket_dropdown")
              .setPlaceholder("Open Ticket")
              .addOptions([
                {
                  label: Name,
                  value: category._id.toString(),
                  emoji: Emoji
                }
              ])
          )
        ];
      }

      await PanelChannel.send({
        embeds: [embed],
        components
      });

      return interaction.followUp({
        content: `${Q} Ticket Panel Created Successfully in ${PanelChannel}`,
        ephemeral: true
      });

    } catch {
      return interaction.followUp({
        content: `${X} Setup Cancelled or Timed Out`,
        ephemeral: true
      });
    }
  }
};