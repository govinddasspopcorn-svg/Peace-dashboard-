const { EmbedBuilder } = require("discord.js");
const PrefixDB = require("../../schema/prefix");

module.exports = {
  name: "help",
  description: "Shows the bot prefix and how to get full help menu",

  run: async (client, interaction) => {
    let prefix = client.prefix || "!";
    
    const data = await db.findOne({ Guild: interaction.guildId });
    if (data?.Prefix) prefix = data.Prefix;

    const emoji = client?.emoji?.information || "ℹ️";

    const embed = new EmbedBuilder()
      .setColor("#2b2d31")
      .setAuthor({
        name: "Help Information",
        iconURL: client.user.displayAvatarURL()
      })
      .setDescription(
        `${emoji} **My Prefix in this server is:** \`${prefix}\`\n\n` +
        `Use the following command to view all help categories:\n` +
        `\`\`\`${prefix}help\`\`\`\n`
      )
      .setFooter({ text: "Use prefix help to view full commands" });

    return interaction.reply({ embeds: [embed], ephemeral: false });
  }
};