const config = require("../../config");

// ALLOWED OWNERS
const ALLOWED_OWNERS = [
  "1358678646466019501",
  "1266043322129059925",
];

module.exports = {
  name: "say",
  description: "Owner only secret say command",
  options: [
    {
      name: "message",
      description: "Message the bot should say",
      type: 3, // STRING
      required: true,
    },
    {
      name: "times",
      description: "How many times to send the message (1-20)",
      type: 4, // INTEGER
      required: false,
    },
  ],

  run: async (client, interaction) => {
    // MULTI OWNER CHECK
    if (!ALLOWED_OWNERS.includes(interaction.user.id)) {
      return interaction.reply({
        content: "❌ You cannot use this command.",
        ephemeral: true,
      });
    }

    const text = interaction.options.getString("message");
    let times = interaction.options.getInteger("times") || 1;

    if (times < 1) times = 1;
    if (times > 20) times = 20;

    await interaction.deferReply({ ephemeral: true });

    await Promise.all(
      Array.from({ length: times }).map(() =>
        interaction.channel.send({ content: text }).catch(() => {})
      )
    );

    await interaction.editReply({
      content: `✅ Sent **${times}** time(s).`,
    });
  },
};