const GiveawayManager = require("../../utils/giveawayManager");

const Giveaway = require("../../schema/giveaway");

module.exports = {

  name: "greroll",

  description: "Reroll winners for a completed giveaway",

  userPerms: ["ManageGuild"],

  botPerms: ["ManageGuild"],

  options: [

    {

      name: "message_id",

      description: "Message ID of the giveaway to reroll",

      required: true,

      type: 3,

    },

  ],

  run: async (client, interaction) => {

    try {

      await interaction.deferReply({ ephemeral: true });

      const messageId = interaction.options.getString("message_id");

      const giveaway = await Giveaway.findOne({

        messageId: messageId,

        guildId: interaction.guild.id,

      });

      if (!giveaway) {

        return interaction.editReply({

          content: "❌ No giveaway found with that message ID!",

        });

      }

      if (!giveaway.ended) {

        return interaction.editReply({

          content:

            "❌ This giveaway hasn't ended yet! Use `/gend` to end it first.",

        });

      }

      const giveawayManager = new GiveawayManager(client);

      // FIX: call rerollGiveaway with messageId only, no result handling

      await giveawayManager.rerollGiveaway(messageId);

      await interaction.editReply({

        content:

          `✅ Giveaway rerolled!

` +

          `Prize: **${giveaway.prize}**`,

      });

    } catch (error) {

      console.error("Error in greroll command:", error);

      await interaction

        .editReply({

          content: "❌ An error occurred while rerolling the giveaway!",

        })

        .catch(() => {});

    }

  },

};