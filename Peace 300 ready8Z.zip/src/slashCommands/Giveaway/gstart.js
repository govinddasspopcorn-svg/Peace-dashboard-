const GiveawayManager = require("../../utils/giveawayManager");

module.exports = {
  name: "gstart",
  description: "Start a new giveaway",
  userPerms: ["ManageGuild"],
  botPerms: ["ManageGuild"],
  options: [
    {
      name: "duration",
      description: "Duration of the giveaway (e.g., 1h, 30m, 1d)",
      required: true,
      type: 3,
    },
    {
      name: "prize",
      description: "What is being given away",
      required: true,
      type: 3,
    },
    {
      name: "winners",
      description: "Number of winners (1-20)",
      required: true,
      type: 4,
    },
    {
      name: "channel",
      description: "Channel to host the giveaway in",
      required: false,
      type: 7,
    },
  ],

  run: async (client, interaction) => {
    try {
      await interaction.deferReply({ ephemeral: true });

      const durationString = interaction.options.getString("duration");
      const prize = interaction.options.getString("prize");
      const winners = interaction.options.getInteger("winners");
      const channel = interaction.options.getChannel("channel");

      if (winners < 1 || winners > 20) {
        return interaction.editReply({
          content: "❌ Number of winners must be between 1 and 20!"
        });
      }

      const giveawayManager = new GiveawayManager(client);
      const duration = giveawayManager.parseDuration(durationString);

      if (duration < 1000) {
        return interaction.editReply({
          content: "❌ Duration must be at least 1 second! Use format like: 1m, 1h, 1d"
        });
      }

      if (duration > 30 * 24 * 60 * 60 * 1000) {
        return interaction.editReply({
          content: "❌ Duration cannot exceed 30 days!"
        });
      }

      const result = await giveawayManager.createGiveaway(
        interaction,
        prize,
        duration,
        winners,
        channel?.id
      );

      if (result.success) {
        await interaction.editReply({
          content: `✅ Giveaway started in ${channel ? channel : interaction.channel}!\n` +
                   `Prize: **${prize}**\n` +
                   `Winners: **${winners}**\n` +
                   `Duration: **${durationString}**`
        });
      } else {
        await interaction.editReply({
          content: `❌ Failed to start giveaway: ${result.error}`
        });
      }
    } catch (error) {
      console.error("Error in gstart command:", error);
      await interaction.editReply({
        content: "❌ An error occurred while starting the giveaway!"
      }).catch(() => {});
    }
  }
};
