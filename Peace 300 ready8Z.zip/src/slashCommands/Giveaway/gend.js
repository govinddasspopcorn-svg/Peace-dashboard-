const GiveawayManager = require("../../utils/giveawayManager");
const Giveaway = require("../../schema/giveaway");

module.exports = {
  name: "gend",
  description: "End an ongoing giveaway",
  userPerms: ["ManageGuild"],
  botPerms: ["ManageGuild"],

  options: [
    {
      name: "message_id",
      description: "Message ID of the giveaway to end",
      required: true,
      type: 3,
    },
  ],

  run: async (client, interaction) => {
    try {
      await interaction.deferReply({ ephemeral: true });

      const messageId = interaction.options.getString("message_id");

      const giveaway = await Giveaway.findOne({
        messageId: messageId,
        guildId: interaction.guild.id,
      });

      if (!giveaway) {
        return interaction.editReply({
          content: "❌ No giveaway found with that message ID!",
        });
      }

      if (giveaway.ended) {
        return interaction.editReply({
          content: "❌ This giveaway has already ended!",
        });
      }

      const giveawayManager = new GiveawayManager(client);

      const result = await giveawayManager.endGiveaway(messageId);

      if (!result.success) {
        return interaction.editReply({
          content: `❌ Could not end giveaway: ${result.error}`,
        });
      }

      return interaction.editReply({
        content:
          `✅ Giveaway ended!\n\n` +
          `Prize: **${giveaway.prize}**`,
      });

    } catch (error) {
      console.error("Error in gend command:", error);

      await interaction
        .editReply({
          content: "❌ An error occurred while ending the giveaway!",
        })
        .catch(() => {});
    }
  },
};
