const { EmbedBuilder } = require("discord.js");
const Giveaway = require("../../schema/giveaway");

module.exports = {
  name: "glist",
  description: "List all active giveaways in this server",
  userPerms: [],
  botPerms: [],
  options: [],

  run: async (client, interaction) => {
    try {
      await interaction.deferReply({ ephemeral: true });

      const giveaways = await Giveaway.find({
        guildId: interaction.guild.id,
        ended: false
      }).sort({ endTime: 1 });

      if (giveaways.length === 0) {
        return interaction.editReply({
          content: "❌ There are no active giveaways in this server!"
        });
      }

      const embed = new EmbedBuilder()
        .setTitle(`🎉 Active Giveaways (${giveaways.length})`)
        .setColor(client.color || "#FFD700")
        .setTimestamp();

      let description = "";
      for (let i = 0; i < giveaways.length; i++) {
        const g = giveaways[i];
        const channel = await interaction.guild.channels.fetch(g.channelId).catch(() => null);
        
        description += `\n**${i + 1}.** ${g.prize}\n`;
        description += `${client.emoji?.dot || "•"} Channel: ${channel || "Unknown"}\n`;
        description += `${client.emoji?.dot || "•"} Winners: ${g.winners}\n`;
        description += `${client.emoji?.dot || "•"} Ends: <t:${Math.floor(g.endTime / 1000)}:R>\n`;
        description += `${client.emoji?.dot || "•"} Message ID: \`${g.messageId}\`\n`;
        description += `${client.emoji?.dot || "•"} Participants: ${g.participants.length}\n`;
      }

      embed.setDescription(description);

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("Error in glist command:", error);
      await interaction.editReply({
        content: "❌ An error occurred while listing giveaways!"
      }).catch(() => {});
    }
  }
};
