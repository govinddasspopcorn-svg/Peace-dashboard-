cat > src/config/dropsConfig.js << '
