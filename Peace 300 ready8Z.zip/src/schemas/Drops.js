cat > src/schemas/Drops.js << '
